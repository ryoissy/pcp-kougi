#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int n;
long long c[101][101];

int main(void){
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			scanf("%lld",&c[j][i]);
		}
	}
	long long cnt=0;
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			cnt+=min(c[i][j],c[j][i]);
		}
	}
	printf("%lld\n",cnt);
	return 0;
}