#include <cstdio>
#include <cstring>
#include <iostream>
#include <string>
using namespace std;

int r,c;
char str[22][22];
string str2[22];
int dx[4]={1,0,-1,0};
int dy[4]={0,1,0,-1};
bool visited[22][22][4][17];

bool dfs(int x,int y,int d,int m){
	if(visited[x][y][d][m])return false;
	visited[x][y][d][m]=true;
	//printf("%d %d %d %d\n",x,y,d,m);
	if(str[x][y]=='@')return true;
	if(str[x][y]=='>')d=0;
	if(str[x][y]=='<')d=2;
	if(str[x][y]=='^')d=3;
	if(str[x][y]=='v')d=1;
	if(str[x][y]=='_'){
		if(m==0)d=0;
		if(m!=0)d=2;
	}
	if(str[x][y]=='|'){
		if(m==0)d=1;
		if(m!=0)d=3;
	}
	if(str[x][y]>='0' && str[x][y]<='9')m=str[x][y]-'0';
	if(str[x][y]=='+')m=(m+1)%16;
	if(str[x][y]=='-')m=(m+15)%16;
	if(str[x][y]=='?'){
		bool ch=false;
		for(int i=0;i<4;i++){
			if(dfs((x+dx[i]+c)%c,(y+dy[i]+r)%r,i,m))ch=true;
		}
		return ch;
	}else{
		return dfs((x+dx[d]+c)%c,(y+dy[d]+r)%r,d,m);
	}
}

int main(void){
	scanf("%d %d",&r,&c);
	for(int i=0;i<r;i++){
		cin >> str2[i];
	}
	for(int i=0;i<r;i++){
		for(int j=0;j<c;j++){
			str[j][i]=str2[i][j];
		}
	}
	memset(visited,false,sizeof(visited));
	printf("%s\n",dfs(0,0,0,0)?"YES":"NO");
	return 0;
}