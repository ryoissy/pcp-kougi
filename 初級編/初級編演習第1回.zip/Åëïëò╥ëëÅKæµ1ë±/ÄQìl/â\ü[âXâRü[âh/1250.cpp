#include <cstdio>
#include <cstring>
#include <iostream>
#include <string>
#include <algorithm>
using namespace std;
typedef long long ll;
int s;
const char* sixteen="0123456789abcdef";
ll num[10];

int main(void){
	scanf("%d",&s);
	for(int ddd=0;ddd<s;ddd++){
		for(int i=0;i<9;i++){
			num[i]=0;
			string str;
			cin >> str;
			for(int j=0;j<str.size();j++){
				if(str[j]>='a' && str[j]<='f')num[i]=(ll)num[i]*16+str[j]-'a'+10;
				if(str[j]>='0' && str[j]<='9')num[i]=(ll)num[i]*16+str[j]-'0';
			}
		}
		ll res=0;
		ll p=1;
		int cnt=0;
		for(int i=0;i<32;i++){
			int cnt2=0;
			for(int i=0;i<8;i++){
				if(num[i] & 1)cnt2++;
				num[i]>>=1;
			}
			if((cnt2+cnt%2)%2!=(num[8] & 1)){
				res=res+p;
				cnt2=8-cnt2;
			}
			p<<=1;
			cnt=(cnt+cnt2)/2;
			num[8]>>=1;
		}
		string restr="";
		while(res>=0){
			restr+=sixteen[res%16];
			res/=16;
			if(res==0)break;
		}
		reverse(restr.begin(),restr.end());
		cout << restr << endl;
	}
	return 0;
}