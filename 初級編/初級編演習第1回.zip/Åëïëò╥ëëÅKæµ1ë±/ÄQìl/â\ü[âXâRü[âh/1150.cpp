#include<cstdio>
#include<queue>
#include<vector>
#include<functional>
#include<algorithm>
#include<iostream>
#include<cstring>

using namespace std;

class data{
public:
	int x,y,rx,ry,s,cost;
	bool operator<(const data &d1)const{
		return d1.cost<cost;
	}
};

int w,h;
int dp[35][65][5][7][4];
int fie[100][100];
int flag[100][100];
int sx[50],scnt;

int dijk(){
	memset(dp,-1,sizeof(dp));
	priority_queue<data> que;
	data inp;
	int res=-1;
	inp.y=h;
	inp.rx=1;
	inp.ry=3;
	inp.cost=0;
	for(int i=0;i<scnt;i++){
		inp.x=sx[i];
		inp.s=2;
		que.push(inp);
		inp.x=sx[i]-1;
		inp.s=3;
		que.push(inp);
	}
	while(que.size()){
		data q=que.top();
		que.pop();
		if(dp[q.x][q.y][q.rx][q.ry][q.s]!=-1 && dp[q.x][q.y][q.rx][q.ry][q.s]<q.cost)continue;
		dp[q.x][q.y][q.rx][q.ry][q.s]=q.cost;
		if(flag[q.x][q.y]==1 || flag[q.x+q.rx][q.y+q.ry-3]==1){
			res=min(res,q.cost);
			if(res==-1)res=q.cost;
		}
		if(q.s%2==0){
			for(int i=1;i<=3;i++){
				for(int j=-3;j<=3;j++){
					if(i+abs(j)>3)continue;
					if(q.x+i>=1 && q.x+i<=w && q.y+j>=1 && q.y+j<=h){
						if(fie[q.x+i][q.y+j]!=-1){
							if(dp[q.x][q.y][i][j+3][1]==-1 || dp[q.x][q.y][i][j+3][1]>q.cost+fie[q.x+i][q.y+j]){
								dp[q.x][q.y][i][j+3][1]=q.cost+fie[q.x+i][q.y+j];
								data nq=q;
								nq.rx=i;
								nq.ry=j+3;
								nq.s=1;
								nq.cost=q.cost+fie[q.x+i][q.y+j];
								que.push(nq);
							}
						}
					}
				}
			}
		}
		if(q.s%2==1){
			q.x=q.x+q.rx;
			q.y=q.y+q.ry-3;
			for(int i=-3;i<=-1;i++){
				for(int j=-3;j<=3;j++){
					if(-i+abs(j)>3)continue;
					if(q.x+i>=1 && q.x+i<=w && q.y+j>=1 && q.y+j<=h){
						if(fie[q.x+i][q.y+j]!=-1){
							if(dp[q.x+i][q.y+j][-i][-j+3][0]==-1 || dp[q.x+i][q.y+j][-i][-j+3][0]>q.cost+fie[q.x+i][q.y+j]){
								dp[q.x+i][q.y+j][-i][-j+3][0]=q.cost+fie[q.x+i][q.y+j];
								data nq;
								nq.x=q.x+i;
								nq.y=q.y+j;
								nq.rx=-i;
								nq.ry=-j+3;
								nq.s=0;
								nq.cost=q.cost+fie[q.x+i][q.y+j];
								que.push(nq);
							}
						}
					}
				}
			}			
		}
	}
	return res;
}

int main(void){
	while(1){
		scanf("%d %d",&w,&h);
		if(w+h==0)break;
		memset(fie,0,sizeof(fie));
		memset(flag,0,sizeof(flag));
		scnt=0;
		for(int i=1;i<=h;i++){
			for(int j=1;j<=w;j++){
				char c;
				cin >> c;
				if(c=='S')fie[j][i]=0,sx[scnt]=j,scnt++;
				if(c=='T')fie[j][i]=0,flag[j][i]=1;
				if(c=='X')fie[j][i]=-1;
				if(c>='1' && c<='9')fie[j][i]=c-'0';
			}
		}
		printf("%d\n",dijk());
	}
	return 0;
}