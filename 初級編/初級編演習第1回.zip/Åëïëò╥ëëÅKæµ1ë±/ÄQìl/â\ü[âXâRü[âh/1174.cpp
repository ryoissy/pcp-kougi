#include<cstdio>
#include<cstring>
#include<vector>
#include<queue>
#include<map>

using namespace std;
typedef pair<int,int> P;

int p[10][10];
int cp[10][10];
int flag[10][10];
int h,w,c;

int sx[4]={0,1,0,-1};
int sy[4]={1,0,-1,0};
int col[7],res;

int bfs(int cc){
	memset(flag,0,sizeof(flag));
	queue<P> que;
	que.push(P(1,1));
	flag[1][1]=1;
	while(que.size()){
		P q=que.front();
		que.pop();
		int x=q.first,y=q.second;
		for(int i=0;i<4;i++){
			int nx=sx[i]+x,ny=sy[i]+y;
			if(flag[nx][ny]==0){
				if(cp[x][y]==cp[nx][ny]){
					flag[nx][ny]=1;
					que.push(P(nx,ny));
				}
			}
		}
	}
	int cnt=0;
	for(int i=1;i<=h;i++){
		for(int j=1;j<=w;j++){
			if(flag[j][i]==1)cp[j][i]=cc;
			cnt+=flag[j][i];
		}
	}
	return cnt;
}

void dfs(int x){
	if(x<4){
		for(int i=1;i<=6;i++){
			col[x]=i;
			dfs(x+1);
		}
	}else{
		col[4]=c;
		for(int i=1;i<=h;i++){
			for(int j=1;j<=w;j++){
				cp[j][i]=p[j][i];
			}
		}
		for(int i=0;i<5;i++){
			bfs(col[i]);
		}
		res=max(res,bfs(7));
	}
}

int main(void){
	while(1){
		scanf("%d %d %d",&h,&w,&c);
		if(h+w+c==0)break;
		res=0;
		memset(p,0,sizeof(p));
		for(int i=1;i<=h;i++){
			for(int j=1;j<=w;j++){
				scanf("%d",&p[j][i]);
			}
		}
		dfs(0);
		printf("%d\n",res);
	}
	return 0;
}