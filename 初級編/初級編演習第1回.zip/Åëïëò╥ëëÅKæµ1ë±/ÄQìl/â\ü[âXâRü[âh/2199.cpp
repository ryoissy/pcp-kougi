#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>

#define INF 255*255*20000
int n,m;
int c[17],x[30000];
int dp[20001][256];
int main(void){
	while(1){
		scanf("%d %d",&n,&m);
		if(n+m==0)break;
		for(int i=0;i<m;i++){
			scanf("%d",&c[i]);
		}
		for(int i=0;i<n;i++){
			scanf("%d",&x[i]);
		}
		memset(dp,-1,sizeof(dp));
		dp[0][128]=0;
		for(int i=0;i<n;i++){
			for(int j=0;j<256;j++){
				if(dp[i][j]>=0){
					for(int k=0;k<m;k++){
						int nx=j+c[k];
						if(nx<0)nx=0;
						if(nx>255)nx=255;
						int np=pow(nx-x[i],2);
						if(dp[i+1][nx]>np+dp[i][j] || dp[i+1][nx]==-1){
							dp[i+1][nx]=np+dp[i][j];
						}
					}
				}
			}
		}
		int res=INF;
		for(int i=0;i<256;i++){
			if(dp[n][i]>=0)res=std::min(res,dp[n][i]);
		}
		printf("%d\n",res);
	}
	return 0;
}