#include <cstdio>
#include <cstring>
#include <iostream>
#include <string>
using namespace std;

char data[4][1000001];
int cnt[4][1000001];
int len[4];
int main(void){
	for(int i=0;i<3;i++){
		while(1){
			scanf("%c%*c",&data[i][len[i]]);
			if(data[i][len[i]]=='$'){
				len[i]++;
				break;
			}
			scanf("%d%*c",&cnt[i][len[i]]);
			len[i]++;
		}
	}
	int i;
	for(i=0;i<=len[0]-len[1];i++){
		int j;
		for(j=0;j<len[1]-1;j++){
			if(data[0][i+j]!=data[1][j])break;
			if(j==0 && cnt[0][i+j]>cnt[1][j])continue;
			if(cnt[0][i+j]==cnt[1][j])continue;
			if(j==len[1]-2 && cnt[0][i+j]>cnt[1][j])continue;
			break;
		}
		if(j==len[1]-1){
			for(int j=0;j<len[0];j++){
				if(j<i){
					data[3][len[3]]=data[0][j];
					cnt[3][len[3]]=cnt[0][j];
					len[3]++;
				}else if(i==j){
					if(len[1]==2){
						for(int k=0;k<len[2]-1;k++){
							if(len[3]>0 && data[3][len[3]-1]==data[2][k])cnt[3][len[3]-1]+=cnt[2][k];
							else{
								data[3][len[3]]=data[2][k];
								cnt[3][len[3]]=cnt[2][k];
								len[3]++;
							}
						}
						if(cnt[0][j]>cnt[1][0]){
							if(len[3]>0 && data[3][len[3]-1]==data[0][j])cnt[3][len[3]-1]+=cnt[0][j]-cnt[1][0];
							else{
								data[3][len[3]]=data[0][j];
								cnt[3][len[3]]=cnt[0][j]-cnt[1][0];
								len[3]++;
							}
						}
					}else{
						if(cnt[0][j]>cnt[1][0]){
							data[3][len[3]]=data[0][j];
							cnt[3][len[3]]=cnt[0][j]-cnt[1][0];
							len[3]++;
						}
						for(int k=0;k<len[2]-1;k++){
							if(len[3]>0 && data[3][len[3]-1]==data[2][k])cnt[3][len[3]-1]+=cnt[2][k];
							else{
								data[3][len[3]]=data[2][k];
								cnt[3][len[3]]=cnt[2][k];
								len[3]++;
							}
						}
					}
				}else if(len[1]>2 && j==i+len[1]-2){
					if(cnt[0][j]>cnt[1][len[1]-2]){
						if(len[3]>0 && data[3][len[3]-1]==data[0][j])cnt[3][len[3]-1]+=cnt[0][j]-cnt[1][len[1]-2];
						else{
							data[3][len[3]]=data[0][j];
							cnt[3][len[3]]=cnt[0][j]-cnt[1][len[1]-2];
							len[3]++;
						}
					}
				}else if(j>=i+len[1]-1){
					if(len[3]>0 && data[3][len[3]-1]==data[0][j])cnt[3][len[3]-1]+=cnt[0][j];
					else{
						data[3][len[3]]=data[0][j];
						cnt[3][len[3]]=cnt[0][j];
						len[3]++;
					}
				}
			}
			break;
		}
	}
	if(i==len[0]-len[1]+1 || len[0]<len[1]){
		for(int j=0;j<len[0];j++){
			printf("%c",data[0][j]);
			if(data[0][j]=='$'){
				printf("\n");
				return 0;
			}
			printf(" %d ",cnt[0][j]);
		}
	}
	for(i=0;i<len[3];i++){
		printf("%c",data[3][i]);
		if(data[3][i]=='$'){
			printf("\n");
			break;
		}
		printf(" %d ",cnt[3][i]);
	}
	return 0;
}