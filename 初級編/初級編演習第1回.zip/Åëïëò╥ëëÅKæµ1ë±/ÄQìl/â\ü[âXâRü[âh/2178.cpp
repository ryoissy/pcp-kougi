#include <cstdio>
#include <cstring>
#include <queue>
#include <vector>
#include <algorithm>
#include <map>
using namespace std;

map<int,map< int,int > > field;
int n;
int x[20001],y[20001];
int head[20001];
char dir[20001];
vector<int> G[20001];
int dx[4]={0,1,0,-1};
int dy[4]={1,0,-1,0};
vector<int> vs;

bool dfs(int v,int c){
	head[v]=c;
	vs.push_back(v);
	for(int i=0;i<G[v].size();i++){
		int e=G[v][i];
		if(dir[v]=='x' && dir[e]=='x'){
			if(x[v]==x[e]){
				if(head[e]==-1){
					if(!dfs(e,c))return false;
				}else{
					if(head[e]!=c)return false;
				}
			}else{
				if(head[e]==-1){
					if(!dfs(e,1-c))return false;
				}else{
					if(head[e]!=1-c)return false;
				}
			}
		}else if(dir[v]=='y' && dir[e]=='y'){
			if(y[v]==y[e]){
				if(head[e]==-1){
					if(!dfs(e,c))return false;
				}else{
					if(head[e]!=c)return false;
				}
			}else{
				if(head[e]==-1){
					if(!dfs(e,1-c))return false;
				}else{
					if(head[e]!=1-c)return false;
				}
			}
		}else{
			bool flag0=true,flag1=true;
			if(c==0){
				for(int i=0;i<4;i++){
					if(x[v]+dx[i]==x[e] && y[v]+dy[i]==y[e])flag1=false;
					if(x[v]+dx[i]==x[e]+(dir[e]=='x') && y[v]+dy[i]==y[e]+(dir[e]=='y'))flag0=false;
				}
				for(int i=0;i<4;i++){
					if(x[e]+dx[i]==x[v]+(dir[v]=='x') && y[e]+dy[i]==y[v]+(dir[v]=='y'))flag0=false;
					if(x[e]+(dir[e]=='x')+dx[i]==x[v]+(dir[v]=='x') && y[e]+(dir[e]=='y')+dy[i]==y[v]+(dir[v]=='y'))flag1=false;
				}
			}
			if(c==1){
				for(int i=0;i<4;i++){
					if(x[v]+(dir[v]=='x')+dx[i]==x[e] && y[v]+(dir[v]=='y')+dy[i]==y[e])flag1=false;
					if(x[v]+(dir[v]=='x')+dx[i]==x[e]+(dir[e]=='x') && y[v]+(dir[v]=='y')+dy[i]==y[e]+(dir[e]=='y'))flag0=false;
				}
				for(int i=0;i<4;i++){
					if(x[e]+dx[i]==x[v] && y[e]+dy[i]==y[v])flag0=false;
					if(x[e]+(dir[e]=='x')+dx[i]==x[v] && y[e]+(dir[e]=='y')+dy[i]==y[v])flag1=false;
				}
			}
			if(!flag0 && !flag1)return false;
			int nc;
			if(flag0)nc=0;
			if(flag1)nc=1;
			if(head[e]==-1){
				if(!dfs(e,nc))return false;
			}else{
				if(head[e]!=nc)return false;
			}
		}
	}
	return true;
}

bool check(){
	for(int i=1;i<=n;i++){
		if(dir[i]=='x'){
			if(field[x[i]][y[i]]!=0)return false;
			field[x[i]][y[i]]=i;
			if(field[x[i]+1][y[i]]!=0)return false;
			field[x[i]+1][y[i]]=i;
		}
		if(dir[i]=='y'){
			if(field[x[i]][y[i]]!=0)return false;
			field[x[i]][y[i]]=i;
			if(field[x[i]][y[i]+1]!=0)return false;
			field[x[i]][y[i]+1]=i;
		}
	}
	for(int i=1;i<=n;i++){
		if(dir[i]=='x'){
			for(int j=0;j<4;j++){
				if(field[x[i]+dx[j]][y[i]+dy[j]]!=0 && field[x[i]+dx[j]][y[i]+dy[j]]!=field[x[i]][y[i]]){
					G[i].push_back(field[x[i]+dx[j]][y[i]+dy[j]]);
				}
				if(field[x[i]+dx[j]+1][y[i]+dy[j]]!=0 && field[x[i]+dx[j]+1][y[i]+dy[j]]!=field[x[i]+1][y[i]]){
					G[i].push_back(field[x[i]+dx[j]+1][y[i]+dy[j]]);
				}
			}
		}
		if(dir[i]=='y'){
			for(int j=0;j<4;j++){
				if(field[x[i]+dx[j]][y[i]+dy[j]]!=0 && field[x[i]+dx[j]][y[i]+dy[j]]!=field[x[i]][y[i]]){
					G[i].push_back(field[x[i]+dx[j]][y[i]+dy[j]]);
				}
				if(field[x[i]+dx[j]][y[i]+dy[j]+1]!=0 && field[x[i]+dx[j]][y[i]+dy[j]+1]!=field[x[i]][y[i]+1]){
					G[i].push_back(field[x[i]+dx[j]][y[i]+dy[j]+1]);
				}
			}
		}
	}
	memset(head,-1,sizeof(head));
	for(int i=1;i<=n;i++){
		if(head[i]==-1){
			if(!dfs(i,0)){
				for(int j=0;j<vs.size();j++){
					head[vs[j]]=-1;
				}
				if(!dfs(i,1))return false;
			}
			vs.clear();
		}
	}
	return true;
}

int main(void){
	while(1){
		field.clear();
		scanf("%d",&n);
		if(n==0)break;
		for(int i=1;i<=n;i++){
			G[i].clear();
			scanf("%d %d %c",&x[i],&y[i],&dir[i]);
		}
		printf("%s\n",check()?"Yes":"No");
	}
	return 0;
}