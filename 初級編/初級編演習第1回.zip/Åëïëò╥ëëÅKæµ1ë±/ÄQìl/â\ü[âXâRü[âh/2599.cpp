#include <cstdio>
#include <string>
#include <iostream>
#include <cstring>
using namespace std;

int change[7][7]={
	{18,17,16,14,12,11,9},
    {17,15,14,12,10,9,7},
    {16,14,13,11,9,8,6},
    {14,12,11,9,7,6,4},
    {12,10,9,7,5,4,2},
    {11,9,8,6,4,3,1},
    {9,7,6,4,2,1,0}
};
string str;

bool dfs(){
	for(int i=0;i<(1<<19);i++){
		int num[19];
		for(int j=0;j<19;j++){
			num[j]=(i>>j)&1;
		}
		int c[7]={};
		for(int j=0;j<7;j++){
			for(int k=0;k<7;k++){
				if(num[change[j][k]])c[j]+=(1<<k);
			}
			c[j]=str[c[j]]-'0';
		}
		int d=0;
		for(int k=0;k<7;k++){
			if(c[k])d+=(1<<k);
		}
		if(str[d]-'0'!=c[3])return false;
	}
	return true;
}

int main(void){
	while(1){
		cin >> str;
		if(str=="#")break;
		printf("%s\n",dfs()?"yes":"no");
	}
	return 0;
}