#include <cstdio>
#include <cstring>
#include <cmath>
#define EPS 1e-10
int n,k;
double t,u,v,l;
double d[201];

double add(double a,double b){
	if(fabs(a+b)<EPS*(fabs(a)+fabs(b)))return 0.0;
	return a+b;
}

int main(void){
	scanf("%d %d %lf %lf %lf %lf",&n,&k,&t,&u,&v,&l);
	for(int i=1;i<=n;i++){
		scanf("%lf",&d[i]);
	}
	d[n+1]=l;
	int now=0;
	double tim=0.0,rest=0.0;
	for(int i=1;i<=n+1;i++){
		if(rest==0.0 && now==0){
			tim+=(d[i]-d[i-1])/u;
			if(now<k)now++;
			else if(now==k)rest=l;
		}else{
			double dist=d[i-1];
			while(add(dist,-d[i])!=0.0){
				if(rest>0.0){
					double cost=(d[i]-dist)/v;
					if(cost>rest){
						dist+=v*rest;
						tim+=rest;
						rest=0.0;
					}else{
						dist=d[i];
						tim+=cost;
						rest-=cost;
					}
				}else{
					if(now>0){
						now--;
						rest=t;
					}else{
						tim+=(d[i]-dist)/u;
						dist=d[i];
					}
				}
			}
			if(now<k)now++;
			else if(now==k)rest=t;
		}
		//printf("%f %f %d %lf\n",tim,d[i],now,rest);
	}
	printf("%.10f\n",tim);
	return 0;
}