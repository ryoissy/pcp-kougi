#include <cstdio>
#include <cstring>
#include <cmath>
#include <iostream>
#include <string>
#include <queue>
#include <vector>
#include <algorithm>
using namespace std;

class data{
public:
	int x,y,c;
	data(){}
	data(int xx,int yy,int cc){
		x=xx;
		y=yy;
		c=cc;
	}
	bool operator <(const data& d1)const{
		return c>d1.c;
	}
};
#define INF 1e9
int w,h,n;
const char* dir="RDLU";
double dx[4]={1,0,-1,0};
double dy[4]={0,1,0,-1};
int sx,sy,tx,ty;
int stx,sty;
int stdir[1001];
int fie[1003][1003];
int dp[1003][1003];

int dijk(){
	priority_queue<data> que;
	for(int i=0;i<=(h+1)*2;i++){
		for(int j=0;j<=(w+1)*2;j++){
			dp[j][i]=INF;
		}
	}
	dp[sx][sy]=0;
	que.push(data(sx,sy,0));
	while(que.size()){
		data q=que.top();
		que.pop();
		if(dp[q.x][q.y]<q.c)continue;
		if(q.x==tx && q.y==ty)return q.c;
		for(int i=0;i<4;i++){
			int nx=q.x+dx[i],ny=q.y+dy[i];
			if(nx>=0 && nx<=(w+1)*2 && ny>=0 && ny<=(h+1)*2){
				int nc=q.c+fie[nx][ny];
				nx+=dx[i];
				ny+=dy[i];
				if(dp[nx][ny]>nc){
					dp[nx][ny]=nc;
					que.push(data(nx,ny,nc));
				}
			}
		}
	}
}

int main(void){
	scanf("%d %d %d",&w,&h,&n);
	scanf("%d %d %d %d",&sx,&sy,&tx,&ty);
	sx*=2;
	sy*=2;
	tx*=2;
	ty*=2;
	int cnt=0;
	for(int i=0;i<n;i++){
		scanf("%d %d",&stx,&sty);
		int t;
		string str;
		cin >> t >> str;
		stx=stx*2+1,sty=sty*2+1;
		fie[stx][sty]++;
		for(int j=0;j<str.size();j++){
			for(int k=0;k<4;k++){
				if(dir[k]==str[j]){
					stdir[j]=k;
					break;
				}
			}
		}
		for(int j=0;j<t;j++){
			for(int k=0;k<str.size();k++){
				int l=stdir[k];
				if(stx+dx[l]*2>=0 && stx+dx[l]*2<=w*2 && sty+dy[l]*2>=0 && sty+dy[l]*2<=h*2){
					stx+=dx[l],sty+=dy[l];
					fie[stx][sty]++;
					stx+=dx[l],sty+=dy[l];
					fie[stx][sty]++;
				}
			}
		}
	}
	printf("%d\n",dijk());
	return 0;
}