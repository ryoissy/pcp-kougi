#include <cstdio>
#include <cstring>
#include <vector>
#include <queue>
#include <algorithm>
#define INF 1e6
using namespace std;
typedef long long ll;
vector<int> G[100001];
int n,m,s,t;
int dist_s[100001];
int dist_l[100001];
int main(void){
	scanf("%d %d %d %d",&n,&m,&s,&t);
	s--;
	t--;
	for(int i=0;i<m;i++){
		int a,b;
		scanf("%d %d",&a,&b);
		a--;
		b--;
		G[a].push_back(b);
		G[b].push_back(a);
	}
	fill(dist_s,dist_s+n,INF);
	queue<int> que;
	que.push(s);
	dist_s[s]=0;
	while(que.size()){
		int v=que.front();
		que.pop();
		for(int i=0;i<G[v].size();i++){
			int nec=G[v][i];
			if(dist_s[nec]==INF){
				dist_s[nec]=dist_s[v]+1;
				que.push(nec);
			}
		}
	}
	fill(dist_l,dist_l+n,INF);
	que.push(t);
	dist_l[t]=0;
	while(que.size()){
		int v=que.front();
		que.pop();
		for(int i=0;i<G[v].size();i++){
			int nec=G[v][i];
			if(dist_l[nec]==INF){
				dist_l[nec]=dist_l[v]+1;
				que.push(nec);
			}
		}
	}
	int mincost=dist_s[t];
	ll cnt=0;
	sort(dist_s,dist_s+n);
	sort(dist_l,dist_l+n);
	for(int i=0;i<n;i++){
		int midl=lower_bound(dist_l,dist_l+n,mincost-dist_s[i]-2)-dist_l;
		int midr=upper_bound(dist_l,dist_l+n,mincost-dist_s[i]-2)-dist_l;
		if(midl<n && midl>=0 && dist_s[i]+dist_l[midl]+2==mincost){
			cnt+=(ll)(midr-midl);
		}
	}
	printf("%lld\n",cnt);
	return 0;
}