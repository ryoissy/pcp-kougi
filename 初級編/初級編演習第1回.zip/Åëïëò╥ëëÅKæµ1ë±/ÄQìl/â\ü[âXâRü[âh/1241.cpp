#include <cstdio>
#include <cstring>

int dp[100000][5];

int main(void){
	dp[0][0]=1;
	for(int i=1;i*i<=(1<<15);i++){
		for(int j=0;j<4;j++){
			for(int k=0;k<(1<<15);k++){
				if(dp[k][j]>=1){
					dp[k+i*i][j+1]+=dp[k][j];
				}
			}
		}
	}
	while(1){
		int n;
		scanf("%d",&n);
		if(n==0)break;
		printf("%d\n",dp[n][1]+dp[n][2]+dp[n][3]+dp[n][4]);
	}
	return 0;
}