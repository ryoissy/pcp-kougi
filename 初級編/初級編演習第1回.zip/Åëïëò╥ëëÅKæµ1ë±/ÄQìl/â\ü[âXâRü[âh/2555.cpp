#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
using namespace std;

int m,n;
int k[101];
int data[101][101][2];
int s[101][101],cond[101][101],t[101][101];
int now[101];
int next[101];
bool used[101];

int main(void){
	scanf("%d %d",&m,&n);
	for(int i=0;i<=100;i++){
		for(int j=0;j<=100;j++){
			data[i][j][0]=0;
			data[i][j][1]=101;
		}
	}
	for(int i=0;i<m;i++){
		scanf("%d",&k[i]);
		for(int j=0;j<k[i];j++){
			char d;
			scanf("%d %c%*c %d",&s[i][j],&d,&t[i][j]);
			if(d=='<')cond[i][j]=0;
			else cond[i][j]=1;
		}
	}
	for(int i=0;i<m;i++){
		for(int j=0;j<k[i];j++){
			if(cond[i][j]==0)data[i][s[i][j]][1]=min(t[i][j],data[i][s[i][j]][1]);
			if(cond[i][j]==1)data[i][s[i][j]][0]=max(t[i][j],data[i][s[i][j]][0]);
			if(data[i][s[i][j]][1]<data[i][s[i][j]][0]){
				printf("No\n");
				return 0;
			}
		}
	}
	memset(used,false,sizeof(used));
	for(int i=1;i<=n;i++)now[i]=100;
	int i;
	for(i=0;i<m;i++){
		int nec=-1;
		int j;
		for(j=0;j<m;j++){
			if(used[j])continue;
			for(int k=1;k<=n;k++){
				if(now[k]<data[j][k][0]){
					printf("No\n");
					return 0;
				}
				if(now[k]>data[j][k][1])next[k]=data[j][k][1];
				else next[k]=now[k];
			}
			bool flag=true;
			for(int k=0;k<m;k++){
				if(used[k])continue;
				for(int l=1;l<=n;l++){
					if(next[l]<data[k][l][0]){
						flag=false;
						break;
					}
				}
			}
			if(flag){
				nec=j;
				break;
			}
		}
		if(nec==-1)break;
		used[nec]=true;
		for(int j=1;j<=n;j++)now[j]=next[j];
	}
	printf("%s\n",i==m?"Yes":"No");
	return 0;
}