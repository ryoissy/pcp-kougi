#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#define MOD 1000000007LL
using namespace std;
typedef long long ll;
ll dp[51][2];
string str[3];
int l[3],r[3];
int main(void){
	while(1){
		cin >> str[0];
		if(str[0]=="0")break;
		cin >> str[1];
		cin >> str[2];
		memset(dp,0,sizeof(dp));
		dp[0][0]=1;
		for(int i=0;i<str[2].size();i++){
			for(int j=0;j<3;j++){
				l[j]=r[j]=0;
				if(str[j].size()>i){
					if(str[j][str[j].size()-i-1]>='0' && str[j][str[j].size()-i-1]<='9'){
						l[j]=str[j][str[j].size()-i-1]-'0';
						r[j]=str[j][str[j].size()-i-1]-'0';
					}else{
						l[j]=0;
						r[j]=9;
						if(str[j].size()==i+1)l[j]=1;
					}
				}
			}
			for(int n=0;n<2;n++){
				for(int j=l[0];j<=r[0];j++){
					for(int k=l[1];k<=r[1];k++){
						for(int m=l[2];m<=r[2];m++){
							if((n+j+k)%10==m){
								dp[i+1][(n+j+k)/10]=(dp[i+1][(n+j+k)/10]+dp[i][n])%MOD;
							}
						}
					}
				}
			}
		}
		printf("%lld\n",dp[str[2].size()][0]); 
	}
	return 0;
}