#include <vector>
#include <cstring>
#include <map>
#include <algorithm>
#include <cstdio>
using namespace std;

struct data{
	int id,a,p,b;
	data(){}
	data(int idd,int aa,int pp,int bb){
		id=idd;
		a=aa;
		p=pp;
		b=bb;
	}
	bool operator<(const data& d1)const{
		if(a!=d1.a)return a>d1.a;
		if(p!=d1.p)return p<d1.p;
		return id<d1.id;
	}
};

int n;
data dat[301];
int cnt[1001];
int win[28];
int main(void){
	while(1){
		memset(cnt,0,sizeof(cnt));
		scanf("%d",&n);
		if(n==0)break;
		for(int i=0;i<n;i++){
			scanf("%d %d %d %d",&dat[i].id,&dat[i].b,&dat[i].a,&dat[i].p);
		}
		sort(dat,dat+n);
		int wcnt=0;
		for(int i=0;i<n;i++){
			if(wcnt<10 && cnt[dat[i].b]<3){
				cnt[dat[i].b]++;
				win[wcnt++]=dat[i].id;
			}else if(wcnt<20 && cnt[dat[i].b]<2){
				cnt[dat[i].b]++;
				win[wcnt++]=dat[i].id;
			}else if(wcnt<26 && cnt[dat[i].b]<1){
				cnt[dat[i].b]++;
				win[wcnt++]=dat[i].id;
			}
		}
		for(int i=0;i<wcnt;i++){
			printf("%d\n",win[i]);
		}
	}
	return 0;
}