#include <cstdio>
#include <cstring>

int n;
int w[26],b[26];
bool used[26];
int main(void){
	while(1){
		scanf("%d",&n);
		if(n==0)break;
		int all=0;
		for(int i=0;i<n;i++){
			scanf("%d %d",&w[i],&b[i]);
			all+=w[i];
		}
		int i;
		memset(used,false,sizeof(used));
		for(i=0;i<n;i++){
			int j;
			for(j=0;j<n;j++){
				if(!used[j] && all<=b[j]){
					all-=w[j];
					used[j]=true;
					break;
				}
			}
			if(j==n)break;
		}
		printf("%s\n",i==n?"Yes":"No");
	}
	return 0;
}