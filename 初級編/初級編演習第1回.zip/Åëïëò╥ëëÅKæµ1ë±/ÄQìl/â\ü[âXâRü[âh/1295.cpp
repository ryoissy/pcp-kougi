#include <cstdio>
#include <cstring>

int w,d;
int h[2][11];
bool used[13];
int main(void){
	while(1){
		scanf("%d %d",&w,&d);
		if(w+d==0)break;
		for(int i=0;i<w;i++){
			scanf("%d",&h[0][i]);
		}
		for(int i=0;i<d;i++){
			scanf("%d",&h[1][i]);
		}
		memset(used,false,sizeof(used));
		if(w>=d){
			int res=0;
			for(int i=0;i<w;i++){
				res+=h[0][i];
				for(int j=0;j<d;j++){
					if(!used[j] && h[1][j]==h[0][i]){
						used[j]=true;
						break;
					}
				}
			}
			for(int i=0;i<d;i++){
				if(!used[i])res+=h[1][i];
			}
			printf("%d\n",res);
		}else{
			int res=0;
			for(int i=0;i<d;i++){
				res+=h[1][i];
				for(int j=0;j<w;j++){
					if(!used[j] && h[0][j]==h[1][i]){
						used[j]=true;
						break;
					}
				}
			}
			for(int i=0;i<w;i++){
				if(!used[i])res+=h[0][i];
			}
			printf("%d\n",res);
		}
	}
	return 0;
}