#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>

using namespace std;

int w,h;
int fie[60][60];
int painted[60][60][2];
int res[2];
int sx[4]={1,0,-1,0};
int sy[4]={0,1,0,-1};

void paint(int x,int y,int c){
	for(int i=0;i<4;i++){
		int nx=x+sx[i],ny=y+sy[i];
		if(nx>=0 && nx<w && ny>=0 && ny<h){
			if(fie[nx][ny]==0 && painted[nx][ny][c]==0){
				painted[nx][ny][c]=1;
				paint(nx,ny,c);
			}
		}
	}
}

int main(void){
	while(1){
		scanf("%d %d",&w,&h);
		if(w+h==0)break;
		for(int i=0;i<h;i++){
			string str;
			cin >> str;
			for(int j=0;j<w;j++){
				if(str[j]=='B')fie[j][i]=1;
				if(str[j]=='W')fie[j][i]=2;
				if(str[j]=='.')fie[j][i]=0;
			}
		}
		memset(painted,0,sizeof(painted));
		for(int i=0;i<h;i++){
			for(int j=0;j<w;j++){
				if(fie[j][i]==1)paint(j,i,0);
				if(fie[j][i]==2)paint(j,i,1);
			}
		}
		res[0]=res[1]=0;
		for(int i=0;i<h;i++){
			for(int j=0;j<w;j++){
				if(painted[j][i][0]==1 && painted[j][i][1]==0)res[0]++;
				if(painted[j][i][0]==0 && painted[j][i][1]==1)res[1]++;
			}
		}
		printf("%d %d\n",res[0],res[1]);
	}
	return 0;
}