#include <cstdio>
#include <string>
#include <iostream>
#include <algorithm>
#define INF 1e7
using namespace std;
int dp[100001][2];

int main(void){
	while(1){
		string str;
		cin >> str;
		if(str=="#")break;
		int cnt=0,cnt2=0;
		int now=0;
		for(int i=0;i<=str.size();i++){
			dp[i][0]=dp[i][1]=INF;
		}
		dp[1][0]=0;
		dp[1][1]=0;
		for(int i=1;i<str.size();i++){
			for(int j=0;j<2;j++){
				if(dp[i][j]!=INF){
					dp[i+1][j]=min(dp[i+1][j],dp[i][j]+1);
					if(j==0 && (str[i]-'0'+2)%3>=(str[i-1]-'0'+2)%3){
						dp[i+1][1]=min(dp[i+1][1],dp[i][j]);
					}
					if(j==1 && (str[i]-'0'+2)%3<=(str[i-1]-'0'+2)%3){
						dp[i+1][0]=min(dp[i+1][0],dp[i][j]);
					}
				}
			}		}
		printf("%d\n",min(dp[str.size()][0],dp[str.size()][1]));
	}
	return 0;
}