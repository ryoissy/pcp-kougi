#include <cstdio>
#include <algorithm>
#define MOD 1000000007LL
using namespace std;
typedef long long ll;

int n;
ll a[100001];
ll cnt[100001];
ll p2[100001];

ll mod_pow(ll b,ll k){
	ll ans=1;
	ll x=b;
	while(k>0){
		if(k&1)ans=ans*x%MOD;
		x=x*x%MOD;
		k/=2;
	}
	return ans;
}

int main(void){
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%lld",&a[i]);
		cnt[a[i]]++;
	}
	p2[0]=1;
	p2[1]=2;
	for(int i=2;i<=100000;i++){
		p2[i]=p2[i-1]*2LL%MOD;
	}
	if(a[0]!=0 || cnt[0]>=2){
		printf("0\n");
		return 0;
	}
	ll res=1;
	for(int i=1;i<=100000;i++){
		if(cnt[i]>=1){
			res=(res*mod_pow((p2[cnt[i-1]]-1),cnt[i]))%MOD;
			if(cnt[i]>=2)res=(res*mod_pow(2,(cnt[i]-1LL)*cnt[i]/2LL))%MOD;
		}
	}
	printf("%lld\n",res);
	return 0;
}