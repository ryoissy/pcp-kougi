#include<cstdio>

int n,cnt;
int prime[300001];
int data[3000];
int main(void){
	for(int i=2;i<=300000;i++){
		if(i%7!=1 && i%7!=6)continue;
		for(int j=i*2;j<=300000;j+=i)prime[j]=1;
	}
	while(1){
		scanf("%d",&n);
		if(n==1)break;
		printf("%d: ",n);
		cnt=0;
		int j=1;
		while(j<n){
			j++;
			if(j%7!=1 && j%7!=6)continue;
			if(n%j==0 && prime[j]==0)data[cnt++]=j;
		}
		for(int i=0;i<cnt;i++)printf("%d%c",data[i],i==cnt-1?'\n':' ');
	}
	return 0;
}