#include <cstdio>
#include <cstring>
#include <cmath>
using namespace std;

int n;
int dp[16][4][4];
int dx[4]={1,0,-1,0};
int dy[4]={0,1,0,-1};
int fie[4][4];
int main(void){
	while(1){
		scanf("%d%*c",&n);
		if(n==0)break;
		char a,b,c;
		scanf("%c %c %c",&a,&b,&c);
		memset(dp,0,sizeof(dp));
		dp[0][(a-'A')%3][(a-'A')/3]=1;
		memset(fie,0,sizeof(fie));
		fie[(c-'A')%3][(c-'A')/3]=-1;
		for(int i=0;i<n;i++){
			for(int j=0;j<3;j++){
				for(int k=0;k<3;k++){
					if(dp[i][j][k]>=1){
						for(int l=0;l<4;l++){
							int nx=j+dx[l],ny=k+dy[l];
							if(nx>=0 && nx<3 && ny>=0 && ny<3 && fie[nx][ny]==0){
								dp[i+1][nx][ny]+=dp[i][j][k];
							}else dp[i+1][j][k]+=dp[i][j][k];
						}
					}
				}
			}
		}
		printf("%.10f\n",(double)dp[n][(b-'A')%3][(b-'A')/3]/pow(4,n));
	}
	return 0;
}