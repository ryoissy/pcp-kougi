#include<cstdio>

int gcd(int a,int b){
	if(b==0)return a;
	return gcd(b,a%b);
}

int p,q,a,n,cnt;

void dfs(int v,int l,int r,int now){
	double dsum=(double)l/r;
	dsum+=(double)(n-v+1)/now;
	if((double)p/q>dsum)return;
	if(v!=0){
		int d=gcd(r,l);
		if(l/d==p && r/d==q){
			cnt++;
			return;
		}

	}
	if(v<n){
		for(int i=a/r;i>=now;i--){
			if((double)p/q<(double)(l*i+r)/(r*i))return;
			dfs(v+1,l*i+r,r*i,i);
		}
	}
}

int main(void){
	while(1){
		scanf("%d %d %d %d",&p,&q,&a,&n);
		if(p+q+a+n==0)break;
		int d=gcd(p,q);
		p/=d;
		q/=d;
		cnt=0;
		dfs(0,0,1,1);
		printf("%d\n",cnt);
	}
	return 0;
}