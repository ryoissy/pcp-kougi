#include<cstdio>
#include<vector>
#include<algorithm>
#include<string>
#include<iostream>

int n;
class data{
public:
	std::string l;
	int p,a,b,c,d,e,f,s,m;
	data(){}
	bool operator<(const data &d1)const{
		long long gm1=d1.f*d1.s*d1.m-d1.p,gm=f*s*m-p;
		long long t1=d1.a+d1.b+d1.c+(d1.d+d1.e)*d1.m;
		long long t=a+b+c+(d+e)*m;
		if(gm1*t==gm*t1)return l<d1.l;
		return gm*t1>gm1*t;
	}
};

std::vector<data> dat;

int main(void){
	while(1){
		scanf("%d",&n);
		if(n==0)break;
		dat.clear();
		for(int i=0;i<n;i++){
			data id;
			std::cin >> id.l >> id.p >> id.a >> id.b >> id.c >> id.d >> id.e >> id.f >> id.s  >> id.m;
			dat.push_back(id);
		}
		sort(dat.begin(),dat.end());
		for(int i=0;i<n;i++){
			std::cout << dat[i].l << std::endl;
		}
		std::cout << "#" << std::endl;
	}
	return 0;
}