#include <cstdio>
#include <cstring>
int n,a,b;
int dp[1500001];
int main(void){
	while(1){
		scanf("%d %d %d",&n,&a,&b);
		if(n+a+b==0)break;
		memset(dp,0,sizeof(dp));
		dp[0]=1;
		int cnt=-1;
		for(int i=0;i<=n;i++){
			if(dp[i]>0){
				cnt++;
				dp[i+a]=dp[i];
				dp[i+b]=dp[i];
			}
		}
		printf("%d\n",n-cnt);
	}
	return 0;
}