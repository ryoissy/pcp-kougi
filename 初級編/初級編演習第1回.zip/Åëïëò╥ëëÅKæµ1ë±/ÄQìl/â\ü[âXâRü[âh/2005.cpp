// 2005.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip> 
#include <complex> 
#include <string>
#include <vector> 
#include <list>
#include <deque> 
#include <stack> 
#include <queue> 
#include <set>
#include <map>
#include <bitset>
#include <functional>
#include <utility>
#include <algorithm> 
#include <numeric> 
#include <typeinfo> 
#include <cstdio>
#include <cstdlib> 
#include <cstring>
#include <cmath>
#include <climits> 
#include <ctime>

using namespace std;

const int INF=10000000;

int field[101][101];
int costs;
int s,g1,g2;
int n,m;
int f,t,c;

void root(){
	int a,b;
	field[f][t]=min(field[f][t],c);
	for(b=1;b<=n;b++){
		for(a=1;a<=n;a++){
			field[a][b]=min(field[a][b],field[a][f]+field[f][t]+field[t][b]);
		}
	}
	for(a=1;a<=n;a++){
		costs=min(costs,field[s][a]+field[a][g1]+field[a][g2]);
	}
}

int main(void){
	int a,b;
	while(1){
		for(b=0;b<=100;b++){
			for(a=0;a<=100;a++){
				field[a][b]=INF;
				if(a==b)field[a][b]=0;
			}
		}
		costs=INF;
		cin >> n >> m >> s >> g1 >> g2;
		if(n==0 && m==0 && s==0 && g1==0 && g2==0)break;
		for(a=0;a<m;a++){
			cin >> f >> t >> c;
			root();
		}
		cout << costs << endl;
	}
	return 0;
}