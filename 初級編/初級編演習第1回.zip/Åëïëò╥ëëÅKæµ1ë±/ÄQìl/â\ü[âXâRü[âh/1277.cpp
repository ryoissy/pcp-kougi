#include <cstdio>
#include <cstring>

int n,t,l,b;
int fie[101];
double dp[102][101];
int main(void){
	while(1){
		scanf("%d %d %d %d",&n,&t,&l,&b);
		if(n+t+l+b==0)break;
		memset(fie,0,sizeof(fie));
		memset(dp,0,sizeof(dp));
		for(int i=0;i<l;i++){
			int a;
			scanf("%d",&a);
			fie[a]=1;
		}
		for(int i=0;i<b;i++){
			int a;
			scanf("%d",&a);
			fie[a]=2;
		}
		dp[0][0]=1.0;
		for(int i=0;i<t;i++){
			for(int j=0;j<n;j++){
				if(dp[i][j]>0.0){
					for(int k=1;k<=6;k++){
						int next=j+k;
						if(next>=n)next=n*2-next;
						if(fie[next]==0)dp[i+1][next]+=dp[i][j]/6.0;
						if(fie[next]==1)dp[i+2][next]+=dp[i][j]/6.0;
						if(fie[next]==2)dp[i+1][0]+=dp[i][j]/6.0;
					}
				}
			}
			dp[i+1][n]+=dp[i][n];
		}
		printf("%.10f\n",dp[t][n]);
	}
	return 0;
}