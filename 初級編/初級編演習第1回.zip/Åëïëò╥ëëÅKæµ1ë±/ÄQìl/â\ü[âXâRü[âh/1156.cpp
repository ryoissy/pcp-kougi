#include<cstdio>
#include<algorithm>
#include<functional>
#include<queue>
#include<cstring>

using namespace std;

class data{
public:
	int x,y,c,w;
	bool operator<(const data &d)const{
		return d.c<c;
	}
};

int w,h;
int fie[31][31];
int dp[31][31][4];
int c[5];
int sx[4]={1,0,-1,0};
int sy[4]={0,1,0,-1};
int dijk(){
	priority_queue<data> que;
	data ind;
	memset(dp,-1,sizeof(dp));
	ind.x=0,ind.y=0,ind.c=0,ind.w=0;
	que.push(ind);
	while(que.size()){
		data d=que.top();
		que.pop();
		if(dp[d.x][d.y][d.w]!=-1 && dp[d.x][d.y][d.w]<d.c)continue;
		if(d.x==w-1 && d.y==h-1)return d.c;
		dp[d.x][d.y][d.w]=d.c;
		for(int i=0;i<4;i++){
			data nd=d;
			if(fie[d.x][d.y]!=i)nd.c+=c[i];
			nd.w=(nd.w+i)%4;
			nd.x+=sx[nd.w];
			nd.y+=sy[nd.w];
			if(nd.x>=0 && nd.x<w && nd.y>=0 && nd.y<h){
				if(dp[nd.x][nd.y][nd.w]>nd.c || dp[nd.x][nd.y][nd.w]==-1){
					dp[nd.x][nd.y][nd.w]=nd.c;
					que.push(nd);
				}
			}
		}
	}
	return -1;
}

int main(void){
	while(1){
		scanf("%d %d",&w,&h);
		if(w+h==0)break;
		for(int i=0;i<h;i++){
			for(int j=0;j<w;j++){
				scanf("%d",&fie[j][i]);
			}
		}
		for(int i=0;i<4;i++){
			scanf("%d",&c[i]);
		}
		printf("%d\n",dijk());
	}
	return 0;
}