#include <cstdio>
#include <string>
#include <iostream>
#include <cstring>
using namespace std;

int w,h;
char fie[72][72];
string str[72][72];

int main(void){
	while(1){
		scanf("%d %d",&w,&h);
		if(w+h==0)break;
		for(int i=0;i<h;i++){
			string in;
			cin >> in;
			for(int j=0;j<w;j++){
				fie[j][i]=in[j];
				str[j][i]="";
			}
		}
		string res="";
		for(int i=0;i<h;i++){
			for(int j=0;j<w;j++){
				if(str[j][i]=="" && fie[j][i]=='0')continue;
				if(fie[j][i]>='0' && fie[j][i]<='9'){
					str[j][i]+=fie[j][i];
				}else continue;
				if(res.size()<str[j][i].size() || (res.size()==str[j][i].size() && res<str[j][i])){
					res=str[j][i];
				}
				if(str[j+1][i].size()<str[j][i].size() || (str[j+1][i].size()==str[j][i].size() && str[j+1][i]<str[j][i])){
					str[j+1][i]=str[j][i];
				}
				if(str[j][i+1].size()<str[j][i].size() || (str[j][i+1].size()==str[j][i].size() && str[j][i+1]<str[j][i])){
					str[j][i+1]=str[j][i];
				}
			}
		}
		cout << res << endl;
	}
	return 0;
}