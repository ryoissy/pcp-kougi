#include<cstdio>
#include<queue>
#include<algorithm>
#include<functional>
#include<vector>
#include<cstring>

using namespace std;
class data{
public:
	int t,c,d;

};

class data2{
public:
	double cost;
	int v,s,p;
	bool operator<(const data2 &d1)const{
		return d1.cost<cost;
	}
};

int n,m,s,g;
double dp[35][35][35];
vector<data> edge[35];

double dijk(){
	for(int i=0;i<35;i++){
		for(int j=0;j<35;j++){
			for(int k=0;k<35;k++){
				dp[i][j][k]=-1.0;
			}
		}
	}
	priority_queue<data2> que;
	data2 ind;
	ind.cost=0.0;
	ind.v=s;
	ind.s=0;
	ind.p=0;
	double res=-1.0;
	dp[s][0][0]=0.0;
	que.push(ind);
	while(que.size()){
		data2 dd=que.top();
		que.pop();
		if(dp[dd.v][dd.s][dd.p]<dd.cost)continue;
		if(dd.v==g && dd.s==1){
			res=min(dd.cost,res);
			if(res==-1.0)res=dd.cost;
			continue;
		}
		dp[dd.v][dd.s][dd.p]=dd.cost;
		for(int i=0;i<edge[dd.v].size();i++){
			data e=edge[dd.v][i];
			if(dd.p==e.t)continue;
			for(int j=-1;j<=1;j++){
				int ns=dd.s+j;
				if(ns<=0 || ns>e.c)continue;
				double nc=dd.cost+(double)e.d/ns;
				if(dp[e.t][ns][dd.v]>nc || dp[e.t][ns][dd.v]==-1.0){
					dp[e.t][ns][dd.v]=nc;
					data2 nd;
					nd.v=e.t;
					nd.cost=nc;
					nd.s=ns;
					nd.p=dd.v;
					que.push(nd);
				}
			}
		}
	}
	return res;
}

int main(void){
	while(1){
		scanf("%d %d",&n,&m);
		if(n+m==0)break;
		for(int i=0;i<=n;i++)edge[i].clear();
		scanf("%d %d",&s,&g);
		for(int i=0;i<m;i++){
			int x,y;
			data dd;
			scanf("%d %d %d %d",&x,&y,&dd.d,&dd.c);
			dd.t=y;
			edge[x].push_back(dd);
			dd.t=x;
			edge[y].push_back(dd);
		}
		double res=dijk();
		if(res!=-1.0)printf("%.9f\n",res);
		else printf("unreachable\n");
	}
	return 0;
}