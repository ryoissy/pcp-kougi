#include <cstdio>
#include <cstring>
#include <vector>
using namespace std;
bool prime[10001];
int res[10001];
vector<int> pid;
int main(void){
	memset(prime,true,sizeof(prime));
	prime[0]=prime[1]=false;
	for(int i=2;i<=10000;i++){
		if(prime[i]){
			pid.push_back(i);
			for(int j=i*2;j<=10000;j+=i)prime[j]=false;
		}
	}
	pid.push_back(10001);
	for(int n=1;n<=10000;n++){
		for(int i=0;pid[i]<=n;i++){
			if(prime[pid[i]] && prime[n-pid[i]+1])res[n]++;
		}
	}
	int n;
	while(~scanf("%d",&n)){
		int cnt=0;
		printf("%d\n",res[n]);
	}
	return 0;
}