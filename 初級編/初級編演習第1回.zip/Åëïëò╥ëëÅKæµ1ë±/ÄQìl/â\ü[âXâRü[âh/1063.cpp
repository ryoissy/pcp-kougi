#include <cstdio>
#include <cstring>
#include <set>
#include <iostream>
#include <algorithm>
#include <string>
using namespace std;

int n,p;
struct data{
	string name;
	int h,m;
	data(){}
	data(string s,int hh,int mm){
		name=s;
		h=hh;
		m=mm;
	}
};

bool comp(const data& d1,const data& d2){
	if(d1.h==d2.h)return d1.m<d2.m;
	return d1.h<d2.h;
}

data d[7][501];
int dcnt[7];
set<string> fav;
bool used[7][30][61];

bool check(){
	for(int i=0;i<7;i++){
		for(int j=0;j<dcnt[i];j++){
			if(fav.find(d[i][j].name)!=fav.end()){
				int k=0,nh=d[i][j].h,nm=d[i][j].m;
				while(k<30){
					if(used[i][nh][nm])return false;
					used[i][nh][nm]=true;
					k++;
					nm++;
					if(nm==60){
						nm=0;
						nh++;
					}
				}
			}
		}
	}
	return true;
}
int main(void){
	while(1){
		scanf("%d",&n);
		if(n==0)break;
		memset(dcnt,0,sizeof(dcnt));
		for(int i=0;i<n;i++){
			int w,s;
			string str;
			cin >> str >> w >> s;
			d[w][dcnt[w]]=data(str,s/100,s%100);
			dcnt[w]++;
		}
		fav.clear();
		scanf("%d",&p);
		for(int i=0;i<p;i++){
			string str;
			cin >> str;
			fav.insert(str);
		}
		memset(used,false,sizeof(used));
		if(!check()){
			printf("-1\n");
			continue;
		}
		int cnt=0;
		for(int i=0;i<7;i++){
			sort(d[i],d[i]+dcnt[i],comp);
			for(int j=0;j<dcnt[i];j++){
				if(fav.find(d[i][j].name)!=fav.end())continue;
				int k=0,nh=d[i][j].h,nm=d[i][j].m;
				while(k<30){
					if(used[i][nh][nm])break;
					k++;
					nm++;
					if(nm==60){
						nm=0;
						nh++;
					}
				}
				if(k==30){
					k=0,nh=d[i][j].h,nm=d[i][j].m;
					cnt++;
					while(k<30){
						if(used[i][nh][nm])return false;
						used[i][nh][nm]=true;
						k++;
						nm++;
						if(nm==60){
							nm=0;
							nh++;
						}
					}
				}
			}
		}
		printf("%d\n",cnt+p);
	}
	return 0;
}