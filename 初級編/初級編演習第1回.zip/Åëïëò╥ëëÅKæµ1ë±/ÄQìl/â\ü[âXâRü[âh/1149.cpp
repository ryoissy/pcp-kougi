#include<cstdio>
#include<algorithm>

using namespace std;
int n,w,d,cnt;
int p[101],s[101];
int pw[201],pd[201];
int sq[101];

int main(void){
	while(1){
		scanf("%d %d %d",&n,&w,&d);
		if(n+w+d==0)break;
		cnt=1;
		for(int i=0;i<n;i++){
			scanf("%d %d",&p[i],&s[i]);
			p[i]--;
		}

		pw[0]=w,pd[0]=d;
		for(int i=0;i<n;i++){
			int j=0;
			while(1){
				if(j%2==0){
					if(s[i]-pw[p[i]]>=0)s[i]-=pw[p[i]];
					else break;
				}else{
					if(s[i]-pd[p[i]]>=0)s[i]-=pd[p[i]];
					else break;
				}
				j=(j+1)%4;
			}
			if(j==0){
				pd[cnt]=pd[cnt+1]=pd[p[i]];
				pw[cnt]=s[i];
				pw[cnt+1]=pw[p[i]]-s[i];
			}
			if(j==1){
				pw[cnt]=pw[cnt+1]=pw[p[i]];
				pd[cnt]=s[i];
				pd[cnt+1]=pd[p[i]]-s[i];
			}
			if(j==2){
				pd[cnt]=pd[cnt+1]=pd[p[i]];
				pw[cnt]=pw[p[i]]-s[i];
				pw[cnt+1]=s[i];
			}
			if(j==3){
				pw[cnt]=pw[cnt+1]=pw[p[i]];
				pd[cnt]=pd[p[i]]-s[i];
				pd[cnt+1]=s[i];
			}
			if(pw[cnt]*pd[cnt]>pw[cnt+1]*pd[cnt+1])swap(pw[cnt],pw[cnt+1]),swap(pd[cnt],pd[cnt+1]);
			for(int j=p[i];j<=cnt;j++){
				pd[j]=pd[j+1];
				pw[j]=pw[j+1];
			}
			cnt++;
		}
		for(int i=0;i<cnt;i++)sq[i]=pd[i]*pw[i];
		sort(sq,sq+cnt);
		for(int i=0;i<cnt;i++)printf("%d%c",sq[i],i==cnt-1?'\n':' ');
	}
	return 0;
}