#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

using namespace std;

int M,T,P,R;
int m[2000],t[2000],p[2000],j[2000];
struct team{
	int n,s,t,w[2000];
};

bool comp(const team &t1,const team &t2){
	if(t1.t==t2.t && t1.s==t2.s)return t1.n>t2.n;
	if(t1.s==t2.s)return t1.t<t2.t;
	return t1.s>t2.s;
};

team dat[2001];

int main(void){
	while(1){
		scanf("%d%d%d%d",&M,&T,&P,&R);
		if(M+T+R+P==0)break;
		memset(dat,0,sizeof(dat));
		for(int i=0;i<T;i++)dat[i].n=i+1;
		for(int i=0;i<R;i++){
			scanf("%d%d%d%d",&m[i],&t[i],&p[i],&j[i]);
			if(j[i]!=0){
				dat[t[i]-1].w[p[i]]++;
			}else{
				dat[t[i]-1].s++;
				dat[t[i]-1].t+=m[i]+dat[t[i]-1].w[p[i]]*20;
			}
		}
		sort(dat,dat+T,comp);
		printf("%d",dat[0].n);
		for(int i=1;i<T;i++){
			if(dat[i-1].s==dat[i].s && dat[i-1].t==dat[i].t)printf("=");
			else printf(",");
			printf("%d",dat[i].n);
		}
		printf("\n");
	}
	return 0;
}