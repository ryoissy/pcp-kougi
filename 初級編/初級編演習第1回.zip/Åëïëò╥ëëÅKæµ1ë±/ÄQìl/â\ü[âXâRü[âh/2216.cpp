#include <cstdio>

int c[3]={1000,500,100};
int cnt[3];
int main(void){
	while(1){
		int a,b;
		scanf("%d %d",&a,&b);
		if(a+b==0)break;
		int rest=b-a;
		for(int i=0;i<3;i++){
			cnt[i]=0;
			while(rest>=c[i]){
				cnt[i]++;
				rest-=c[i];
			}
		}
		printf("%d %d %d\n",cnt[2],cnt[1],cnt[0]);
	}
	return 0;
}