#include<cstdio>
#include<queue>
#include<cstring>

int t,n;
int fie[120][120];
bool used[120][120];
int dx[6]={1,1,0,0,-1,-1};
int dy[6]={1,0,1,-1,0,-1};
int sx,sy;
class data{
public:
	int x,y,t;
	data(){}
	data(int ix,int iy,int it){
		x=ix;
		y=iy;
		t=it;
	}
};

int bfs(){
	std::queue<data> que;
	memset(used,false,sizeof(used));
	que.push(data(sx,sy,0));
	used[sx][sy]=true;
	int res=1;
	while(que.size()){
		data d=que.front();
		que.pop();
		if(d.t==t)continue;
		for(int i=0;i<6;i++){
			int nx=d.x+dx[i],ny=d.y+dy[i];
			//if(nx<5 || nx>=66 || ny<5 || ny>=66)continue;
			if(!used[nx][ny] && fie[nx][ny]==0){
				used[nx][ny]=true;
				res++;
				que.push(data(nx,ny,d.t+1));
			}
		}
	}
	return res;
}

int main(void){
	while(1){
		scanf("%d %d",&t,&n);
		if(t+n==0)break;
		memset(fie,0,sizeof(fie));
		for(int i=0;i<n;i++){
			int bx,by;
			scanf("%d %d",&bx,&by);
			bx+=60;
			by+=60;
			fie[bx][by]=-1;
		}
		scanf("%d %d",&sx,&sy);
		sx+=60,sy+=60;
		printf("%d\n",bfs());
	}
	return 0;
}