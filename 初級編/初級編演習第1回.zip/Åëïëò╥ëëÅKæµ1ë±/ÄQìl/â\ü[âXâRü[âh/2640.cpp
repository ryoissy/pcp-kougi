#include <cstring>
#include <string>
#include <iostream>
#include <algorithm>
#include <queue>
#include <functional>
#include <cstdio>
#define INF 1e7
using namespace std;

class data{
public:
	int x,y,dir,dir2,c;
	data(){}
	data(int xx,int yy,int dd,int dd2,int cc){
		x=xx;
		y=yy;
		dir=dd;
		dir2=dd2;
		c=cc;
	}
	bool operator<(const data& d1)const{
		return c>d1.c; 
	}
};

struct edge{
	int x,y,dir,dir2,c;
	edge(){}
	edge(int xx,int yy,int dd,int dd2,int cc){
		x=xx;
		y=yy;
		dir=dd;
		dir2=dd2;
		c=cc;
	}
};

const char* dir="^>v<";
int n,m;
int fie[55][55];
int dx[4]={0,1,0,-1};
int dy[4]={-1,0,1,0};
int bx[4][4]={
	{1,1,1,0},
	{0,1,1,-1},
	{-1,-1,-1,0},
	{0,-1,-1,1}
};

int by[4][4]={
	{0,-1,1,-1},
	{1,1,0,1},
	{0,-1,1,1},
	{-1,0,-1,-1}
};

int sx,sy,sdir;
vector<edge> G[55][55][4][4];
bool used[55][55][4][4];
int uses[55][55];

int dfs(int x,int y,int dir,int dir2,int c){
	used[x][y][dir][dir2]=true;
	uses[x][y]++;
	if(fie[x][y]==1)return c;
	for(int i=0;i<G[x][y][dir][dir2].size();i++){
		edge e=G[x][y][dir][dir2][i];
		if(!used[e.x][e.y][e.dir][e.dir2]){
			if(e.c==1 && uses[e.x][e.y]==0){
				//printf("%d %d %d %d %d\n",e.x,e.y,e.dir,e.dir2,c+1);
				int res=dfs(e.x,e.y,e.dir,e.dir2,c+1);
				if(res>=1)return res;
			}else{
				//printf("%d %d %d %d %d\n",e.x,e.y,e.dir,e.dir2,c+1);
				int res=dfs(e.x,e.y,e.dir,e.dir2,c);
				if(res>=1)return res;
			}
		}
	}
	uses[x][y]--;
	return -1;
}

int solve(){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(fie[j][i]==-1)continue;
			for(int k=0;k<4;k++){
				for(int l=0;l<4;l++){
					int nx=j+dx[k],ny=i+dy[k];
					if(nx>=1 && nx<=m && ny>=1 && ny<=n){
						for(int b=0;b<4;b++){
							if(j+bx[k][l]==nx+bx[k][b] && i+by[k][l]==ny+by[k][b]){
								G[j][i][k][l].push_back(edge(nx,ny,k,b,1));
							}
						}
					}
					for(int b=0;b<4;b++){
						if(bx[k][l]==bx[(k+1)%4][b] && by[k][l]==by[(k+1)%4][b]){
							G[j][i][k][l].push_back(edge(j,i,(k+1)%4,b,0));
						}
						if(bx[k][l]==bx[(k+3)%4][b] && by[k][l]==by[(k+3)%4][b]){
							G[j][i][k][l].push_back(edge(j,i,(k+3)%4,b,0));
						}
					}
					for(int a=0;a<4;a++){
						if(fie[j+bx[k][a]][i+by[k][a]]==-1 && abs(bx[k][a]-bx[k][l])<=1 && abs(by[k][a]-by[k][l])<=1){
							G[j][i][k][l].push_back(edge(j,i,k,a,0));
						}
					}
				}
			}
		}
	}
	memset(used,0,sizeof(used));
	return dfs(sx,sy,sdir,0,1);
}

int main(void){
	scanf("%d %d",&n,&m);
	memset(fie,-1,sizeof(fie));
	for(int i=1;i<=n;i++){
		string str;
		cin >> str;
		for(int j=1;j<=m;j++){
			for(int k=0;k<4;k++){
				if(dir[k]==str[j-1]){
					sx=j;
					sy=i;
					sdir=k;
					fie[j][i]=0;
				}
			}
			if(str[j-1]=='#')fie[j][i]=-1;
			if(str[j-1]=='.')fie[j][i]=0;
			if(str[j-1]=='G')fie[j][i]=1;
		}
	}
	printf("%d\n",solve());
	return 0;
}