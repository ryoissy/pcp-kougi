#include <iostream>
#include <cstdio>
#include <string>
using namespace std;

int main(void){
	string str;
	cin >> str;
	if(str.size()==1){
		cout << str[0] << endl;
	}else{
		if(str[0]=='o' && str[str.size()-1]=='o')cout << "o" << endl;
		if(str[0]=='x' && str[str.size()-1]=='x')cout << "x" << endl;
		if(str[0]!=str[str.size()-1])cout << "o" << endl;
	}
    return 0;
}
