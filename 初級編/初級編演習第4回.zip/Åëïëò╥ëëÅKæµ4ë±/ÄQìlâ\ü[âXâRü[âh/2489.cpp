#include <cstdio>
#include <string>
#include <iostream>
#include <algorithm>
#include <sstream>
using namespace std;

int n;

int main(void){
	scanf("%d",&n);
	stringstream ss;
	int a=n,b=n;
	while(1){
		if(a>=0){
			ss << a;
			string l=ss.str();
			string r=ss.str();
			ss.str("");
			reverse(r.begin(),r.end());
			if(l==r){
				printf("%d\n",a);
				return 0;
			}
		}
		a--;

		ss << b;
		string l=ss.str();
		string r=ss.str();
		ss.str("");
		reverse(r.begin(),r.end());
		if(l==r){
			printf("%d\n",b);
			return 0;
		}
		b++;
	}
	return 0;
}