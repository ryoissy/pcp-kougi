#include <cstdio>

int n;

int main(void){
	scanf("%d%*c",&n);
	int left=0;
	for(int i=0;i<n;i++){
		char p;
		int x;
		scanf("%c %d%*c",&p,&x);
		if(p=='('){
			left+=x;
		}else left-=x;
		if(left<0){
			printf("NO\n");
			return 0;
		}
	}
	printf("%s\n",left==0?"YES":"NO");
	return 0;
}