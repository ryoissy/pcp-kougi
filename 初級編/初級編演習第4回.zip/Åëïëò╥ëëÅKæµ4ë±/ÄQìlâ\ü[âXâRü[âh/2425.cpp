#include <cstdio>
#include <cstring>
#include <vector>
#include <queue>
#include <algorithm>
#define INF 1e9
using namespace std;

class data{
public:
	int x,y,t;
	data(){}
	data(int xx,int yy,int tt){
		x=xx;
		y=yy;
		t=tt;
	}
};

int dx[6]={0,1,1,0,-1,-1};
int dy[2][6]={
	1,0,-1,-1,-1,0,
	1,1,0,-1,0,1
};
int sx,sy,gx,gy;
int n;
int lx,ly;
int fie[201][201];
int dp[201][201][6];

int bfs(){
	for(int i=0;i<=200;i++){
		for(int j=0;j<=200;j++){
			for(int k=0;k<6;k++){
				dp[i][j][k]=INF;
			}
		}
	}
	queue<data> que;
	que.push(data(sx+100,sy+100,0));
	dp[sx+100][sy+100][0]=0;
	while(que.size()){
		queue<data> que2;
		while(que.size()){
			data q=que.front();
			que.pop();
			if(q.x-100==gx && q.y-100==gy)return dp[q.x][q.y][q.t];
			que2.push(q);
			bool flag=true;
			while(flag){
				flag=false;
				int sdir=abs((q.x-100)*(q.y-100)*q.t)%6;
				int nx=q.x+dx[sdir],ny=q.y+dy[q.x%2][sdir];
				if(nx>=100-lx && nx<=lx+100 && ny>=100-ly && ny<=100+ly){
					if(fie[nx][ny]!=-1 && dp[nx][ny][(q.t+1)%6]==INF){
						flag=true;
						if(nx-100==gx && ny-100==gy)return dp[q.x][q.y][q.t];
						que2.push(data(nx,ny,(q.t+1)%6));
						dp[nx][ny][(q.t+1)%6]=dp[q.x][q.y][q.t];
					}
				}
				q.x=nx;
				q.y=ny;
				q.t=(q.t+1)%6;
			}
		}
		while(que2.size()){
			data q=que2.front();
			que2.pop();
			if(dp[q.x][q.y][(q.t+1)%6]==INF){
				dp[q.x][q.y][(q.t+1)%6]=dp[q.x][q.y][q.t]+1;
				que.push(data(q.x,q.y,(q.t+1)%6));
			}
			for(int i=0;i<6;i++){
				int nx=q.x+dx[i],ny=q.y+dy[q.x%2][i];
				if(nx>=100-lx && nx<=lx+100 && ny>=100-ly && ny<=100+ly){
					if(fie[nx][ny]!=-1 && dp[nx][ny][(q.t+1)%6]==INF){
						dp[nx][ny][(q.t+1)%6]=dp[q.x][q.y][q.t]+1;
						que.push(data(nx,ny,(q.t+1)%6));
					}
				}
			}
		}
	}
	return -1;
}

int main(void){
	scanf("%d%d%d%d",&sx,&sy,&gx,&gy);
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		int x,y;
		scanf("%d %d",&x,&y);
		fie[x+100][y+100]=-1;
	}
	scanf("%d%d",&lx,&ly);
	printf("%d\n",bfs());
	return 0;
}