// 1995.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstdio>
using namespace std;

typedef long long ll;
int t;

ll mod_pow(ll x,ll n,ll mod){
	if(n==0)return 1;
	ll res=mod_pow(x*x%mod,n/2,mod);
	if(n & 1)res=res*x%mod;
	return res;
}

int main(void){
	scanf("%d",&t);
	for(int i=0;i<t;i++){
		ll m;
		int d;
		ll ans=0;
		scanf("%lld",&m);
		scanf("%d",&d);
		for(int j=0;j<d;j++){
			ll a,b;
			scanf("%lld%lld",&a,&b);
			ans=(ans+mod_pow(a,b,m))%m;
		}
		printf("%lld\n",ans);
	}
	return 0;
}
