// 3641.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstdio>
using namespace std;

typedef long long ll;
ll a,p;
bool prime=true;

ll mod_pow(ll x,ll n,ll mod){
	if(n==0)return 1;
	ll res=mod_pow(x*x%mod,n/2,mod);
	if(n & 1)res=res*x%mod;
	return res;
}

int main(void){
	while(1){
		scanf("%lld%lld",&p,&a);
		if(p==0 && a==0)break;
		prime=true;
		for(int i=2;i*i<=p;i++){
			if(p%i==0)prime=false;
		}
		if(!prime){
			ll ans=mod_pow(a,p,p);
			if(ans==a%p)cout << "yes" << endl;
			else cout << "no" << endl;
		}else cout << "no" << endl;
	}
    return 0;
}
