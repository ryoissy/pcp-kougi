// 3126.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<queue>
#include<map>
#include<sstream>
using namespace std;
typedef pair<int,int> P;
bool prime[10001];
int t,ans=10000;
map<int,int> num;

void seive(int s){
	for(int i=0;i<=s;i++)prime[i]=true;
	prime[0]=prime[1]=false;
	for(int i=2;i<=s;i++){
		if(prime[i])for(int j=i*2;j<=s;j+=i)prime[j]=false;
	}
}

int change(int x,int y,int num){
	int res;
	if(x==0){
		res=y*1000+num%1000;
	}
	if(x==1){
		res=num-num%1000+y*100+num%100;
	}
	if(x==2){
		res=num-num%100+num%10+y*10;
	}
	if(x==3){
		res=num-num%10+y;
	}
	return res;
}

int main(void){
	seive(10000);
	scanf("%d",&t);
	for(int d=0;d<t;d++){
		int f,t;
		num.clear();
		cin >> f >> t;
		queue<P> que;
		que.push(P(f,0));
		num[f]=1;
		while(que.size()){
			P p=que.front();que.pop();
			if(p.first==t){
				ans=p.second;
				break;
			}
			for(int i=0;i<4;i++){
				for(int j=0;j<=9;j++){
					if(i==0 && j==0)continue;
					int n2=change(i,j,p.first);
					if(prime[n2]==true && num[n2]==0){
						num[n2]=1;
						que.push(P(n2,p.second+1));
					}
				}
			}
		}
		printf("%d\n",ans);
	}
    return 0;
}
