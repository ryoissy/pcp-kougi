#include <cstdio>
#include <cstring>

int h;
bool prime[1000001];
bool prime2[1000001];
int cnt[1000001];
int main(void){
	memset(prime,true,sizeof(prime));
	memset(prime2,false,sizeof(prime2));
	prime[1]=false;
	for(int i=5;i<=2000;i+=4){
		if(prime[i]){
			for(int j=i*i;j<=1000001;j+=i*4){
				prime[j]=false;
			}
		}
	}
	for(int i=5;i<=2000;i+=4){
		if(prime[i]){
			for(int j=i*i;j<=1000001;j+=i*4){
				if(prime[j/i])prime2[j]=true;
			}
		}
	}
	for(int i=1;i<=1000001;i++){
		cnt[i]=cnt[i-1];
		if(prime2[i])cnt[i]++;
	}
	while(1){
		scanf("%d",&h);
		if(h==0)break;
		printf("%d %d\n",h,cnt[h]);
	}
	return 0;
}