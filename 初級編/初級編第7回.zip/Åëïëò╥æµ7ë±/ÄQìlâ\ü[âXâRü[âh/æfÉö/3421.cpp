#include <cstdio>
#include <cstring>

int x;
bool prime[20001];
int primenum[20001],pcnt;
int cnt[20001];

int main(void){
	memset(prime,true,sizeof(prime));
	prime[0]=prime[1]=false;
	for(int i=2;i<=5000;i++){
		if(prime[i]){
			primenum[pcnt]=i;
			pcnt++;
			for(int j=i*2;j<=5000;j+=i){
				prime[j]=false;
			}
		}
	}
	while(~scanf("%d",&x)){
		memset(cnt,0,sizeof(cnt));
		int allcnt=0,i=0;
		long long res=1;
		int c=0;
		for(i=0;i<pcnt;i++){
			while(x%primenum[i]==0){
				x/=primenum[i];
				cnt[i]++;
				allcnt++;
				res*=allcnt;
			}
			for(int j=1;j<=cnt[i];j++){
				res/=j;
			}
			c++;
		}
		if(x!=1){
			allcnt++;
			res*=allcnt;
		}
		printf("%d %lld\n",allcnt,res);
	}
	return 0;
}