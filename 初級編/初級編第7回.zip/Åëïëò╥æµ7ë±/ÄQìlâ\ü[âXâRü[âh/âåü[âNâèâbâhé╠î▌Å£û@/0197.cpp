// 0197.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>

using namespace std;

int step=0;

int gcd(int x,int y){
	if(y==0)return x;
	else{
		step++;
		return gcd(y,x%y);
	}
}

int main(void){
	int x,y,ans;
	while(1){
		scanf("%d%d",&x,&y);
		if(x==0 && y==0)break;
		step=0;
		if(x>y)ans=gcd(x,y);else ans=gcd(y,x);
		cout << ans << " " << step << endl;
	}
	return 0;
}