// 0568.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip> 
#include <complex> 
#include <string>
#include <vector> 
#include <list>
#include <deque> 
#include <stack> 
#include <queue> 
#include <set>
#include <map>
#include <bitset>
#include <functional>
#include <utility>
#include <algorithm> 
#include <numeric> 
#include <typeinfo> 
#include <cstdio>
#include <cstdlib> 
#include <cstring>
#include <cmath>
#include <climits> 
#include <ctime>

using namespace std;



int main(void){
	int dp[102][5][5],f[102];
	int n,k;
	int a,b,c;
	int x,y;
	for(a=0;a<102;a++){
		f[a]=0;
		for(b=0;b<5;b++){
			for(c=0;c<5;c++){
				dp[a][b][c]=0;
			}
		}
	}
	cin >> n >> k;
	for(a=0;a<k;a++){
		cin >> x >> y;
		f[x]=y;
	}
	if(f[1]!=0)dp[1][f[1]][1]=1;
	else dp[1][1][1]=dp[1][2][1]=dp[1][3][1]=1; 
	for(a=2;a<=n;a++){
		if(f[a]==0){
			dp[a][1][1]=(dp[a-1][2][1]+dp[a-1][2][2]+dp[a-1][3][1]+dp[a-1][3][2])%10000;
			dp[a][1][2]=dp[a-1][1][1]%10000;

			dp[a][2][1]=(dp[a-1][1][1]+dp[a-1][1][2]+dp[a-1][3][1]+dp[a-1][3][2])%10000;
			dp[a][2][2]=dp[a-1][2][1]%10000;

			dp[a][3][1]=(dp[a-1][1][1]+dp[a-1][1][2]+dp[a-1][2][1]+dp[a-1][2][2])%10000;
			dp[a][3][2]=dp[a-1][3][1]%10000;
		}else{
			dp[a][f[a]][2]=dp[a-1][f[a]][1]%10000;
			for(b=1;b<=3;b++){
				if(b!=f[a])dp[a][f[a]][1]+=(dp[a-1][b][1]+dp[a-1][b][2])%10000;

			}
		}
	}
	printf("%d\n",(dp[n][1][1]+dp[n][1][2]+dp[n][2][1]+dp[n][2][2]+dp[n][3][1]+dp[n][3][2])%10000);
	return 0;
}