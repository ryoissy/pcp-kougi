#include <iostream>
#include <cstring>
using namespace std;
 
int main(void){
    int a,b;
    int w,h;
    long int map[102][102][3][3];
    memset(map,0,sizeof(map));
    map[1][1][0][0]=1;
    for(a=1;a<=100;a++){
        for(b=1;b<=100;b++){
            map[a+1][b][1][0]=(map[a][b][0][2])%100000;
            map[a+1][b][2][0]=(map[a][b][0][0]+map[a][b][1][0]+map[a][b][2][0])%100000;
            map[a][b+1][0][1]=(map[a][b][2][0])%100000;
            map[a][b+1][0][2]=(map[a][b][0][0]+map[a][b][0][1]+map[a][b][0][2])%100000;
        }
    }
    while(1){
        cin >> w >> h;
        if(w==0 && h==0)break;
        cout << (map[w][h][1][0]+map[w][h][2][0]+map[w][h][0][1]+map[w][h][0][2])%100000 << endl;
    }
    return 0;
}