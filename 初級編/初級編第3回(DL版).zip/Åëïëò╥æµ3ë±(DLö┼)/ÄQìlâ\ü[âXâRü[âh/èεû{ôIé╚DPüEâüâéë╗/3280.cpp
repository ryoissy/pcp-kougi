#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>

using namespace std;

int n,m;
string str;
int c[30];
int d[2005][2005];


int main(void){
	scanf("%d%d",&n,&m);
	cin >> str;
	for(int i=0;i<n;i++){
		string s;
		int p,e;
		cin >> s >> p >> e;
		c[s[0]-'a']=min(p,e);
	}
	for(int i=m-1;i>=0;i--){
		for(int j=1;j<=m;j++){
			if(j-i<=0)d[i][j]=0;
			else if(str[i]==str[j])d[i][j]=d[i+1][j-1];
			else d[i][j]=min(d[i+1][j]+c[str[i]-'a'],d[i][j-1]+c[str[j]-'a']);
		}
	}
	printf("%d\n",d[0][m-1]);
	return 0;
}