#include <cstdio>
#include <cstring>

int n,m;
int d[1001],c[1001];

int dp[1001][1001];

int min(int a,int b){
	if(a>b)return b;
	return a;
}

int main(void){
	scanf("%d %d",&n,&m);
	for(int i=0;i<n;i++){
		scanf("%d",&d[i]);
	}
	for(int i=0;i<m;i++){
		scanf("%d",&c[i]);
	}
	memset(dp,-1,sizeof(dp));
	dp[0][0]=0;
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
			if(dp[i][j]>=0){
				dp[i][j+1]=min(dp[i][j+1],dp[i][j]);
				if(dp[i][j+1]==-1)dp[i][j+1]=dp[i][j];
				dp[i+1][j+1]=min(dp[i+1][j+1],dp[i][j]+d[i]*c[j]);
				if(dp[i+1][j+1]==-1)dp[i+1][j+1]=dp[i][j]+d[i]*c[j];
			}
		}
	}
	int res=dp[n][n];
	for(int i=n+1;i<=m;i++){
		res=min(res,dp[n][i]);
	}
	printf("%d\n",res);
	return 0;
}