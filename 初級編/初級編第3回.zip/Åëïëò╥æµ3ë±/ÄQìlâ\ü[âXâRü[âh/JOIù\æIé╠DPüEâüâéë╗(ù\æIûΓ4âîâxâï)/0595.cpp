#include<iostream>
#include<cstdio>
#include<string>
using namespace std;

int n;
int mod=10007;
string str;
int dp[1<<3][1001];
int bit[1001];
int main(void){
	scanf("%d",&n);
	cin >> str;
	for(int i=0;i<str.size();i++){
		if(str[i]=='J')bit[i]=0;
		if(str[i]=='O')bit[i]=1;
		if(str[i]=='I')bit[i]=2;
	}
	dp[1][0]=1;
	int res=0;
	for(int i=0;i<n;i++){
		for(int j=0;j<1<<3;j++){
			if(dp[j][i]>0){
				for(int k=0;k<1<<3;k++){
					bool flag=false;
					for(int l=0;l<3;l++){
						if((j>>l & 1) && (k>>l & 1))flag=true;
					}
					if(!flag)continue;
					if(k>>bit[i] & 1)dp[k][i+1]=(dp[k][i+1]+dp[j][i])%mod;
				}
			}
		}
	}
	for(int i=0;i<1<<3;i++)res=(res+dp[i][n])%mod;
	printf("%d\n",res);
	return 0;
}