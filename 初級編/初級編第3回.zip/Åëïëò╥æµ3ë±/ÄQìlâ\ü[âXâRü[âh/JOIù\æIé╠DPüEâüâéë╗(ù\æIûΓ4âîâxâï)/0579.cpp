#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip> 
#include <complex> 
#include <string>
#include <vector> 
#include <list>
#include <deque> 
#include <stack> 
#include <queue> 
#include <set>
#include <map>
#include <bitset>
#include <functional>
#include <utility>
#include <algorithm> 
#include <numeric> 
#include <typeinfo> 
#include <cstdio>
#include <cstdlib> 
#include <cstring>
#include <cmath>
#include <climits> 
#include <ctime>
using namespace std;
 
int d,n;
int hot[501];
int a[501],b[501],c[501];
int dp[501][501];
int main(void){
    scanf("%d%d",&d,&n);
    for(int i=0;i<d;i++)scanf("%d",&hot[i]);
    for(int i=0;i<n;i++)scanf("%d%d%d",&a[i],&b[i],&c[i]);
    memset(dp,-1,sizeof(dp));
    for(int i=0;i<n;i++){
        if(a[i]<=hot[0] && hot[0]<=b[i])dp[1][c[i]]=0;
    }
    for(int i=1;i<d;i++){
        for(int j=0;j<200;j++){
            if(dp[i][j]!=-1){
                for(int k=0;k<n;k++){
                    if(a[k]<=hot[i] && hot[i]<=b[k]){
                        dp[i+1][c[k]]=max(dp[i+1][c[k]],dp[i][j]+abs(c[k]-j));
                    }
                }
            }
        }
    }
    int res=0;
    for(int i=0;i<200;i++)res=max(res,dp[d][i]);
    printf("%d\n",res);
    return 0;
}