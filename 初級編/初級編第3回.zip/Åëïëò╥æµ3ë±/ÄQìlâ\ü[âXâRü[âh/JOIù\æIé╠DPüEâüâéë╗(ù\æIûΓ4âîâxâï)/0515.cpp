#include<stdio.h>
 
int main(){
    int a,b,c,d;
    int e,f,x,y;
    int map[17][17];
     
    while(1){
    for(y=0;y<=16;y++){          
        for(x=0;x<=16;x++){
            map[x][y]=0;
        }
    }
    map[1][1]=1;
    scanf("%d %d",&a,&b);
    if(a==0 && b==0)break;
    scanf("%d",&c);
    for(d=0;d<c;d++){
        scanf("%d %d",&e,&f);
        map[e][f]=-1;   
    }
    for(y=1;y<=b;y++){          
        for(x=1;x<=a;x++){
            if(map[x][y]>-1){
                if(map[x-1][y]>0)map[x][y]+=map[x-1][y];
                if(map[x][y-1]>0)map[x][y]+=map[x][y-1];
            }
        }
    }
    printf("%d\n",map[a][b]);
    }
    return 0;
} 