// 2385.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstdio>

using namespace std;

int tm,w;
int res=0;
int t[1001];
int dp[1001][31][2];

int main(void){
	scanf("%d%d",&tm,&w);
	for(int i=0;i<tm;i++){
		int a;
		scanf("%d",&a);
		t[i]=a-1;
	}
	for(int i=0;i<tm;i++){
		for(int j=0;j<=w;j++){
			dp[i+1][j][0]=dp[i][j][0];
			if(j>=1)dp[i+1][j][0]=max(dp[i+1][j][0],dp[i][j-1][1]);
			if(t[i]==0)dp[i+1][j][0]++;
			dp[i+1][j][1]=dp[i][j][1];
			if(j>=1)dp[i+1][j][1]=max(dp[i+1][j][1],dp[i][j-1][0]);
			if(t[i]==1)dp[i+1][j][1]++;
			res=max(res,max(dp[i+1][j][0],dp[i+1][j][1]));
		}
	}
	printf("%d\n",res);
    return 0;
}
