// 3616.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstdio>
#include<vector>
#include<algorithm>
#include<map>
using namespace std;
int n,m,r;
typedef pair<int,int> P;
typedef pair<P,int> PP;
vector<PP> milk;
long long dp[1002];
long long res=0;
int main(void){
	scanf("%d%d%d",&n,&m,&r);
	for(int i=0;i<m;i++){
		int s,t,e;
		scanf("%d%d%d",&s,&t,&e);
		milk.push_back(PP(P(s,t),e));
	}
	milk.push_back(PP(P(-r,-r),0));
	sort(milk.begin(),milk.end());
	for(int i=0;i<milk.size();i++){
		int is=milk[i].first.first,it=milk[i].first.second,ie=milk[i].second;
		for(int j=i+1;j<milk.size();j++){
			int js=milk[j].first.first,jt=milk[j].first.second,je=milk[j].second;
			if(js>=it+r)dp[j]=max(dp[j],dp[i]+je);
			res=max(res,dp[j]);
		}
	}
	printf("%lld\n",res);
    return 0;
}
