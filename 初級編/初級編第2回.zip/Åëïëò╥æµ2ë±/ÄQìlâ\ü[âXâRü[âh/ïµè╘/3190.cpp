#include<iostream>
#include<cstdio>
#include<queue>
#include<algorithm>
#include<functional>
#include<map>
using namespace std;

typedef pair<int,int> P;
typedef pair<P,int> PP;
int n;
vector<PP> v;
int ans[100000];
int main(void){
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		int f,t;
		scanf("%d%d",&f,&t);
		v.push_back(PP(P(f,t),i));
	}
	sort(v.begin(),v.end());
	int cnt=1;
	ans[v[0].second]=1;
	priority_queue<P, vector<P> , greater<P> > que;
	que.push(P(v[0].first.second,1));
	for(int i=1;i<n;i++){
		P p=que.top();
		if(p.first<v[i].first.first){
			ans[v[i].second]=p.second;
			que.pop();
			que.push(P(v[i].first.second,p.second));
		}else{
			cnt++;
			ans[v[i].second]=cnt;
			que.push(P(v[i].first.second,cnt));
		}
	}
	printf("%d\n",cnt);
	for(int i=0;i<n;i++)printf("%d\n",ans[i]);
	return 0;
}