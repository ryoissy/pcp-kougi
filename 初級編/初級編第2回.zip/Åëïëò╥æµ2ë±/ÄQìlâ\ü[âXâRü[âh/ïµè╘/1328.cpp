#include<cstdio>
#include<algorithm>
#include<cmath>
#include<vector>
#include<queue>

#define eps 1e-5
using namespace std;

int n;
double d;

class data{
public:
	double x,y;
	data(){}
	data(double ix,double iy){
		x=ix;
		y=iy;
	}
	bool operator<(const data &d1)const{
		if(d1.x==x)return d1.y<y;
		return x<d1.x;
	}
};

class query{
public:
	int v;
	double x;
	query(){}
	query(int vv,double xx){
		v=vv;
		x=xx;
	}
	bool operator<(const query &d1)const{
		return x<d1.x;
	}
};

data dat[2001];
double range[2001];
vector<query> que;

int main(void){
	int casenum=1;
	while(1){
		scanf("%d %lf",&n,&d);
		if(n+d==0)break;
		que.clear();
		int flag=0;
		for(int i=0;i<n;i++){
			scanf("%lf %lf",&dat[i].x,&dat[i].y);
			if(dat[i].y>d)flag=1;
			double ix=sqrt(d*d-dat[i].y*dat[i].y);
			range[i]=dat[i].x-ix;
			que.push_back(query(i,dat[i].x+ix));
		}
		if(flag==1){
			printf("Case %d: -1\n",casenum);
			casenum++;
			continue;
		}
		sort(que.begin(),que.end());
		int cnt=0;
		double ix=0;
		for(int i=0;i<que.size();i++){
			if(cnt==0 || ix<range[que[i].v]){
				ix=que[i].x;
				cnt++;
			}
		}
		printf("Case %d: %d\n",casenum,cnt);
		casenum++;
	}
	return 0;
}