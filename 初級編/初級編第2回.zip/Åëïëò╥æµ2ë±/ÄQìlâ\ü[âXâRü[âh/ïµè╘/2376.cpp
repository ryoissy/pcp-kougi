#include<iostream>
#include<cstdio>

using namespace std;

int n,t;
int dp[1000001];
bool flag=true;

int main(void){
	scanf("%d%d",&n,&t);
	for(int i=0;i<n;i++){
		int a,b;
		scanf("%d%d",&a,&b);
		dp[a]=max(dp[a],b);
	}
	for(int i=1;i<=t;i++){
		dp[i]=max(dp[i],dp[i-1]);
		if(dp[i]<i)flag=false;
		
	}
	if(flag){
		int cnt=0;
		int np=0;
		while(np<t){
			np=dp[np+1];
			cnt++;
		}
		cout << cnt << endl;
	}else cout << "-1" << endl; 
	return 0;
}



