#include<iostream>
#include<cstdio>

using namespace std;

typedef long long ll;
int n,s;
ll c[10001],y[10001];
ll ans;
int main(void){
	scanf("%d%d",&n,&s);
	for(int i=0;i<n;i++)scanf("%lld%lld",&c[i],&y[i]);
	ans=c[0]*y[0];
	
	int ic=c[0];
	for(int i=1;i<n;i++){
		if(s+ic>c[i])ic=c[i];
		else ic=s+ic;
		
		ans+=ic*y[i];
	}
	printf("%lld\n",ans);
	return 0;
}