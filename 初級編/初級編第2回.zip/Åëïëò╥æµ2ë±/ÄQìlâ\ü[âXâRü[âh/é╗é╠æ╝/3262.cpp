#include<iostream>
#include<cstdio>
#include<map>
#include<algorithm>
#include<functional>
using namespace std;
typedef long long ll;
typedef pair<double,int> P;
int n;
ll sum,res;
int t[100001],d[100001];
P h[100001];

int main(void){
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d%d",&t[i],&d[i]);
		t[i]*=2;
		sum+=d[i];
	}
	for(int i=0;i<n;i++){
		h[i].first=(double)t[i]/d[i];
		h[i].second=i;
	}
	sort(h,h+n);
	for(int i=0;i<n;i++){
		sum-=d[h[i].second];
		res+=sum*t[h[i].second];
	}
	cout << res << endl;
	return 0;
}