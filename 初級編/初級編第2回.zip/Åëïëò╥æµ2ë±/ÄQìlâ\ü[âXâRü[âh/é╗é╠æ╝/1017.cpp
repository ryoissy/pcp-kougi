#include<iostream>
#include<cstdio>

using namespace std;

typedef long long ll;

ll a[7];
ll sum;
ll cnt,cnt2;
ll three[4]={0,5,3,1};
ll thrp[4]={0,7,6,5};
int main(void){
	while(1){
		sum=0;
		cnt=0,cnt2=0;
		for(int i=1;i<=6;i++)scanf("%lld",&a[i]);
		if(a[1]==0 && a[2]==0 && a[3]==0 && a[4]==0 && a[5]==0 && a[6]==0)break;
		sum+=a[6];
		
		sum+=a[5];
		cnt=a[5]*11;
		if(a[1]<=cnt)a[1]=0,cnt=0;
		else a[1]-=cnt,cnt=0;
		cnt=0,cnt2=0;
		
		sum+=a[4];
		cnt2=a[4]*5;
		if(a[2]<=cnt2)cnt2-=a[2],a[2]=0;
		else a[2]-=cnt2,cnt2=0;
		cnt=cnt2*4;
		if(a[1]<=cnt)a[1]=0,cnt=0;
		else a[1]-=cnt,cnt=0;
		cnt=0,cnt2=0;
		
		sum+=(a[3]+3)/4;
		cnt2=three[a[3]%4];
		if(a[2]<=cnt2)cnt2-=a[2],a[2]=0;
		else a[2]-=cnt2,cnt2=0;
		cnt=cnt2*4+thrp[a[3]%4];
		if(a[1]<=cnt)a[1]=0,cnt=0;
		else a[1]-=cnt,cnt=0;
		cnt=0,cnt2=0;
		
		sum+=(a[2]+8)/9;
		if(a[2]%9>0)cnt=36-a[2]%9*4;
		if(a[1]<=cnt)a[1]=0,cnt=0;
		else a[1]-=cnt,cnt=0;
		cnt=0,cnt2=0;
		
		sum+=(a[1]+35)/36;
		printf("%lld\n",sum);
	}
    return 0;
}
