#include<cstdio>
#include<cmath>
#include<functional>
#include<map>
#include<iostream>
#include<queue>
using namespace std;

int n;

int main(void){
	scanf("%d",&n);
	priority_queue<double> que;
	for(int i=0;i<n;i++){
		double w;
		scanf("%lf",&w);
		que.push(w);
	}
	int id=n;
	while(que.size()>1){
		double p=que.top();
		que.pop();
		double q=que.top();
		que.pop();
		que.push(2*sqrt(p*q));
		id++;
	}
	printf("%.3f\n",que.top());
}