// 0031.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip> 
#include <complex> 
#include <string>
#include <vector> 
#include <list>
#include <deque> 
#include <stack> 
#include <queue> 
#include <set>
#include <map>
#include <bitset>
#include <functional>
#include <utility>
#include <algorithm> 
#include <numeric> 
#include <typeinfo> 
#include <cstdio>
#include <cstdlib> 
#include <cstring>
#include <cmath>
#include <climits> 
#include <ctime>

using namespace std;

const int w[10]={1,2,4,8,16,32,64,128,256,512};
int c[10];
int main(void){
	int n;
	int a;
	while(~scanf("%d",&n)){
		bool b=false;
		for(a=0;a<=9;a++)c[a]=0;
		for(a=9;a>=0;a--){
			if(n>=w[a])c[a]=1,n-=w[a];
			if(n==0)break;
		}
		for(a=0;a<=9;a++){
			if(c[a]==1){
				if(b==true)cout << " " << w[a];
				if(b==false){
					cout << w[a];
					b=true;
				}
			}
		}
		cout << endl;
	}
	return 0;
}