#include<stdio.h>
 
int main(){
    int n,a,b,c,t[101],d,e,f,dl,ans,nans,cal;
     
    scanf("%d",&n);
    scanf("%d %d",&a,&b);
    dl=a;
    scanf("%d",&c);
    cal=c;
    ans=cal/dl;
    for(d=0;d<n;d++){
        scanf("%d",&t[d]);
    }
    for(d=0;d<n;d++){
        for(e=d+1;e<n;e++){
            if(t[d]<=t[e])f=t[d],t[d]=t[e],t[e]=f;
        }
    }
    for(d=0;d<n;d++){
        cal+=t[d];
        dl+=b;
        nans=cal/dl;
        if(nans>=ans)ans=nans;else break;
    }
    printf("%d\n",ans);
    return 0;
} 