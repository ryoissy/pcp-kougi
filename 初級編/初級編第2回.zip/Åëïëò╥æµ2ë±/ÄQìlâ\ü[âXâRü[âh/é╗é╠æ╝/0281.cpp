#include<cstdio>
#include<algorithm>

using namespace std;

int q;
int c,a,n;

int main(void){
	scanf("%d",&q);
	for(int i=0;i<q;i++){
		scanf("%d%d%d",&c,&a,&n);
		int res=0;
		while(c>0 && a>0 && n>0){
			c--;
			a--;
			n--;
			res++;
		}
		while(c>1 && a>0){
			c-=2;
			a--;
			res++;
		}
		while(c>2){
			c-=3;
			res++;
		}
		printf("%d\n",res);
	}
	return 0;
}