#include <cstdio>
#include <algorithm>
#include <functional>
#include <queue>

using namespace std;

int n,c;
int v[21],b[21];

int main(void){
	scanf("%d %d",&n,&c);
	int cnt=0;
	for(int i=0;i<n;i++){
		scanf("%d %d",&v[i],&b[i]);
		if(v[i]>=c){
			cnt+=b[i];
			b[i]=0;
		}
	}
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			if(v[i]<v[j]){
				swap(v[i],v[j]);
				swap(b[i],b[j]);
			}
		}
	}
	int last=n-1;
	int nc=c;
	for(int i=0;i<n;i++){
		while(b[i]>0){
			if(nc-v[i]>=0){
				int dd=nc/v[i];
				if(b[i]>=dd){
					b[i]-=dd;
					nc-=dd*v[i];
				}else{
					nc-=b[i]*v[i];
					b[i]=0;
				}
			}else{
				for(int j=i+1;j<last;j++){
					if(nc-v[j]>=0){
						int dd=nc/v[j];
						if(b[j]>=dd){
							b[j]-=dd;
							nc-=dd*v[j];
						}else{
							nc-=b[j]*v[j];
							b[j]=0;
						}
					}
				}
				while(nc>0 && i<=last){
					int dd=nc/v[last];
					if(nc%v[last]!=0)dd++;
					if(b[last]>=dd){
						nc-=dd*v[last];
						b[last]-=dd;
					}else{
						nc-=b[last]*v[last];
						b[last]=0;
						last--;
					}
				}
			}
			if(nc<=0){
				nc=c;
				cnt++;
			}
		}
	}
	printf("%d\n",cnt);
	return 0;
}