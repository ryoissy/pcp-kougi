#include <cstdio>
#include <cstring>
typedef long long ll;
int n,s;
ll dp[102][12][1002];

int main(void){
	memset(dp,0,sizeof(dp));
	dp[0][0][0]=1;
	for(int i=0;i<=100;i++){
		for(int j=0;j<=9;j++){
			for(int k=0;k<=1000;k++){
				dp[i+1][j][k]+=dp[i][j][k];
				if(i+k<=1000)dp[i+1][j+1][k+i]+=dp[i][j][k];
			}
		}
	}
	while(1){
		scanf("%d %d",&n,&s);
		if(n==0)break;
		printf("%lld\n",dp[101][n][s]);
	}
	return 0;
}