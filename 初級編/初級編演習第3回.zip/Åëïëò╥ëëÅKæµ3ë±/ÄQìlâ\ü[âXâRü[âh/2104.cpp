#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int t;
int n,k;
int x[100001];
int dist[100001];
int main(void){
	scanf("%d",&t);
	for(int kkk=0;kkk<t;kkk++){
		scanf("%d %d",&n,&k);
		for(int i=0;i<n;i++){
			scanf("%d",&x[i]);
		}
		for(int i=0;i<n-1;i++){
			dist[i]=x[i+1]-x[i];
		}
		sort(dist,dist+n-1);
		int res=0;
		for(int i=0;i<n-k;i++){
			res+=dist[i];
		}
		printf("%d\n",res);
	}
	return 0;
}