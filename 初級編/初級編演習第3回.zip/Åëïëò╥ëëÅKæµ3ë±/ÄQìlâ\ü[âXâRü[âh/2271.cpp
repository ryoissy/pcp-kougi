// 2271.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstdio>
#include<string>

using namespace std;

int s[4];

int main(void){
	string str;
	cin >> str;
	for(int i=0;i<str.size();i++){
		if(str[i]=='K')s[0]++;
		if(str[i]=='U')s[1]++;
		if(str[i]=='P')s[2]++;
		if(str[i]=='C')s[3]++;
	}
	cout << min(min(s[0],s[1]),min(s[2],s[3])) << endl;
    return 0;
}
