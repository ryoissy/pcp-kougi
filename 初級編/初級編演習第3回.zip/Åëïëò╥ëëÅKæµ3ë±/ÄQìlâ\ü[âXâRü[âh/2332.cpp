#include <cstdio>
#include <queue>
#include <vector>
#include <cstring>
using namespace std;
int n;
int p[100001];
vector<int> G[100001];

int next[100001];
bool used[100001];
vector<int> vs;
void dfs(int v){
	used[v]=true;
	vs.push_back(v);
	if(p[v]==0){
		for(int i=0;i<vs.size();i++){
			next[vs[i]]=v;
		}
		return;
	}
	for(int i=0;i<G[v].size();i++){
		if(!used[G[v][i]]){
			dfs(G[v][i]);
		}else{
			if(next[G[v][i]]==-1){
				for(int j=0;j<vs.size();j++){
					next[vs[j]]=-2;
				}
				next[G[v][i]]=-2;
			}else{
				for(int j=0;j<vs.size();j++){
					next[vs[j]]=next[G[v][i]];
				}
			}
		}
	}
}

int cnt[100001];

int bfs(){
	queue<int> que;
	que.push(1);
	memset(cnt,-1,sizeof(cnt));
	cnt[1]=0;
	while(que.size()){
		int v=que.front();
		que.pop();
		if(v==n)return cnt[n];
		for(int i=1;i<=6;i++){
			if(v+i>=n)return cnt[v]+1;
			else if(next[v+i]>=1 && cnt[next[v+i]]==-1){
				cnt[next[v+i]]=cnt[v]+1;
				que.push(next[v+i]);
			}
		}
	}
}

int main(void){
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&p[i]);
		if(p[i]!=0)G[i].push_back(i+p[i]);
	}
	memset(next,-1,sizeof(next));
	memset(used,0,sizeof(used));
	for(int i=1;i<=n;i++){
		if(next[i]==-1){
			vs.clear();
			dfs(i);
		}
	}
	printf("%d\n",bfs());
	return 0;
}