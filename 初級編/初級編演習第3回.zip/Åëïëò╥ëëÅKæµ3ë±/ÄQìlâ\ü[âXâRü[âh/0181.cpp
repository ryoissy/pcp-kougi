#include<cstdio>
#include<cstring>
#define INF 1500000
int m,n;
int d[101];

bool check(int x){
	int nx=0,nm=1;
	for(int i=0;i<n;i++){
		if(d[i]>x)return false;
		if(d[i]+nx>x)nm++,nx=d[i];
		else nx+=d[i];
		if(nm>m)return false;
	}
	return true;
}

int main(void){
	while(1){
		scanf("%d%d",&m,&n);
		if(m==0)break;
		for(int i=0;i<n;i++)scanf("%d",&d[i]);
		int l=0,r=1500001;
		for(int i=0;i<30;i++){
			int mid=(l+r)/2;
			if(check(mid))r=mid;
			else l=mid;
		}
		printf("%d\n",r);
	}
	return 0;
}