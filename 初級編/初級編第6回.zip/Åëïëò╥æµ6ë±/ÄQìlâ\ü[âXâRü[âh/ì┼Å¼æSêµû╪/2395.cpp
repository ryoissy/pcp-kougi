#include<iostream>
#include<cstdio>
#include<queue>
#include<vector>
#include<algorithm>
#include<functional>

using namespace std;

typedef pair<int,int> P;
struct edge{
	int t,c;
	edge(int t,int c): t(t),c(c){};
};

int n,m;
vector<edge> G[2001];
bool flag[2001];
int INF=1000000001;
int prim(){
	priority_queue<P,vector<P>,greater<P> > que;
	que.push(P(0,1));
	int res=0;
	while(que.size()){
		P p=que.top();
		que.pop();
		int v=p.second,c=p.first;
		if(flag[v])continue;
		flag[v]=true;
		res=max(res,c);
		for(int i=0;i<G[v].size();i++){
			edge e=G[v][i];
			if(!flag[e.t]){
				que.push(P(e.c,e.t));
			}
		}
	}
	return res;
}

int main(void){
	scanf("%d%d",&n,&m);
	for(int i=0;i<m;i++){
		int a,b,c;
		scanf("%d%d%d",&a,&b,&c);
		G[a].push_back(edge(b,c));
		G[b].push_back(edge(a,c));
	}
	printf("%d\n",prim());
	return 0;
}