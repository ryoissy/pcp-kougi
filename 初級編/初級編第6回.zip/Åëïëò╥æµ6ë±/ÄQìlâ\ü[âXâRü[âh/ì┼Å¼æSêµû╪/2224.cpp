#include<iostream>
#include<cstdio>
#include<queue>
#include<algorithm>
#include<vector>
#include<cmath>
#include<map>

using namespace std;

struct edge{
	int f,t;
	double c;
};

bool comp(const edge &e1,const edge &e2){
	return e1.c>e2.c;
}

typedef pair<double,int> P;
int n,m;
bool used[10001];
int par[10001];
int rank[10001];
int x[10001],y[10001];
vector<edge> all;

void init(int v){
	for(int i=0;i<=v;i++)par[i]=i,rank[i]=0;
}

int find(int v){
	if(par[v]==v)return v;
	else return par[v]=find(par[v]);
}

void unite(int v,int w){
	v=find(v);
	w=find(w);
	if(v==w)return;
	if(rank[v]<rank[w])par[v]=w;
	else{
		par[w]=v;
		if(rank[v]==rank[w])rank[v]++;
	}
}

bool same(int v,int w){
	return find(v)==find(w);
}

double kruskal(){
	double res=0.0;
	init(n);
	sort(all.begin(),all.end(),comp);
	for(int i=0;i<all.size();i++){
		edge e=all[i];
		if(!same(e.f,e.t)){
			unite(e.f,e.t);
			//printf("%d %d %d %d\n",e.f,e.t,par[e.f],par[e.t]);
		}else res+=e.c;
	}
	return res;
}

int main(void){
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)scanf("%d%d",&x[i],&y[i]);
	for(int i=0;i<m;i++){
		int f,t;
		edge e;
		scanf("%d%d",&f,&t);
		double nx=(double)(abs(x[f]-x[t]));
		double ny=(double)(abs(y[f]-y[t]));
		e.c=(double)sqrt(pow(nx,2)+pow(ny,2));
		e.f=f;
		e.t=t;
		all.push_back(e);
	}
	printf("%.7f\n",kruskal());
	return 0;
}