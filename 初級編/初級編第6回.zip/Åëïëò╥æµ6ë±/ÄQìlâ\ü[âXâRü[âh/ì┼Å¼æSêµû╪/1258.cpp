#include<iostream>
#include<cstdio>
#include<queue>
#include<map>
#include<algorithm>
#include<vector>
#include<cstring>
#include<functional>
using namespace std;
typedef pair<int,int> P;
int n;
struct edge{
	int t,c;
	edge(int t,int c): t(t),c(c){};
};
bool used[101];
vector<edge> v[101];

long long prim(){
	memset(used,false,sizeof(used));
	long long res=0;
	priority_queue<P, vector<P> , greater<P> > que;
	que.push(P(0,0));
	while(que.size()){
		P p=que.top();que.pop();
		int nc=p.first,n=p.second;
		if(used[n]==true)continue;
		used[n]=true;
		res+=nc;
		for(int i=0;i<v[n].size();i++){
			edge e=v[n][i];
			if(used[e.t]==false){
				que.push(P(e.c,e.t));
			}
		}
	}
	return res;
}

int main(void){
	while(cin >> n){
		for(int i=0;i<n;i++){
			v[i].clear();
			for(int j=0;j<n;j++){
				int co;
				scanf("%d",&co);
				if(i!=j)v[i].push_back(edge(j,co));
			}	
		}
		printf("%lld\n",prim());
	}
	return 0;
}
