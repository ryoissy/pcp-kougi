// 0180.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip> 
#include <complex> 
#include <string>
#include <vector> 
#include <list>
#include <deque> 
#include <stack> 
#include <queue> 
#include <set>
#include <map>
#include <bitset>
#include <functional>
#include <utility>
#include <algorithm> 
#include <numeric> 
#include <typeinfo> 
#include <cstdio>
#include <cstdlib> 
#include <cstring>
#include <cmath>
#include <climits> 
#include <ctime>

using namespace std;

const int INF=1000000;
int n,m;
int cost[101][101];
int mincost[101];
bool used[101];

int prim(){
	int a;
	for(a=0;a<n;++a){
		mincost[a]=INF;
		used[a]=false;
	}
	mincost[0]=0;
	int res=0;
	while(1){
		int v=-1;
		for(a=0;a<n;a++){
			if(!used[a] && (v==-1 || mincost[a] < mincost[v]))v=a;
		}
		if(v==-1)break;
		used[v]=true;
		res+=mincost[v];
		for(a=0;a<n;a++){
			mincost[a]=min(mincost[a],cost[v][a]);
		}
	}
	return res;
}

int main(void){
	int a,b;
	while(1){
		for(a=0;a<=100;a++){
			for(b=0;b<=100;b++){
				cost[a][b]=INF;
				if(a==b)cost[a][b]=0;
			}
		}
		cin >> n >> m;
		if(n==0 && m==0)break;
		for(a=0;a<m;a++){
			int b,c,d;
			cin >> b >> c >> d;
			if(cost[b][c]>d){
				cost[b][c]=d;
				cost[c][b]=d;
			}
		}
		int ans=prim();
		cout << ans << endl;
	}
	return 0;
}