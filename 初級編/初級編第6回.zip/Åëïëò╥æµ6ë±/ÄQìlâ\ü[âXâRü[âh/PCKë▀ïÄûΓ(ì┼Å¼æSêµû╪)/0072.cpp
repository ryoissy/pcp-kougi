// 0072.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip> 
#include <complex> 
#include <string>
#include <vector> 
#include <list>
#include <deque> 
#include <stack> 
#include <queue> 
#include <set>
#include <map>
#include <bitset>
#include <functional>
#include <utility>
#include <algorithm> 
#include <numeric> 
#include <typeinfo> 
#include <cstdio>
#include <cstdlib> 
#include <cstring>
#include <cmath>
#include <climits> 
#include <ctime>

using namespace std;

const int INF=1000000;
int cost[101][101];
int mincost[101];
bool used[101];
int V;
int prim(){
	int a;
	for(a=0;a<=100;a++){
		used[a]=false;
		mincost[a]=INF;
	}
	mincost[0]=0;
	int res=0;
	while(1){
		int v=-1;
		int u;
		for(u=0;u<V;u++){
			if(!used[u] && (v==-1 || mincost[u]<mincost[v]))v=u;
		}
		if(v==-1)break;
		used[v]=true;
		res+=mincost[v];
		for(u=0;u<V;u++){
			mincost[u]=min(mincost[u],cost[v][u]);
		}
	}
	return res;
}

int main(void){
	int a,b;
	int n;
	int ans;
	while(1){
		for(a=0;a<=100;a++){
			for(b=0;b<=100;b++){
				cost[b][a]=INF;
			}
			cost[a][a]=0;
		}
		cin >> V;
		if(V==0)break;
		cin >> n;
		for(a=0;a<n;a++){
			int c,d,e;
			scanf("%d,%d,%d",&c,&d,&e);
			cost[c][d]=e/100-1;
			cost[d][c]=e/100-1;
		}
		ans=prim();
		cout << ans << endl;
	}
	return 0;
}