// 0215.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>

using namespace std;

int x,y;
const int INF=1000000;
string str[1001];
int dp[5001][1<<5];
int sx,sy;
int gx,gy;
in
int main(void){
	while(1){
		for(int u=0;u<=5000;u++){
			for(int bit=0;bit<=(1<<5)-1;bit++){
				dp[u][i][j][bit]=INF;
			}
		}
		scanf("%d%d",&x,&y);
		for(int i=0;i<y;i++){
			cin >> str[i];
			for(int j=0;j<)
		}
	}
    return 0;
}
