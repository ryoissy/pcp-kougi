// 0200.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include <iostream>
#include <cstring>

using namespace std;

const int INF=100000;
int cost[101][101];
int tim[101][101];

int main(void){
	int n,m,a,b,c;
	while(1){
		for(a=0;a<=100;a++){
			for(b=0;b<=100;b++){
				cost[a][b]=INF;
				tim[a][b]=INF;
				if(a==b)cost[a][b]=0,tim[a][b]=0;
			}
		}
		cin >> n >> m;
		if(n==0 && m==0)break;
		for(a=0;a<n;a++){
			int f,t,co,ti;
			scanf("%d%d%d%d",&f,&t,&co,&ti);
			if(cost[f][t]>co)cost[f][t]=co,cost[t][f]=co;
			if(tim[f][t]>ti)tim[f][t]=ti,tim[t][f]=ti;
		}
		for(c=1;c<=m;c++){
			for(b=1;b<=m;b++){
				for(a=1;a<=m;a++){
					cost[a][b]=min(cost[a][b],cost[a][c]+cost[c][b]);
					tim[a][b]=min(tim[a][b],tim[a][c]+tim[c][b]);
				}
			}
		}
		cin >> n;
		for(a=0;a<n;a++){
			int d,f,t;
			scanf("%d%d%d",&f,&t,&d);
			if(d==0)printf("%d\n",cost[f][t]);
			if(d==1)printf("%d\n",tim[f][t]);
		}
	}
    return 0;
}