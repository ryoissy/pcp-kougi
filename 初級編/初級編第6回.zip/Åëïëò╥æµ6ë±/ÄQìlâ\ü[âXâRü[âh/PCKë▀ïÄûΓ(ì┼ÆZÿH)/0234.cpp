// 0234.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<queue>
#include<vector>
#include<algorithm>
#include<functional>
#include<map>
using namespace std;
int INF=10000000;
int w,h;
int ans;
//�\�Z�A�e�ʁA�����_�f
int f,m,o;
int fie[11][11];
//x,bit,y,air
int cost[11][1<<10][11][51];

void dfs(int x,int bit,int y,int air,int c){
	if(air<=0)return;
	if(!((bit >> x)& 1)){
		if(fie[x][y]>0)air=min(air+fie[x][y],m);
		if(fie[x][y]<0)c+=abs(fie[x][y]);
		bit |= 1<< x;
	}
	if(c>f)return;
	if(cost[x][bit][y][air]<=c)return;
	cost[x][bit][y][air]=c;
	if(y==h-1)ans=min(ans,c);
	else{
		dfs(x,0,y+1,air-1,c);
		if(x-1>=0)dfs(x-1,bit,y,air-1,c);
		if(x+1<w)dfs(x+1,bit,y,air-1,c);
	}
}

int main(void){
	while(1){
		ans=INF;
		for(int i=0;i<=10;i++){
			for(int j=0;j<=10;j++){
				for(int bit=0;bit<=(1<<10)-1;bit++){
					for(int k=0;k<=50;k++){
						cost[i][bit][j][k]=INF;
					}
				}
			}
		}
		scanf("%d%d",&w,&h);
		if(w==0 && h==0)break;
		scanf("%d%d%d",&f,&m,&o);
		for(int i=0;i<h;i++){
			for(int j=0;j<w;j++){
				scanf("%d",&fie[j][i]);
			}
		}
		for(int i=0;i<w;i++){
			dfs(i,0,0,o-1,0);
		}
		if(ans==INF)cout << "NA" << endl;
		else cout << ans << endl;
	}	
    return 0;
}
