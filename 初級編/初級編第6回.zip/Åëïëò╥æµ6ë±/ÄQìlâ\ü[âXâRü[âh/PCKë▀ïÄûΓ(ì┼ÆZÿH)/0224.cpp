// 0224.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<string>
#include<vector>
#include<cstdlib>
#define rep(i,n) for(int i=0;i<n;i++)

using namespace std;

struct edge{
	int from,to,cost;
	edge(int a,int b,int c){from = a , to = b , cost = c;} 
};

int m,n,k,dd;
vector<edge> es;
const int INF=100000;
int d[1<<6][109];
int cake[9];

int root(string s){
	if(s[0]=='H')return 0;
	if(s[0]=='D')return 1;
	string num = s.substr(1,s.size()-1); 
	if(s[0]=='C')return 1+atoi(num.c_str());
	if(s[0]=='L')return m+1+atoi(num.c_str());
}

void path(int s){
	int a,b;
	rep(b,1<<m)for(a=0;a<109;a++)d[b][a]=INF;
	d[0][s]=0;
	while(true){
		bool upd=false;
		for(a=0;a<es.size();a++){
			edge e=es[a];
			rep(b,1<<m){
				if(e.to>1 && e.to<=1+m && (b & (1<<(e.to-2))) ) continue;
				if(e.to>1 && e.to<=1+m){
					if(d[b|(1<<(e.to-2))][e.to]>d[b][e.from]+e.cost-cake[e.to-2]){
						d[b|(1<<(e.to-2))][e.to]=d[b][e.from]+e.cost-cake[e.to-2];
						upd=true;
					}
				}else if(d[b][e.to]>d[b][e.from]+e.cost){
					d[b][e.to]=d[b][e.from]+e.cost;
					upd=true;
				}
			}
		}
		if(!upd)break;
	}
}

int main(void){
	int a;
	while(1){
		int ans=INF;
		cin >> m >> n >> k >> dd;
		if(m==0 && n==0 && k==0 && dd==0)break;
		es.clear();
		for(a=0;a<m;a++){
			cin >> cake[a];
		}
		for(a=0;a<dd*2;a+=2){
			int b,c,dd;
			string s;
			string ss;
			cin >> s >> ss >> dd;
			b=root(s);
			c=root(ss);
			es.push_back(edge(b,c,dd*k));
			es.push_back(edge(c,b,dd*k));
		}
		path(0);
		rep(a,1<<m)ans=min(ans,d[a][1]);
		cout << ans << endl;
	}
	return 0;
}