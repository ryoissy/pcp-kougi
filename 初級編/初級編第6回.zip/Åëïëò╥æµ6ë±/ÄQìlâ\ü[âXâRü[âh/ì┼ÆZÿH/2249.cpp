#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
#include<vector>
#include<algorithm>
#include<functional>

using namespace std;

struct edge{
	int t,d,c;
};
typedef long long ll;
typedef pair<ll,int> P;
typedef pair<ll,P> PP;
int n,m;
ll INF=1000000007;
ll d[20001];
vector<edge> G[20001];

void dijk(){
	for(int i=0;i<n;i++)d[i]=INF;
	priority_queue<P,vector<P>,greater<P> > que;
	que.push(P(0,0));
	d[0]=0;
	while(que.size()){
		P p=que.top();
		que.pop();
		ll c=p.first;
		int v=p.second;
		if(c>d[v])continue;
		for(int i=0;i<G[v].size();i++){
			edge e=G[v][i];
			if((ll)c+e.d<d[e.t]){
				d[e.t]=c+e.d;
				que.push(P(c+e.d,e.t));
			}
		}
	}
}

int use[10001];
ll check(){
	priority_queue<P,vector<P>,greater<P> > que;
	for(int i=0;i<n;i++)use[i]=INF,que.push(P(d[i],i));
	while(que.size()){
		P p=que.top();
		que.pop();
		int v=p.second;
		int c=p.first;
		for(int i=0;i<G[v].size();i++){
			edge e=G[v][i];
			if(c+e.d==d[e.t])use[e.t]=min(use[e.t],e.c);
		}
	}
	int res=0;
	for(int i=1;i<n;i++)res+=use[i];
	return res;
}

int main(void){
	while(1){
		scanf("%d%d",&n,&m);
		if(n==0 && m==0)break;
		for(int i=0;i<m;i++){
			int f,t;
			edge e;
			scanf("%d%d%d%d",&f,&t,&e.d,&e.c);
			f--,t--;
			e.t=t;
			G[f].push_back(e);
			e.t=f;
			G[t].push_back(e);
		}
		dijk();
		//for(int i=0;i<n;i++)printf("%d%c",d[i],i==n-1?'\n':' ');
		printf("%lld\n",check());
		for(int i=0;i<=n;i++){
			G[i].clear();
		}
	}
	return 0;
}