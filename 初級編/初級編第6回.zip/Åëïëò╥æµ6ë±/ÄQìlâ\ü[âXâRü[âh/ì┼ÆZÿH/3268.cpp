#include<iostream>
#include<cstdio>
#include<queue>
#include<vector>
#include<algorithm>
#include<functional>
#include<map>
using namespace std;

const int INF=1000000000;
struct edge{ int t, c; };

typedef pair<int,int> P;
int n,m,x;
vector<edge> G[1001];
int d[1001];
int res=0;

int dijk(int s){
	if(s==x)return 0;
	fill(d,d+n+1,INF);
	priority_queue<P,vector<P>,greater<P> > que;
	que.push(P(0,s));
	d[s]=0;
	while(que.size()){
		P p=que.top();
		que.pop();
		int v=p.second,co=p.first;
		if(co>d[v])continue;
		d[v]=co;
		for(int i=0;i<G[v].size();i++){
			edge e=G[v][i];
			if(d[e.t]>co+e.c){
				d[e.t]=co+e.c;
				que.push(P(co+e.c,e.t));
			}
		}
	}
	return d[x];
}
int dijk2(int s){
	if(s==x)return 0;
	fill(d,d+n+1,INF);
	priority_queue<P,vector<P>,greater<P> > que;
	que.push(P(0,x));
	d[x]=0;
	while(que.size()){
		P p=que.top();
		que.pop();
		int v=p.second,co=p.first;
		if(co>d[v])continue;
		d[v]=co;
		for(int i=0;i<G[v].size();i++){
			edge e=G[v][i];
			if(d[e.t]>co+e.c){
				d[e.t]=co+e.c;
				que.push(P(co+e.c,e.t));
			}
		}
	}
	return d[s];
}

int main(void){
	scanf("%d%d%d",&n,&m,&x);
	for(int i=0;i<m;i++){
		edge e;
		int a;
		scanf("%d%d%d",&a,&e.t,&e.c);
		G[a].push_back(edge(e));
	}
	for(int i=1;i<=n;i++)res=max(res,dijk(i)+dijk2(i));
	printf("%d\n",res);
	return 0;
}