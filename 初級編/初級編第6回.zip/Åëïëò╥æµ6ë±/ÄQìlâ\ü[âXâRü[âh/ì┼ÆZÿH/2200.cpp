#include<iostream>
#include<cstdio>
#include<queue>
#include<string>
#include<cstring>
#include<vector>
#include<algorithm>
#include<functional>
using namespace std;


const int INF=10000000;
int ans;
int n,m;
int r;
int load[201][201];
int sea[201][201];
int dp[1001][201];
int rt[1001];
int main(void){
	while(1){
		for(int i=0;i<=200;i++){
			for(int j=0;j<=200;j++){
				load[i][j]=sea[i][j]=INF;
			}
			load[i][i]=sea[i][i]=0;
			for(int j=0;j<=1000;j++){
				dp[j][i]=INF;
			}
		}
		cin >> n >> m;
		if(n==0 && m==0)break;
		for(int i=0;i<m;i++){
			int a,b,ti;
			string ls;
			cin >> a >> b >> ti >> ls;
			a--,b--;
			if(ls=="L"){
				load[a][b]=min(load[a][b],ti);
				load[b][a]=min(load[b][a],ti);
			}
			if(ls=="S"){
				sea[a][b]=min(sea[a][b],ti);
				sea[b][a]=min(sea[b][a],ti);
			}
		}
		for(int k=0;k<=200;k++){
			for(int i=0;i<=200;i++){
				for(int j=0;j<=200;j++){
					load[i][j]=min(load[i][j],load[i][k]+load[k][j]);
					sea[i][j]=min(sea[i][j],sea[i][k]+sea[k][j]);
				}
			}
		}
		cin >> r;
		for(int i=0;i<r;i++){
			cin >> rt[i];
			rt[i]--;
		}
		dp[0][rt[0]]=0;
		//�z�B��
		for(int i=0;i<r-1;i++){
			//���̑D�̈ʒu
			for(int j=0;j<=200;j++){
				//���̑D�̈ʒu
				for(int k=0;k<=200;k++){
					if(dp[i][k]!=INF){
						dp[i+1][j]=min(dp[i+1][j],dp[i][k]+load[rt[i]][k]+sea[k][j]+load[j][rt[i+1]]);
						if(j==k)dp[i+1][j]=min(dp[i+1][j],dp[i][k]+load[rt[i]][rt[i+1]]);
					}
				}
			}
		}
		int res=INF;
		for(int i=0;i<=200;i++)res=min(res,dp[r-1][i]);
		printf("%d\n",res);
	}
	return 0;
}