// 2139.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstdio>

using namespace std;
int dp[301][301];
int t,d[301];
int n,m;
double ans=1000000000;
int main(void){
	for(int i=0;i<=300;i++)for(int j=0;j<=300;j++)dp[i][j]=1000000;
	scanf("%d%d",&n,&m);
	for(int i=0;i<m;i++){
		scanf("%d",&t);
		for(int j=0;j<t;j++)scanf("%d",&d[j]);
		for(int j=0;j<t;j++){
			for(int k=0;k<t;k++){
				dp[d[j]][d[k]]=1;
			}
			dp[d[j]][d[j]]=1000000;
		}
	}
	for(int k=1;k<=n;k++){
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				dp[i][j]=min(dp[i][j],dp[i][k]+dp[k][j]);
			}
		}
	}
	for(int i=1;i<=n;i++){
		double c=0;
		for(int j=1;j<=n;j++){
			if(i!=j)c+=dp[i][j];
		}
		ans=min(ans,c*100/(n-1));
	}
	printf("%d\n",(int)ans);
    return 0;
}
