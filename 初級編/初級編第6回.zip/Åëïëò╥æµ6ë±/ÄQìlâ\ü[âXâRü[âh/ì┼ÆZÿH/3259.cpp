#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>

using namespace std;

struct edge{ int f,t,c; };
int farm;
int n,m,w;
vector<edge> G;
int d[1001];

bool loop(){
	memset(d,0,sizeof(d));
	for(int lp=0;lp<n;lp++){
		bool flag=false;
		for(int i=0;i<G.size();i++){
			edge e=G[i];
			if(d[e.t]>d[e.f]+e.c){
				flag=true;
				d[e.t]=d[e.f]+e.c;
			}
		}
		
		if(!flag)break;
		if(lp==n-1)return true;
	}
	return false;
}

int main(void){
	scanf("%d",&farm);
	for(int ds=0;ds<farm;ds++){
		G.clear();
		scanf("%d%d%d",&n,&m,&w);
		for(int i=0;i<m;i++){
			edge a;
			scanf("%d%d%d",&a.f,&a.t,&a.c);
			G.push_back(edge(a));
			swap(a.f,a.t);
			G.push_back(edge(a));
		}
		for(int i=0;i<w;i++){
			edge a;
			scanf("%d%d%d",&a.f,&a.t,&a.c);
			a.c*=-1;
			G.push_back(edge(a));
		}
		if(loop())printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
