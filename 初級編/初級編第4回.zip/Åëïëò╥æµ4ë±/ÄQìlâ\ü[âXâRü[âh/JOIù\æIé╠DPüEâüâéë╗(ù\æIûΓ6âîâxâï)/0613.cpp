#include <cstdio>
#include <vector>
#include <utility>
#include <algorithm>
#include <set>
#define INF 1e17
using namespace std;

typedef long long ll;
typedef pair<ll,ll> P; 

class datas{
public:
	ll a,b;
	datas(ll aa,ll bb){
		a=aa;
		b=bb;
	}
	bool operator<(const datas &d1)const {
		return d1.b<b;
	}
};

int n,segn;
ll x[31],y[31],d;
vector<P> data[2];

void dfs(int v,ll ax,ll ay){
	if(v==(n+1)/2){
		data[0].push_back(P(ax,ay));
	}else{
		dfs(v+1,ax,ay);
		dfs(v+1,ax+x[v],ay-y[v]);
		dfs(v+1,ax-x[v],ay+y[v]);
	}
}

void dfs2(int v,ll ax,ll ay){
	if(v==n){
		data[1].push_back(P(ax,ay));
	}else{
		dfs2(v+1,ax,ay);
		dfs2(v+1,ax+x[v],ay-y[v]);
		dfs2(v+1,ax-x[v],ay+y[v]);
	}
}
int main(void){
	scanf("%d %lld",&n,&d);
	for(int i=0;i<n;i++){
		scanf("%lld %lld",&x[i],&y[i]);
	}
	dfs(0,0,0);
	sort(data[0].begin(),data[0].end());
	data[0].erase(unique(data[0].begin(),data[0].end()),data[0].end());
	dfs2((n+1)/2,0,0);
	sort(data[1].begin(),data[1].end());
	data[1].erase(unique(data[1].begin(),data[1].end()),data[1].end());
	int l=data[1].size()-1,r=data[1].size()-1;
	ll res=0;
	multiset<datas> s;
	for(int i=0;i<data[0].size();i++){
		while(-data[0][i].first-d<=data[1][l].first && l>=0){
			s.insert(datas(data[1][l].first,data[1][l].second));
			l--;
		}
		while(-data[0][i].first+d<data[1][r].first && r>l){
			multiset<datas>::iterator it=s.find(datas(data[1][r].first,data[1][r].second));
			s.erase(it);
			r--;
		}
		if(s.size()>0){
			multiset<datas>::iterator it=s.begin();
			datas kkk=*it;
			res=max(res,kkk.b+data[0][i].second);
		}
	}
	printf("%lld\n",res);
	return 0;
}