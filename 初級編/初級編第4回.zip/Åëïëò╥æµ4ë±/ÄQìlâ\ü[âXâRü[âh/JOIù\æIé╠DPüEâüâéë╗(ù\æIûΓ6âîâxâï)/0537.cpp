// 0537.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstring>

using namespace std;

int n,m,s;
int map[50][3001];

int main(void){
	while(1){
		cin >> n >> m >> s;
		if(n==0 && m==0 && s==0)break;
		memset(map,0,sizeof(map));
		map[0][0]=1;
		for(int i=1;i<=m;i++){
			for(int j=n*n;j>=1;j--){
				for(int k=i;k<=s;k++){
					map[j][k]=(map[j][k]+map[j-1][k-i])%100000;
				}
			}
		}
		cout << map[n*n][s] << endl;
	}
    return 0;
}
