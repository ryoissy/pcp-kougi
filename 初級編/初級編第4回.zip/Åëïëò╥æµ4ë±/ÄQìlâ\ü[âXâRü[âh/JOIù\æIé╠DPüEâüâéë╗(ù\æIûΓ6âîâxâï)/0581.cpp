#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip> 
#include <complex> 
#include <string>
#include <vector> 
#include <list>
#include <deque> 
#include <stack> 
#include <queue> 
#include <set>
#include <map>
#include <bitset>
#include <functional>
#include <utility>
#include <algorithm> 
#include <numeric> 
#include <typeinfo> 
#include <cstdio>
#include <cstdlib> 
#include <cstring>
#include <cmath>
#include <climits> 
#include <ctime>
using namespace std;
 
int h,w,K;
string str;
int fie[100][100];
short dp[51][51][4][1<<12+1];
int res=0;
 
short dfs(int x,int y,int k,int bit,int pc){
    int nx=x,ny=y;
    if(dp[x][y][k][bit]!=-1)return dp[x][y][k][bit];
     
    //11nx++,10nx--,01ny++,00ny--;
    int nbit=bit;
    if(nbit >>11 & 1)nbit-=1<<11;
    if(nbit >>10 & 1)nbit-=1<<10;
    nbit<<=2;
    short r=-20000;
    if(k>=1){
        nbit+=2;
        x--;
        if(x>=0 && y>=0 && fie[x][y]!=-1){
            r=max(r,dfs(x,y,k-1,nbit,pc+1));
        }
        x++;
        y--;
        nbit-=2;
        if(x>=0 && y>=0 && fie[x][y]!=-1){
            r=max(r,dfs(x,y,k-1,nbit,pc+1));
        }
        y++;
    }
    nbit+=3;
    x++;
    if(x>=0 && y>=0 && fie[x][y]!=-1){
        r=max(r,dfs(x,y,k,nbit,pc+1));
    }
    x--;
    nbit-=2;
    y++;
    if(x>=0 && y>=0 && fie[x][y]!=-1){
        r=max(r,dfs(x,y,k,nbit,pc+1));
    }
    y--;
     
    int sum=0;
    bool f=false;
    for(int i=0;i<min(pc,6);i++){
        if(bit >>i*2 & 1){
            if(bit >>(i*2+1) & 1)nx--;
            else ny--;
        }else{
            if(bit >>(i*2+1) & 1)nx++;
            else ny++;
        }
        if(nx==x && ny==y){
            f=true;
            break;
        }
    }
    if(!f)sum+=fie[x][y];
     
    if(r<0 && x==w-1 && y==h-1)r=0;
    return (dp[x][y][k][bit]=sum+r);
}
 
int main(void){
    scanf("%d%d%d",&h,&w,&K);
    memset(fie,-1,sizeof(fie));
    memset(dp,-1,sizeof(dp));
    for(int i=0;i<h;i++){
        cin >> str;
        for(int j=0;j<w;j++){
            if(str[j]=='.')fie[j][i]=0;
            else if(str[j]=='#')fie[j][i]=-1;
            else fie[j][i]=str[j]-'0';
        }
    }
    printf("%d\n",dfs(0,0,K,0,0));
    return 0;
}