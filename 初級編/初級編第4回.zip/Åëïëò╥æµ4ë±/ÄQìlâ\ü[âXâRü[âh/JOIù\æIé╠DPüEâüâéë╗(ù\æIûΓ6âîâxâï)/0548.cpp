// 0548.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>
#include<map>

using namespace std;

int x,y;
int sx,sy;
int N;
int hx[24],hy[24];
int fie[12][12];
int dx[4]={0,0,1,-1},dy[4]={1,-1,0,0};
map<int,int> memo[24];

int dfs(int pos,int bit,bool done[12][12],int home){
	if(memo[pos].find(bit)!=memo[pos].end())return memo[pos][bit];
	if(bit==(1<<N)-1){
		for(int i=0;i<4;i++){
			int cx=hx[pos]+dx[i],cy=hy[pos]+dy[i];
			while(fie[cx][cy]!=-1){
				if(fie[cx][cy]==100)return 1;
				cx+=dx[i],cy+=dy[i];
			}
		}
		return 0;
	}
	int ans=0;
	for(int i=0;i<4;i++){
		int cx=hx[pos]+dx[i],cy=hy[pos]+dy[i];
		while(fie[cx][cy]==-2 || fie[cx][cy]==100 || done[cx][cy]==true){
			cx+=dx[i],cy+=dy[i];
		}
		if(fie[cx][cy]!=-1){
			done[cx][cy]=true;
			ans+=dfs(fie[cx][cy] , bit | (1<<fie[cx][cy]), done,home+1);
			done[cx][cy]=false;
		}
	}
	if(home<15)memo[pos][bit]=ans;
	return ans;
}

int main(void){
	while(1){
		scanf("%d%d",&x,&y);
		if(x==0 && y==0)break;
		N=0;
		for(int i=0;i<24;i++){
			memo[i].clear();
		}
		for(int i=0;i<12;i++){
			for(int j=0;j<12;j++){
				fie[j][i]=-1;
			}
		}
		for(int i=1;i<=y;i++){
			for(int j=1;j<=x;j++){
				scanf("%d",&fie[j][i]);
				if(fie[j][i]==0){
					fie[j][i]=-2;
				}
				if(fie[j][i]==2){
					fie[j][i]=100;
					sx=j;
					sy=i;
				}
				if(fie[j][i]==1){
					fie[j][i]=N;
					hx[N]=j;
					hy[N]=i;
					N++;
				}
			}
		}
		hx[N]=sx,hy[N]=sy;
		bool done[12][12];
		memset(done,false,sizeof(done));
		cout << dfs(N,0,done,0) << endl;
	}
    return 0;
}
