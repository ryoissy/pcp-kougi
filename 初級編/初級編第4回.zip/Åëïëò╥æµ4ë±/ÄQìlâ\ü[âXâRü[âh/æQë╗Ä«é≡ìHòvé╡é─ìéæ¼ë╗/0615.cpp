#include <cstdio>
#include <cstring>

typedef long long ll;
int n;
ll a[2001];
ll dp[2001][2001];

ll max(ll x,ll y){
	if(x>y)return x;
	return y;
}

ll memo(ll l,ll r){
	if(dp[l][r]!=-1)return dp[l][r];
	if(l==r)return 0;
	if((r+1)%n==l)return a[r];
	ll vl=a[(l-1+n)%n],vr=a[r];
	if(a[(l-2+n)%n]>a[r])vl+=memo((l-2+n)%n,r);
	else vl+=memo((l-1+n)%n,(r+1)%n);
	if(a[(l-1+n)%n]>a[(r+1)%n])vr+=memo((l-1+n)%n,(r+1)%n);
	else vr+=memo(l,(r+2)%n);
	return dp[l][r]=max(vl,vr);
}

int main(void){
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%lld",&a[i]);
	}
	if(n<=2){
		printf("%d\n",max(a[0],a[1]));
		return 0;
	}
	ll res=0;
	memset(dp,-1,sizeof(dp));
	for(int i=0;i<n;i++){
		if(a[(i-1+n)%n]>a[(i+1)%n])res=max(res,memo((i-1+n)%n,(i+1)%n)+a[i]);
		else res=max(res,memo(i,(i+2)%n)+a[i]);
	}
	printf("%lld\n",res);
	return 0;
}