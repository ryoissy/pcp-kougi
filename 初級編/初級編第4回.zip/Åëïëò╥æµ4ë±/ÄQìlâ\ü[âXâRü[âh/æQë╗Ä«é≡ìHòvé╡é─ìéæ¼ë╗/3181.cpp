#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;

int n,k;
int dp[101][1001][101];

void tbi(int x,int y,int m){
	if(m==0){
		for(int i=0;i<100;i++){
			dp[x][y][i]=dp[x-1][y][i];
		}
	}
	if(m==1){
		int p=0;
		for(int i=0;i<100;i++){
			dp[x][y][i]=(dp[x-1][y][i]+dp[x][y-x][i]+p)%10;
			p=(dp[x-1][y][i]+dp[x][y-x][i]+p)/10;
			
		}
	}
}

int main(void){
	scanf("%d%d",&n,&k);
	dp[0][0][0]=1;
	for(int i=1;i<=k;i++){
		for(int j=0;j<=n;j++){
			if(j>=i)tbi(i,j,1);
			else tbi(i,j,0);
		}
	}
	string res;
	bool flag=false;
	for(int i=99;i>=0;i--){
		if(dp[k][n][i]!=0)flag=true;
		if(flag)res+=dp[k][n][i]+'0';
	}
	cout << res << endl;
	return 0;
}
