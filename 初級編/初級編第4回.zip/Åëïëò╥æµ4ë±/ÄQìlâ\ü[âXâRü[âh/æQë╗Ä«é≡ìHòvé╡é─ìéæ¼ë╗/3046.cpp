#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<functional>
using namespace std;

int t,a,s,b;
int cnt[1002];
int dp[2][300001];
int res;
int mod=1000000;

int main(void){
	scanf("%d%d%d%d",&t,&a,&s,&b);
	for(int i=0;i<a;i++){
		int num;
		scanf("%d",&num);
		num--;
		cnt[num]++;
	}
	sort(cnt,cnt+t,greater<int>() );
	int now=1,prev=0;
	int sum=0;
	for(int i=0;i<t;i++){
		dp[prev][0]=1;
		if(cnt[i]==0)break;
		for(int j=0;j<=sum;j++){
			dp[now][j]=dp[prev][j];
		}
		for(int k=1;k<=cnt[i];k++){
			for(int j=0;j<=sum;j++){
				dp[now][j+k]+=dp[prev][j];
				while(dp[now][j+k]>=mod)dp[now][j+k]-=mod;
			}
		}
		//for(int j=0;j<=10;j++)printf("%d%c",dp[now][j],j==10?'\n':' ');
		memset(dp[prev],0,sizeof(dp[prev]));
		swap(now,prev);
		sum+=cnt[i];
	}
	for(int j=s;j<=b;j++){
		res+=dp[prev][j];
		while(res>=mod)res-=mod;
	}
	printf("%d\n",res);
	return 0;
}