#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector>
using namespace std;

struct blocks{
	int a,h,c;
};

bool operator<(const blocks& a, const blocks& b){
    return a.a < b.a;
}

int k;
blocks b[501];
int dp[40001];
int res=0;
int main(void){
	scanf("%d",&k);
	for(int i=0;i<k;i++){
		scanf("%d%d%d",&b[i].h,&b[i].a,&b[i].c);
	}
	sort(b,b+k);
	memset(dp,-1,sizeof(dp));
	dp[0]=0;
	for(int i=0;i<k;i++){
		for(int j=0;j<=b[i].a;j++){
			if(dp[j]>=0)dp[j]=b[i].c;
			else if(j<b[i].h || dp[j-b[i].h]<=0)dp[j]=-1;
			else dp[j]=dp[j-b[i].h]-1;
			if(dp[j]>=0)res=max(res,j);
		}
	}
	printf("%d\n",res);
	return 0;
}