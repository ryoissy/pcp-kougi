#include<iostream>
#include<cstdio>
#include<map>
#include<algorithm>
#include<cstring>

using namespace std;

struct cow{
	int s,f;
};

bool comp(const cow &e1,const cow &e2){
	return e1.s>e2.s;
}

cow all[400];
int n;
int sta=1000000;
int M=0;
int dp[2][105001];

int main(void){
	scanf("%d",&n);
	for(int i=0;i<n;i++)scanf("%d%d",&all[i].s,&all[i].f);
	sort(all,all+n,comp);
	int now=1,prev=0;
	for(int i=0;i<n;i++){
		M=max(M,M+all[i].s);
		memset(dp[now],0,sizeof(dp[now]));
		dp[prev][0]=max(sta,dp[prev][0]);
		for(int j=0;j<=M;j++){
			if(j+all[i].s>=0)dp[now][j+all[i].s]=max(dp[now][j+all[i].s],dp[prev][j]+all[i].f);
			dp[now][j]=max(dp[now][j],dp[prev][j]);
		}
		swap(now,prev);
	}
	int res=sta;
	for(int j=0;j<=M;j++)if(dp[prev][j]>=sta)res=max(res,j+dp[prev][j]);
	printf("%d\n",res-sta);
	return 0;
}