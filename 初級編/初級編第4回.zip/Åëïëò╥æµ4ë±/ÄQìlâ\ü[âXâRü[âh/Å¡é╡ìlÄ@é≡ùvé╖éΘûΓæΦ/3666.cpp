#include <cstdio>
#include <algorithm>
#include <vector>
#include <cstring>
#define INF 1LL<<50
using namespace std;

typedef long long ll;

ll lmin(ll a,ll b){
	if(a>b)return b;
	return a;
}

int n;
ll a[2002];
ll dp[2002][2002];

vector<ll> data;

int main(void){
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%lld",&a[i]);
		data.push_back(a[i]);
	}
	sort(data.begin(),data.end());
	data.erase(unique(data.begin(),data.end()),data.end());
	for(int i=0;i<n;i++){
		a[i]=lower_bound(data.begin(),data.end(),a[i])-data.begin();
	}
	for(int i=0;i<=n;i++){
		for(int j=0;j<data.size();j++){
			dp[i][j]=INF;
		}
	}
	for(int i=0;i<data.size();i++)dp[0][i]=0;
	for(int i=0;i<n;i++){
		for(int j=0;j<data.size();j++){
			if(a[i]==j){
				dp[i+1][j]=lmin(dp[i+1][j],dp[i][j]);
			}
			if(a[i]>j){
				dp[i+1][j]=lmin(dp[i+1][j],dp[i][j]+data[a[i]]-data[j]);
				dp[i+1][a[i]]=lmin(dp[i+1][a[i]],dp[i][j]);
			}
			if(a[i]<j){
				dp[i+1][j]=lmin(dp[i+1][j],dp[i][j]+data[j]-data[a[i]]);
			}
			if(j>0)dp[i+1][j]=lmin(dp[i+1][j],dp[i+1][j-1]);
		}
	}
	ll res=INF;
	for(int i=0;i<data.size();i++){
		res=lmin(res,dp[n][i]);
	}

	for(int i=0;i<=n;i++){
		for(int j=0;j<data.size();j++){
			dp[i][j]=INF;
		}
	}
	for(int i=0;i<data.size();i++)dp[0][i]=0;
	for(int i=0;i<n;i++){
		for(int j=data.size()-1;j>=0;j--){
			if(a[i]==j){
				dp[i+1][j]=lmin(dp[i+1][j],dp[i][j]);
			}
			if(a[i]>j){
				dp[i+1][j]=lmin(dp[i+1][j],dp[i][j]+data[a[i]]-data[j]);
			}
			if(a[i]<j){
				dp[i+1][j]=lmin(dp[i+1][j],dp[i][j]+data[j]-data[a[i]]);
				dp[i+1][a[i]]=lmin(dp[i+1][a[i]],dp[i][j]);
			}
			if(j<data.size()-1)dp[i+1][j]=lmin(dp[i+1][j],dp[i+1][j+1]);
		}
	}
	for(int i=0;i<data.size();i++){
		res=lmin(res,dp[n][i]);
	}
	printf("%lld\n",res);
	return 0;
}