#include<iostream>
#include<cstdio>
#include<cstring>

using namespace std;
#define N (1<<17)
int n;
int p;
int a[50001];
int seg[1<<18];

void add(int k,int a){
	k+=N-1;
	seg[k]=a;
	while(k>0){
		k=(k-1)/2;
		seg[k]=max(seg[k*2+1],seg[k*2+2]);
	}
}

int query(int a,int b,int k=0,int l=0,int r=N){
	if(r<=a || b<=l)return 0;
	if(a<=l && r<=b)return seg[k];
	int m=(l+r)/2;
	int le=query(a,b,k*2+1,l,m);
	int ri=query(a,b,k*2+2,m,r);
	return max(le,ri);
}

int main(void){
	scanf("%d",&n);
	for(int test=0;test<n;test++){
		scanf("%d",&p);
		memset(seg,0,sizeof(seg));
		for(int i=0;i<p;i++)scanf("%d",&a[i]);
		for(int i=0;i<p;i++){
			int v=query(0,a[i]);
			add(a[i],v+1);
		}
		printf("%d\n",query(0,N));
	}
	return 0;
}