#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>
#include<map>
#include<algorithm>

using namespace std;

typedef pair<int,int> P;
int t;
vector<P> wsl;
int n;

int main(void){
	scanf("%d",&t);
	for(int ds=0;ds<t;ds++){
		wsl.clear();
		scanf("%d",&n);
		for(int i=0;i<n;i++){
			int a,b;
			scanf("%d%d",&a,&b);
			wsl.push_back(P(a,b));
		}
		sort(wsl.begin(),wsl.end());
		int cnt=0;
		while(wsl.size()>0){
			cnt++;
			int a=wsl[0].second;
			vector<P> wsl2;
			for(int i=1;i<wsl.size();i++){
				if(a<=wsl[i].second)a=wsl[i].second;
				else wsl2.push_back(P(wsl[i].first,wsl[i].second));
			}
			wsl=wsl2;
		}
		printf("%d\n",cnt);
	}
	return 0;
}
