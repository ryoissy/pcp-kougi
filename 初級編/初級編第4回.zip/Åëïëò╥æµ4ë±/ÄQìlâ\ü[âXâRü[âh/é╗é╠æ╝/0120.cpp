// 0120.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstdio>
#include<cmath>
#include<vector>
#include<string>
#include<sstream>

using namespace std;

const double INF=10000000;
double l;
bool flag;
string str;
vector<double> r;
double dp[1<<12][12];

void rec(int x,int bit,double nl,double nh){
	if(dp[bit][x]<nl)return;
	dp[bit][x]=nl;
	if(bit==(1<<r.size())-1){
		if(nl+nh<=l)flag=true;
		return;
	}
	else{
		for(int i=0;i<r.size();i++){
			if(!(bit>>i & 1)){
				double nnh=r[i];
				double nnl=nl+sqrt(pow(nh+nnh,2)-pow(fabs(nh-nnh),2));
				if(nnl<dp[bit | 1<<i][i]){
					dp[bit | 1<<i][i]=nnl;
					rec(i,bit | 1<<i,nnl,nnh);
				}
			}
		}
	}
}


int main(void){
	while(getline(cin,str)){
		flag=false;
		r.clear();
		for(int i=0;i<(1<<12);i++){
			for(int j=0;j<12;j++){
				dp[i][j]=INF;
			}
		}
		stringstream input(str);
		input >> l;
		double a;
		while(input >> a)r.push_back(a);
		for(int i=0;i<r.size();i++){
			rec(i,1<<i,r[i],r[i]);
		}
		if(flag)cout << "OK" << endl;
		else cout << "NA" << endl;
	}
    return 0;
}
