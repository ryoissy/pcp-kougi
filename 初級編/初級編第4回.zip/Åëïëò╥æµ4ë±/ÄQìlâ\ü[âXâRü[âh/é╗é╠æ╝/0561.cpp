// 0561.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<vector>
#include<cstring>
#include<algorithm>
#include<functional>
using namespace std;


vector<int> book[10];
vector<int> sell[10];
int dp[11][2001];
int main(void){
	int n,k,res=0;
	memset(dp,0,sizeof(dp));
	scanf("%d%d",&n,&k);
	for(int i=0;i<n;i++){
		int a,b;
		scanf("%d%d",&a,&b);
		book[b-1].push_back(a);
	}
	for(int i=0;i<10;i++)sort(book[i].begin(),book[i].end(), greater<int>() );
	for(int i=0;i<10;i++){
		sell[i].push_back(0);
		if(book[i].size()>0)sell[i].push_back(book[i][0]);
		for(int j=1;j<book[i].size();j++){
			book[i][j]+=book[i][j-1];
			sell[i].push_back(book[i][j]+j*(j+1));
		}
	}
	
	for(int i=0;i<10;i++){
		for(int j=0;j<sell[i].size();j++){
			for(int l=0;l<=k;l++){
				if(l>=j){
					dp[i+1][l]=max(max(dp[i+1][l],dp[i][l]),dp[i][l-j]+sell[i][j]);
				}else dp[i+1][l]=max(dp[i+1][l],dp[i][l]);
			}
		}
	}
	cout << dp[10][k] << endl;
    return 0;
}
