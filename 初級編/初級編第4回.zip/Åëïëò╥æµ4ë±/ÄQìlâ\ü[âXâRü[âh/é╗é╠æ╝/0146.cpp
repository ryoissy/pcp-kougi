// 0146.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
using namespace std;

const double INF=10000000000000;
int n;
int num[16];
double to[16];
double s[16];
double dp[1<<16][16];
double ans=INF;
int r[16];
int ansr[16]; 

void dfs(int x,double t,double w,int bit,int root[16],int k){
	if(t>dp[bit][x])return;
	if(bit==(1<<n)-1 && ans>t){
		ans=t;
		for(int i=0;i<n;i++){
			ansr[i]=root[i];
		}
	}
	else{
		for(int i=0;i<n;i++){
			if(!(bit>>i & 1)){
				double v=2000.0/(70.0+w);
				double ct=t+(fabs(to[x]-to[i])/v);
				double nw=w+s[i]*20;
				root[k]=num[i];
				if(dp[bit | 1<<i][i]>ct){
					dp[bit | 1<<i][i]=ct;
					dfs(i,ct,nw,(bit | 1<<i),root,k+1);
				}
			}
		}
	}
}

int main(void){
	cin >> n;
	for(int i=0;i<(1<<16)-1;i++){
		for(int j=0;j<16;j++){
			dp[i][j]=INF;
		}
	}
	for(int i=0;i<n;i++){
		cin >> num[i] >> to[i] >> s[i];
	}
	for(int i=0;i<n;i++){
		r[0]=num[i];
		dfs(i,0,s[i]*20,1<<i,r,1);
	}
	for(int i=0;i<n;i++){
		if(i!=0)cout << " ";
		cout << ansr[i];
	}
	cout << endl;
    return 0;
}
