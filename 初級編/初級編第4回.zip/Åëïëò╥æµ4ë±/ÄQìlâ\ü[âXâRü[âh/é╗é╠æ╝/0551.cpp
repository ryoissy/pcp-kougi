// 0551.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstring>
using namespace std;

int n,l;
int ice[100002],memo[100002];

int drop(int i){
	if(~memo[i])return memo[i];
	int res=0;
	if(ice[i+1]>ice[i])res=max(res,drop(i+1));
	if(ice[i-1]>ice[i])res=max(res,drop(i-1));
	return memo[i]=res+(l-ice[i]);
}

int main(void){
	int ans=0;
	scanf("%d%d",&n,&l);
	memset(ice,0,sizeof(ice));
	memset(memo,-1,sizeof(memo));
	for(int i=1;i<=n;i++){
		scanf("%d",&ice[i]);
	}
	for(int i=1;i<=n;i++){
		ans=max(ans,drop(i));
	}
	printf("%d\n",ans);
    return 0;
}
