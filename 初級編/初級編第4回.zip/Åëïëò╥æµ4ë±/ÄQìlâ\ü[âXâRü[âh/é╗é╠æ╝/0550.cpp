// 0550.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstring>
using namespace std;
int n;
int cut[10001];
long long int INF=10000*10000;
long long int dp[2][5001][2];

int main(void){
	scanf("%d",&n);
	for(int i=1;i<n;i++){
		scanf("%d",&cut[i]);
	}
	//INF
	for(int i=0;i<2;i++){
		for(int j=0;j<5001;j++){
			for(int k=0;k<2;k++){
				dp[i][j][k]=INF;
			}
		}
	}
	//0:n�ɕ�����̂�0�b
	dp[0][0][0]=0;
	dp[1][0][0]=0;
	for(int i=0;i<=n/2;i++){
		for(int j=0;j<=n/2;j++){
			//�ė��p
			if(i>0){
				dp[i%2][j][0]=dp[(i+1)%2][j][0];
				dp[i%2][j][1]=dp[(i+1)%2][j][0]+cut[i+j];
			}
			if(j>0){
				dp[i%2][j][0]=min(dp[i%2][j][0],dp[i%2][j-1][1]+cut[i+j]);
				dp[i%2][j][1]=min(dp[i%2][j][1],dp[i%2][j-1][1]);
			}
		}
	}
	printf("%d\n",min(dp[n%2][n/2][0],dp[n%2][n/2][1]));
    return 0;
}
