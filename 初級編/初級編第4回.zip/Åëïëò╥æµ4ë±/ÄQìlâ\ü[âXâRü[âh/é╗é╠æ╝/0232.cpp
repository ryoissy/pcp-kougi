#include "StdAfx.h"
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
#define rep(i,n)for(int i=0;i<n;i++)
#define MAXCOST 5000
double dp[51][MAXCOST+1];
int v[4];
struct INFO{
	int type,val;
	INFO(){
		type=0;val=0;
	}; 
};
INFO mass[51];    
int main(){
	int x,y,z;
	while(cin >> x >> y >> z , x){
		rep(i,51)mass[i] = INFO(); 
		rep(i,51)rep(j,MAXCOST+1)dp[i][j] = 0;
		rep(i,x)cin >> v[i];      
		int mxcost = 0;   
		rep(i,z){       
			int N;           
			cin >> N;          
			cin >> mass[N].type >> mass[N].val;       
			if(mass[N].type == 2)mxcost += mass[N].val;       
		}    
		double baseProb = 1.0/x;  
		dp[0][0] = 1;      
		for(int pos = 0; pos < y ; pos++){      
			for(int cost = 0 ; cost <= mxcost ; cost++){         
				rep(i,x){                 
					int nextPos = pos+v[i];               
					if(nextPos > y)nextPos = y;         
					if(mass[nextPos].type == 0){          
						dp[nextPos][cost] += dp[pos][cost] * baseProb;    
					}                            
					if(mass[nextPos].type == 1){    
						int newPos = nextPos + mass[nextPos].val;   
						if(newPos > y)newPos = y;        
						dp[newPos][cost] += dp[pos][cost] * baseProb;     
					}                 
					if(mass[nextPos].type == 2){         
						int newCost = mass[nextPos].val + cost;        
						dp[nextPos][newCost] += dp[pos][cost] * baseProb;      
					}                  
					if(mass[nextPos].type == 3){  
						int newCost = cost - mass[nextPos].val;      
						if(newCost < 0)newCost = 0;              
						dp[nextPos][newCost] += dp[pos][cost] * baseProb;   
					}            
				}      
			}       
		}   
		double sum = 0;    
		for(int i = 0; i <= mxcost ;i++){     
			sum += dp[y][i] * i;     
		}      
		cout << (int)sum << endl;     
	}
}