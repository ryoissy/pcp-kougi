// 0191.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

int n,m;
double ans;
double dp[101][101];
double up[101][101];
int main(void){
	for(int i=1;i<=100;i++){
		up[i][0]=1.0;
	}
	while(1){
		memset(dp,0,sizeof(dp));
		ans=0;
		cin >> n >> m;
		if(n==0 && m==0)break;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				cin >> up[j][i];
			}
		}
		dp[0][0]=1;
		for(int i=1;i<=m;i++){
			for(int j=1;j<=n;j++){
				for(int k=0;k<=n;k++){
					dp[i][j]=max(dp[i][j],dp[i-1][k]*up[j][k]);
				}
				if(i==m)ans=max(ans,dp[i][j]);
			}
		}
		printf("%0.2f\n",ans);
	}
    return 0;
}
