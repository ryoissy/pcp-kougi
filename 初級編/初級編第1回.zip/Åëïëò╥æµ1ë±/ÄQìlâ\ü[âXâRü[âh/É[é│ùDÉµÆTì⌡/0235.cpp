#include<cstdio>
#include<vector>
#include<cstring>
#include<map>

using namespace std;

typedef unsigned short us;
struct edge{
	int t;
	us c;
	edge(int t,us c):t(t),c(c){}
};

int n;
us INF=50000;
vector<edge> G[21];
map<int,map<int,us> > dp;
bool used[21];
us res=0;

void dfs(int v,int bit,us c){
	if(dp[bit][v]!=0 && dp[bit][v]<c)return;
	dp[bit][v]=c;
	if(bit==(1<<n)-1)res=min(c,res);
	else{
		for(int i=0;i<G[v].size();i++){
			edge e=G[v][i];
			if(used[e.t])continue;
			int nbit=bit | (1<<e.t);
			dfs(e.t,nbit,e.c+c);
		}
	}
}

int main(void){
	while(1){
		scanf("%d",&n);
		if(n==0)break;
		memset(used,false,sizeof(used));
		res=INF;
		dp.clear();
		for(int i=0;i<n;i++)G[i].clear();
		for(int i=0;i<n-1;i++){
			int a,b;
			us c;
			scanf("%d%d%hd",&a,&b,&c);
			a--,b--;
			G[a].push_back(edge(b,c));
			G[b].push_back(edge(a,c));
		}
		/*
		for(int i=0;i<(1<<n);i++){
			for(int j=0;j<n;j++)dp[i][j]=INF;
		}
		*/
		int st=1;
		for(int i=1;i<n;i++){
			if(G[i].size()==1){
				st|=1<<i;
				used[i]=true;
			}
		}
		dfs(0,st,0);
		printf("%d\n",res);
	}
	return 0;
}