#include<iostream>
#include<cstdio>
#include<vector>

using namespace std;

int w,h;
int ans=1;
char tile[21][21];

void saiki(int x,int y){
	if(x<0 | x>h | y<0 | y>w)return;
	tile[x][y]='#';
	if(tile[x-1][y]=='.')ans++,saiki(x-1,y);
	if(tile[x+1][y]=='.')ans++,saiki(x+1,y);
	if(tile[x][y-1]=='.')ans++,saiki(x,y-1);
	if(tile[x][y+1]=='.')ans++,saiki(x,y+1);
}

int main(void){
	int a,b; 
	while(1){
		for(a=0;a<21;a++){
			for(b=0;b<21;b++){
				tile[a][b]='\0';
			}
		}
		scanf("%d %d",&w,&h);
		if(w==0 && h==0)break;
		ans=1;
		for(a=0;a<h;a++){
			scanf("%s",tile[a]);
		}
		for(a=0;a<h;a++){
			for(b=0;b<w;b++){
				if(tile[a][b]=='@')saiki(a,b);
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}