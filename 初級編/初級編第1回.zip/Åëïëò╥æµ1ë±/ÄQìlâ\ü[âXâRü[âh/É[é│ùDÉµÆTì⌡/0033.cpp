#include<iostream>
#include<cstdio>
#include<string>
#include<vector>
using namespace std;


int res=0;

bool saiki(int ball[],int ttB,int ttC,int res){
	if(res==10)return true;
	if(ball[res]>ttB){
		return saiki(ball,ball[res],ttC,res+1);
	}
	if(ball[res]>ttC){
		return saiki(ball,ttB,ball[res],res+1);
	}
	return false;
}

int main(void){
	int a,b;
	int ball[11];
	int ttB=0,ttC=0;
	int n;
	scanf("%d",&n);
	for(a=0;a<n;a++){
		for(b=0;b<10;b++){
			ball[b]=0;
		}
		ttB=0;
		ttC=0;
		res=0;
		for(b=0;b<10;b++){
			scanf("%d",&ball[b]);
		}
		if(saiki(ball,ttB,ttC,res)==true)printf("YES\n");else printf("NO\n");
	}
	return 0;
}
