#include<iostream>
#include<cstdio>
#include<cstring>

using namespace std;
int n,num;
int dp[11][10];
int ansn[11];
int k[11];
bool flag=true;
void dfs(int x,int sum,int bit){
	if(!flag)return;
	if(x==n && sum==num){
		for(int i=0;i<n;i++)ansn[i]=k[i];
		flag=false;
		return;
	}
	if(x<n){
		for(int i=1;i<=n;i++){
			if(!(bit >> i & 1)){
				int nbit=bit | 1 << i ;
				k[x]=i;
				int nsum=sum+i*dp[n][x];
				dfs(x+1,nsum,nbit);
			}
		}
	}
}

int main(void){
	dp[1][0]=1;
	for(int i=2;i<=10;i++){
		dp[i][0]=1;
		for(int j=1;j<i;j++){
			dp[i][j]=dp[i-1][j]+dp[i-1][j-1];
		}
	}
	scanf("%d%d",&n,&num);
	dfs(0,0,0);
	printf("%d",ansn[0]);
	for(int i=1;i<n;i++)printf(" %d",ansn[i]);
	printf("\n");
	return 0;
}
