#include<cstdio>
#include<cstring>
#include<cmath>

#define INF 2e9
int min,n,size;
int cnt[10];
int now[10];
int flag[2];
int abs(int a,int b){
	if(a>b)return a-b;
	return b-a;
}

int p[10];

void dfs(int a,int b,int v,int c){
	if(v==size){
		if(flag[0]>0 && a!=0)return;
		if(flag[1]>0 && b!=0)return;
		if(min>abs(a,b))min=abs(a,b);
	}else{
		if(v==c && a-p[size-c]+1>min)return;
		for(int i=0;i<=9;i++){
			if(now[i]<cnt[i]){
				if(i==0){
					now[i]++;
					if(v<c){
						if(a==0)flag[0]++;
						dfs(a*10,b,v+1,c);
						if(a==0)flag[0]--;
					}
					if(v>=c){
						if(b==0)flag[1]++;
						dfs(a,b*10,v+1,c);
						if(b==0)flag[1]--;
					}
					now[i]--;
				}else{
					now[i]++;
					if(v<c){
						if(flag[0]==0)dfs(a*10+i,b,v+1,c);
					}
					if(v>=c){
						if(flag[1]==0)dfs(a,b*10+i,v+1,c);
					}
					now[i]--;
				}
			}
		}
	}
}

int main(void){
	scanf("%d",&n);
	p[0]=1;
	for(int i=0;i<10;i++)p[i+1]=p[i]*10;
	for(int i=0;i<n;i++){
		memset(cnt,0,sizeof(cnt));
		size=0;
		while(1){
			int a;
			char b;
			scanf("%d%c",&a,&b);
			cnt[a]++;
			size++;
			if(b=='\n')break;
		}
		min=INF;
		flag[0]=flag[1]=0;
		for(int i=(size+1)/2;i<size;i++){
			if(min==INF)dfs(0,0,0,i);
		}
		printf("%d\n",min);
	}	
	return 0;
}