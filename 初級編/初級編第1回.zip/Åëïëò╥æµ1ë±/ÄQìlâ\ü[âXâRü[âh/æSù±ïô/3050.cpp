// 3050.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstdio>
#include<string>
#include<map>
#include<set>
using namespace std;

set<string> v;
string str[6];
int dx[4]={0,0,1,-1};
int dy[4]={1,-1,0,0};

void check(int x,int y,string ss,int n){
	if(n==6)v.insert(ss);
	else{
		ss+=str[x][y];
		for(int i=0;i<4;i++){
			if(x+dx[i]>=0 && x+dx[i]<5 && y+dy[i]>=0 && y+dy[i]<5)check(x+dx[i],y+dy[i],ss,n+1);
		}
	}
}

int main(void){
	string s;
	for(int i=0;i<5;i++){
		for(int j=0;j<5;j++){
			string st;
			cin >> st;
			str[i]+=st;
		}
	}
	for(int i=0;i<5;i++){
		for(int j=0;j<5;j++){
			check(i,j,s,0);
		}
	}
	cout << v.size() << endl;
    return 0;
}
