// 3669.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
#include<map>
using namespace std;

typedef pair<int,int> P;
typedef pair<P,int> PP;
const int INF=100000;
int fie[501][501];
bool used[501][501];
int ans=INF;
int m;
int dx[4]={0,0,1,-1};
int dy[4]={1,-1,0,0};
int main(void){
	for(int i=0;i<=500;i++){
		for(int j=0;j<=500;j++){
			fie[i][j]=INF;
		}
	}
	memset(used,false,sizeof(used));
	cin >> m;
	for(int i=0;i<m;i++){
		int x,y,t;
		cin >> x >> y >> t;
		for(int i=max(x-1,0);i<=min(500,x+1);i++){
				fie[i][y]=min(fie[i][y],t);
		}
		for(int i=max(y-1,0);i<=min(500,y+1);i++){
				fie[x][i]=min(fie[x][i],t);
		}
	}
	queue<PP> que;
	que.push(PP(P(0,0),0));
	used[0][0]=true;
	while(que.size()){
		PP p=que.front();que.pop();
		int x=p.first.first,y=p.first.second,t=p.second;
		if(fie[x][y]==INF){
			ans=t;
			break;
		}
		for(int i=0;i<4;i++){
			if(x+dx[i]>=0 && x+dx[i]<=500 && y+dy[i]>=0 && y+dy[i]<=500){
				if(used[x+dx[i]][y+dy[i]]==false && t+1<fie[x+dx[i]][y+dy[i]]){
					used[x+dx[i]][y+dy[i]]=true;
					que.push(PP(P(x+dx[i],y+dy[i]),t+1));
				}
			}
		}
	}
	if(fie[0][0]==0)ans=-1;
	if(ans==INF)ans=-1;
	cout << ans << endl;
    return 0;
}
