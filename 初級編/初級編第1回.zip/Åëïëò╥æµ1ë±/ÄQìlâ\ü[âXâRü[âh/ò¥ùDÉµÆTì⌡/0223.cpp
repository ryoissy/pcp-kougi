// 0223.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<map>
#include<queue>

using namespace std;

const int NOT=-1;
int maps[51][51];
int x,y;
int tx,ty;
int kx,ky;
int ans=101;
int dx[4]={0,1,0,-1},dy[4]={1,0,-1,0};
int sai[52][52][52][52];
typedef pair<int,int> P;
typedef pair<P,P> PP;

void bfs(){
	queue<PP> pp;
	int a,b,c,d;
	for(a=0;a<=50;a++){
		for(b=0;b<=50;b++){
			for(c=0;c<=50;c++){
				for(d=0;d<=50;d++){
					sai[a][b][c][d]=NOT;
				}
			}
		}
	}
	pp.push(PP(P(tx,ty),P(kx,ky)));
	sai[tx][ty][kx][ky]=0;
	while(pp.size()){
		PP p=pp.front();pp.pop();
		if(p.first.first==p.second.first && p.first.second==p.second.second){
			ans=sai[p.first.first][p.first.second][p.second.first][p.second.second];
			break;
		}
		if(sai[p.first.first][p.first.second][p.second.first][p.second.second]<100){
			for(a=0;a<4;a++){
				int ntx,nty,nkx=p.second.first-dx[a],nky=p.second.second-dy[a];
				
				if(maps[p.first.first+dx[a]][p.first.second+dy[a]]==0 && p.first.first+dx[a]>=1 && p.first.first+dx[a]<=x && p.first.second+dy[a]>=1 && p.first.second+dy[a]<=y){
					ntx=p.first.first+dx[a],nty=p.first.second+dy[a];
				}else ntx=p.first.first,nty=p.first.second;

				if(maps[p.second.first-dx[a]][p.second.second-dy[a]]==0 && p.second.first-dx[a]>=1 && p.second.first-dx[a]<=x && p.second.second-dy[a]>=1 && p.second.second-dy[a]<=y){
					nkx=p.second.first-dx[a],nky=p.second.second-dy[a];
				}else nkx=p.second.first,nky=p.second.second;
				
				if(sai[ntx][nty][nkx][nky]==NOT){
					pp.push(PP(P(ntx,nty),P(nkx,nky)));
					sai[ntx][nty][nkx][nky]=sai[p.first.first][p.first.second][p.second.first][p.second.second]+1;
				}
			}
		}
	}
}

int main(void){
	while(1){
		cin >> x >> y;
		if(x==0 && y==0)break;
		cin >> tx >> ty;
		cin >> kx >> ky;
		int a,b;
		ans=101;
		for(a=1;a<=y;a++){
			for(b=1;b<=x;b++){
				cin >> maps[b][a];
			}
		}
		bfs();
		if(ans<=100)cout << ans << endl;else cout << "NA" << endl;
	}
	return 0;
}