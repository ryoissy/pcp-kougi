// 0122.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstring>
#include<queue>
using namespace std;

typedef pair<int,int> P;
typedef pair<P,int> PP;

int spx[11],spy[11];
const int jux[12]={-2,-2,-2,2,2,2,-1,0,1,-1,0,1};
const int juy[12]={-1,0,1,-1,0,1,-2,-2,-2,2,2,2};
int x,y,n;

bool pyon(){
	queue<PP> M;
	M.push(PP(P(x,y),1));
	while(!M.empty()){
		PP m=M.front();M.pop();
		int mx=m.first.first,my=m.first.second,ms=m.second;
		for(int a=0;a<12;a++){
			int nx=mx+jux[a],ny=my+juy[a];
			if(nx>=0 && nx<=9 && ny>=0 && ny<=9){
				if(nx>=spx[ms]-1 && nx<=spx[ms]+1 && ny>=spy[ms]-1 && ny<=spy[ms]+1){
					if(ms==n)return true;
					else{
						M.push(PP(P(nx,ny),ms+1));
					}
				}
			}
		}
	}
	return false;
}

int main(void){
	while(1){
		int a;
		scanf("%d%d",&x,&y);
		if(x==0 && y==0)break;
		scanf("%d",&n);
		for(a=1;a<=n;a++){
			int xx,yy;
			scanf("%d%d",&xx,&yy);
			spx[a]=xx,spy[a]=yy;
		}
		if(pyon())cout << "OK" << endl;else cout << "NA" << endl;
	}
    return 0;
}
