// 0193.cpp : ���C�� �v���W�F�N�g �t�@�C���ł��B

#include "stdafx.h"
#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>

using namespace std;

typedef pair<int,int> P;
typedef pair<int,P> PP;

int fie[101][101];
bool fie2[101][101];
int cox[11],coy[11];
int m,n,s,sn;
int ans=0;
const int dx1[6]={-1,-1,-1,0,1,0};
const int dx0[6]={0,-1,0,1,1,1};
const int dy[6]={-1,0,1,-1,0,1};
const int INF=100000;

void bfs(int x,int y){
	queue<PP> que;
	que.push(PP(0,P(x,y)));
	fie[x][y]=0;
	while(que.size()){
		PP p=que.front();que.pop();
		int v=p.first,kx=p.second.first,ky=p.second.second;
		for(int i=0;i<6;i++){
			int fx=kx,fy=ky+dy[i];
			if(ky%2==1)fx+=dx1[i];
			if(ky%2==0)fx+=dx0[i];
			if(fx>=1 && fx<=m && fy>=1 && fy<=n){
				if(fie[fx][fy]>v+1){
					que.push(PP(v+1,P(fx,fy)));
					fie[fx][fy]=v+1;
				}
			}
		}
	}
}

int bfs2(int x,int y){
	memset(fie2,false,sizeof(fie2));
	int res=1;
	if(fie[x][y]==0)return 0;
	queue<PP> que;
	que.push(PP(0,P(x,y)));
	fie2[x][y]=true;
	while(que.size()){
		PP p=que.front();que.pop();
		int v=p.first,kx=p.second.first,ky=p.second.second;
		for(int i=0;i<6;i++){
			int fx=kx,fy=ky+dy[i];
			if(ky%2==1)fx+=dx1[i];
			if(ky%2==0)fx+=dx0[i];
			if(fx>=1 && fx<=m && fy>=1 && fy<=n){
				if(fie[fx][fy]>v+1 && fie2[fx][fy]==false){
					que.push(PP(v+1,P(fx,fy)));
					res++;
					fie2[fx][fy]=true;
				}
			}
		}
	}
	return res;
}

int main(void){
	while(1){
		scanf("%d",&m);
		if(m==0)break;
		scanf("%d",&n);
		for(int i=0;i<=100;i++){
			for(int j=0;j<=100;j++){
				fie[i][j]=INF;
			}
		}
		ans=0;
		scanf("%d",&s);
		for(int i=0;i<s;i++){
			int x,y;
			scanf("%d%d",&x,&y);
			bfs(x,y);
		}
		scanf("%d",&sn);
		for(int i=0;i<sn;i++){
			int x,y;
			scanf("%d%d",&x,&y);
			ans=max(ans,bfs2(x,y));
		}
		printf("%d\n",ans);
	}
    return 0;
}
