#include<iostream>
#include<cstdio>
#include<string>
#include<vector>
#include<map>
#include<queue>
#include<algorithm>
 
using namespace std;
const int INF=100000000;
 
typedef pair<int, int> P;
 
int h,w,n;
int ans=0;
int sx,sy;
int kx[10],ky[10];
long int field[1001][1001],field2[1001][1001];
char str[1001];
int dx[4]={1,0,-1,0},dy[4]={0,1,0,-1,};
 
int bfs(int x,int y,int e){
    int a=0,b=0;
    queue<P> que;
    for(a=0;a<h;a++){
        for(b=0;b<w;b++){
            field2[b][a]=INF;
        }
    }
    que.push(P(x,y));
    field2[x][y]=0;
    while(que.size()){
        P p=que.front();que.pop();
        if(p.first==kx[e] && p.second==ky[e])break;
        for(a=0;a<4;a++){
            int nx=p.first+dx[a],ny=p.second+dy[a];
            if(0<=nx && nx<w && 0<=ny && ny<h && field[nx][ny]!=-1 && field2[nx][ny]==INF){
                que.push(P(nx,ny));
                field2[nx][ny]=field2[p.first][p.second]+1;
            }
        }
    }
    return field2[kx[e]][ky[e]];
}
 
int main(void){
    int a,b;
    scanf("%d %d %d",&h,&w,&n);
    for(a=0;a<h;a++){
        scanf("%s",str);
        for(b=0;b<w;b++){
            if(str[b]=='S')sx=b,sy=a;
            if(str[b]=='X')field[b][a]=-1;
            else field[b][a]=0;
            if('1' <= str[b] && str[b] <= '9'){
                field[b][a]=str[b]-'0';
                kx[field[b][a]]=b;
                ky[field[b][a]]=a;
            }
        }
    }
    for(a=1;a<=n;a++){
        if(a==1)ans+=bfs(sx,sy,a);
        if(a>1)ans+=bfs(kx[a-1],ky[a-1],a);
    }
    printf("%d\n",ans);
    return 0;
}