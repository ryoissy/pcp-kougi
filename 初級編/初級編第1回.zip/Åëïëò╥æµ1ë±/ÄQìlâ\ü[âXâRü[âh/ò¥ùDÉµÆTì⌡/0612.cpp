#include <cstdio>
#include <string>
#include <iostream>
#include <queue>
#include <algorithm>

using namespace std;

typedef pair<int,int> P;
int h,w;
int fie[1001][1001];
int fade[1001][1001];
int cnt[1001][1001];
int t[1001][1001];

int bfs(){
	queue<P> que;
	int res=0;
	for(int i=0;i<h;i++){
		for(int j=0;j<w;j++){
			int none=0;
			for(int k=-1;k<=1;k++){
				for(int l=-1;l<=1;l++){
					int y=i+k,x=j+l;
					if(x>=0 && x<w && y>=0 && y<h){
						if(fie[y][x]==0)none++;
					}
				}
			}
			cnt[i][j]=none;
			if(none>=fie[i][j] && fie[i][j]>=1){
				t[i][j]=1;
				fade[i][j]=1;
				que.push(P(i,j));
			}
		}
	}
	while(que.size()){
		P q=que.front();
		que.pop();
		int y=q.first,x=q.second;
		fie[y][x]=0;
		for(int i=-1;i<=1;i++){
			for(int j=-1;j<=1;j++){
				int nx=x+j,ny=y+i;
				if(nx>=0 && nx<w && ny>=0 && ny<h){
					cnt[ny][nx]++;
					if(cnt[ny][nx]>=fie[ny][nx] && fie[ny][nx]>=1 && fade[ny][nx]==0){
						fade[ny][nx]=1;
						t[ny][nx]=t[y][x]+1;
						que.push(P(ny,nx));
					}
				}
			}
		}

	}
	for(int i=0;i<h;i++){
		for(int j=0;j<w;j++){
			res=max(res,t[i][j]);
		}
	}
	return res;
}

int main(void){
	scanf("%d %d",&h,&w);
	for(int i=0;i<h;i++){
		string str;
		cin >> str;
		for(int j=0;j<w;j++){
			if(str[j]>='0' && str[j]<='9')fie[i][j]=str[j]-'0';
		}
	}
	printf("%d\n",bfs());
	return 0;
}