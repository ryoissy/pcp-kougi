#include<iostream>
#include<string> 
using namespace std;

int farm[101][101];
int h,w;

void kubun(int k,int a,int b){
	if(a<0 | a>w | b<0 | b>h)return;
	farm[a][b]=0;
	if(k==farm[a-1][b])kubun(farm[a-1][b],a-1,b);
	if(k==farm[a+1][b])kubun(farm[a+1][b],a+1,b);
	if(k==farm[a][b-1])kubun(farm[a][b-1],a,b-1);
	if(k==farm[a][b+1])kubun(farm[a][b+1],a,b+1);
	
}
int main(void){
	char c[101][101];
	int a,b;
	int ans=0;
	while(1){
		ans=0;
		for(b=0;b<101;b++){
			for(a=0;a<101;a++){
				farm[a][b]=0;
			}
		}
		scanf("%d %d",&h,&w);
		if(h==0 && w==0)break;
		for(b=0;b<h;b++){
			scanf("%s",c[b]);   
			for(a=0;a<w;a++){
				if(c[b][a]=='@')farm[a][b]=1;
				if(c[b][a]=='#')farm[a][b]=2;
				if(c[b][a]=='*')farm[a][b]=3;
				
			}
		}
		for(b=0;b<h;b++){
			for(a=0;a<w;a++){
				if(farm[a][b]==0);
				else{
					ans++;
					kubun(farm[a][b],a,b); 
				}
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}