#include<iostream>
#include<cstdio>
#include<queue>
#include<algorithm>
#include<functional>
#include<vector>

using namespace std;

typedef pair<int,int> P;
int c,l;
P cow[3000];
P btl[3000];
int main(void){
	scanf("%d%d",&c,&l);
	for(int i=0;i<c;i++)scanf("%d%d",&cow[i].first,&cow[i].second);
	for(int i=0;i<l;i++)scanf("%d%d",&btl[i].first,&btl[i].second);
	sort(cow,cow+c);
	sort(btl,btl+l);
	priority_queue<int,vector<int>,greater<int> > que;
	int cn=0;
	int cnt=0;
	for(int i=0;i<l;i++){
		//printf("%d\n",i);
		while(btl[i].first>=cow[cn].first && cn<c){
			que.push(cow[cn++].second);
			//printf("%d %d\n",i,cn);
		}
		int canuse=btl[i].second;
		while(canuse>0){
			if(!que.size())break;
			int spf=que.top();
			que.pop();
			if(btl[i].first<=spf)cnt++;
			else canuse++;
			//printf("%d %d %d\n",i,spf,cnt);
			canuse--;
		}
	}
	printf("%d\n",cnt);
	return 0;
}