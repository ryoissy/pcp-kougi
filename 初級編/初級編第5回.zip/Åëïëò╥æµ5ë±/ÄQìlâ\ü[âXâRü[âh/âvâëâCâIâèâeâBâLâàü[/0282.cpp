#include<iostream>
#include<cstdio>
#include<algorithm>
#include<queue>
#include<functional>
#include<cstring>
#define N (1<<17)
 
using namespace std;
typedef long long ll;
ll dat[1<<18];
int id[1<<18];
int n,r,l;
int d[1000001],t[1000001],x[1000001];
int timel[100001];
 
void init(){
    memset(dat,0,sizeof(dat));
    for(int i=N;i<N*2;i++)id[i]=i-N;
}
 
void update(int k,ll a){
    k+=N-1;
    dat[k]+=a;
    while(k>0){
        k=(k-1)/2;
        if(dat[k*2+1]>=dat[k*2+2]){
            dat[k]=dat[k*2+1];
            id[k]=id[k*2+1];
        }else{
            dat[k]=dat[k*2+2];
            id[k]=id[k*2+2];
        }
    }
}
 
int main(void){
    scanf("%d%d%d",&n,&r,&l);
    for(int i=0;i<r;i++)scanf("%d%d%d",&d[i],&t[i],&x[i]);
    int nt=0;
    init();
    for(int i=0;i<r;i++){
        timel[id[0]]+=t[i]-nt;
        nt=t[i];
        update(d[i],x[i]);
    }
    timel[id[0]]+=l-nt;
    int sum=0,rid=0;
    for(int i=0;i<n;i++){
        if(sum<timel[i])sum=timel[i],rid=i;
    }
    printf("%d\n",rid+1);
    return 0;
}