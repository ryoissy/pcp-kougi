#include<iostream>
#include<cstdio>
#include<queue>
#include<algorithm>

using namespace std;

typedef long long ll;
typedef pair<ll,ll> P;
int n,c;
ll f;
P cow[100001];
ll aid[100001];
ll aid2[100001];

int main(void){
	scanf("%d%d%lld",&n,&c,&f);
	for(int i=0;i<c;i++)scanf("%lld%lld",&cow[i].first,&cow[i].second);
	sort(cow,cow+c);
	ll sum=0;
	priority_queue<ll> que;
	for(int i=0;i<n/2;i++){
		que.push(cow[i].second);
		sum+=cow[i].second;
	}
	for(int i=n/2;i<c-n/2;i++){
		aid[i]=sum;
		que.push(cow[i].second);
		sum+=cow[i].second;
		ll p=que.top();
		sum-=p;
		que.pop();
	}
	sum=0;
	priority_queue<ll> que2;
	for(int i=c-1;i>=c-n/2;i--){
		que2.push(cow[i].second);
		sum+=cow[i].second;
	}
	for(int i=c-n/2-1;i>=n/2;i--){
		aid2[i]=sum;
		que2.push(cow[i].second);
		sum+=cow[i].second;
		ll p=que2.top();
		sum-=p;
		que2.pop();
	}
	ll res=-1;
	for(int i=n/2;i<=c-n/2-1;i++){
		if(f>=aid[i]+aid2[i]+cow[i].second)res=cow[i].first;
		//printf("%lld\n",aid[i]+aid2[i]+cow[i].second);
	}
	printf("%lld\n",res);
	return 0;
}
