#include <cstdio>
#include <cstring>
#include <vector>
#include <iostream>

using namespace std;

int n,q;
int edge[100001];
vector<int> G[100001];
int par[100001];
bool flag[100001];
int fm[100001];
char s[100001];
int v[100001];

void init(){
	for(int i=1;i<=n;i++){
		par[i]=i;
		G[i].clear();
	}
	memset(flag,false,sizeof(flag));
	memset(fm,-1,sizeof(fm));
}

int find(int x){
	if(par[x]==x)return x;
	return par[x]=find(par[x]);
}

void unite(int x,int y){
	x=find(x);
	y=find(y);
	if(x!=y){
		par[x]=y;
	}

}

void unite_dfs(int v,int p){
	if(!flag[v])unite(v,p);
	else p=v;
	for(int i=0;i<G[v].size();i++){
		unite_dfs(G[v][i],p);
	}
}

int main(void){
	while(1){
		scanf("%d %d",&n,&q);
		if(n+q==0)break;
		init();
		for(int i=2;i<=n;i++){
			scanf("%d",&edge[i]);
			G[edge[i]].push_back(i);
		}
		flag[1]++;
		fm[1]=-2;
		for(int i=0;i<q;i++){
			cin >> s[i] >> v[i];
			if(s[i]=='M'){
				flag[v[i]]=true;
				if(fm[v[i]]==-1)fm[v[i]]=i;
			}
		}
		unite_dfs(1,1);
		long long res=0;
		for(int i=q-1;i>=0;i--){
			if(s[i]=='Q'){
				res+=(long long)find(v[i]);
			}
			if(s[i]=='M' && fm[v[i]]==i){
				unite(v[i],edge[v[i]]);
			}
		}
		printf("%lld\n",res);

	}
	return 0;
}