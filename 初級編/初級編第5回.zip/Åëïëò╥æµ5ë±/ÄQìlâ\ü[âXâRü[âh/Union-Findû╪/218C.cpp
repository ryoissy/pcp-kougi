#include<cstdio>

int n;
int x[101],y[101];

int par[1001],rank[1001];
int cnt[1001];

void init(int x){
	for(int i=0;i<x;i++){
		par[i]=i;
		rank[i]=0;
	}
}

int find(int x){
	if(par[x]==x)return x;
	return par[x]=find(par[x]);
}

void unite(int x,int y){
	x=find(x);
	y=find(y);
	if(x!=y){
		if(rank[x]>rank[y]){
			par[y]=x;
		}else{
			par[x]=y;
			if(rank[x]==rank[y])rank[y]++;
		}
	}
}

bool same(int x,int y){
	return find(x)==find(y);
}

int main(void){
	scanf("%d",&n);
	init(n);
	for(int i=0;i<n;i++){
		scanf("%d %d",&x[i],&y[i]);
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<i;j++){
			if(x[i]==x[j] || y[i]==y[j]){
				unite(i,j);
			}
		}
	}
	for(int i=0;i<n;i++){
		cnt[find(i)]++;
	}
	int res=0;
	for(int i=0;i<n;i++){
		if(cnt[i]>0)res++;
	}
	printf("%d\n",res-1);
	return 0;
}