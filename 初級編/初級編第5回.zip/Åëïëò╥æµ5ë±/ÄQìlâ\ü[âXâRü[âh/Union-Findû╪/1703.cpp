#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<cstdlib>

using namespace std;

int t;
int n,m;
int par[100001],rank[100001];


void init(int s){
	for(int i=1;i<=s;i++)par[i]=i,rank[i]=0;
}

int find(int x){
	if(abs(par[x])==x)return x;
	else return par[x]=find(abs(par[x]))*(par[x]>0?1:-1);
}

void unite(int x,int y){
	x=find(x);
	y=find(y);
	if(rank[abs(x)]<rank[abs(y)]){
		par[abs(x)]=(x>0)?-y:y;
	}else{
		par[abs(y)]=(y>0)?-x:x;
		if(rank[abs(x)]==rank[abs(y)])rank[abs(x)]++;
	}
}

bool same(int x,int y){
	return abs(find(x))==abs(find(y));
}

int main(void){
	scanf("%d",&t);
	for(int i=0;i<t;i++){
		scanf("%d%d\n",&n,&m);
		init(n);
		for(int j=0;j<m;j++){
			char d;
			int a,b;
			scanf("%c %d %d\n",&d,&a,&b);
			if(d=='D')unite(a,b);
			if(d=='A'){
				if(!same(a,b))printf("Not sure yet.\n");
				else{
					if(find(a)==find(b))printf("In the same gang.\n");
					else if(find(a)==-find(b)) printf("In different gangs.\n");
				}
			}
		}
		
	}
	return 0;
}