#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstdlib>
using namespace std;

int n,d;
int x[1002],y[1002];
int g[1002][1002];
int gs[1002];
bool use[1002];
int par[1002],rank[1002];

void init(int s){
	for(int i=1;i<=s;i++)par[i]=i,rank[i]=0;
}

int find(int x){
	if(par[x]==x)return x;
	else return par[x]=find(par[x]);
}

void unite(int x,int y){
	x=find(x);
	y=find(y);
	if(x==y)return;
	
	if(rank[x]<rank[y]){
		par[x]=y;
	}else{
		par[y]=x;
		if(rank[x]==rank[y])rank[x]++;
	}
}

int main(void){
	scanf("%d%d",&n,&d);
	init(n);
	for(int i=1;i<=n;i++)scanf("%d%d",&x[i],&y[i]);
	for(int i=1;i<=n;i++){
		for(int j=1;j<i;j++){
			double xx=pow(fabs((double)x[i]-x[j]),2);
			double yy=pow(fabs((double)y[i]-y[j]),2);
			if(sqrt(xx+yy)<=d){
				g[i][gs[i]++]=j;
				g[j][gs[j]++]=i;
			}
		}
	}
	char c;
	while(scanf("%c",&c)!=EOF){
		if(c=='O'){
			int a;
			scanf("%d",&a);
			use[a]=true;
			for(int i=0;i<gs[a];i++)if(use[g[a][i]])unite(a,g[a][i]);
		}
		if(c=='S'){
			int a,b;
			scanf("%d%d",&a,&b);
			if(use[a] && use[b] && find(a)==find(b))printf("SUCCESS\n");
			else printf("FAIL\n");
		}
	}
	return 0;
}