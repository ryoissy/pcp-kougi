#include <cstdio>
#include <cstring>

int n,k,m;
int prev[10001],next[10001];
bool used[10001];
int main(void){
	while(1){
		scanf("%d %d %d",&n,&k,&m);
		if(n+m+k==0)break;
		for(int i=0;i<n;i++){
			prev[i]=(i+n-1)%n;
			next[i]=(i+1)%n;
		}
		int now=m-1;
		next[prev[now]]=next[now];
		prev[next[now]]=prev[now];
		for(int i=0;i<n-1;i++){
			for(int j=0;j<k;j++){
				now=next[now];
			}
			next[prev[now]]=next[now];
			prev[next[now]]=prev[now];
			//printf("%d\n",now);
		}
		printf("%d\n",next[now]+1);
	}
	return 0;
}