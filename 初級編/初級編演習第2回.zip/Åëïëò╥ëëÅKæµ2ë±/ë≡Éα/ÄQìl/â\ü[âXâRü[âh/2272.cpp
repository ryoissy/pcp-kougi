#include <cstdio>
#include <cstring>
#include <string>
#include <iostream>
#define INF 1e8
using namespace std;

int h,w;
int fie[51][51];
int dp[51][51];
int main(void){
	scanf("%d %d",&h,&w);
	for(int i=0;i<h;i++){
		string str;
		cin >> str;
		for(int j=0;j<w;j++){
			fie[j][i]=str[j]-'0';
		}
	}
	for(int i=0;i<=h;i++){
		for(int j=0;j<=w;j++){
			dp[j][i]=INF;
		}
	}
	dp[0][0]=fie[0][0];
	for(int i=0;i<h;i++){
		for(int j=0;j<w;j++){
			if(dp[j][i]!=INF){
				dp[j+1][i]=min(dp[j+1][i],dp[j][i]+fie[j+1][i]);
				dp[j][i+1]=min(dp[j][i+1],dp[j][i]+fie[j][i+1]);
			}
		}
	}
	printf("%d\n",dp[w-1][h-1]);
	return 0;
}