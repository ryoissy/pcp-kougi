#include<cstdio>
#include<queue>
#include<vector>
#include<algorithm>
#include<cstring>
#include<functional>

#define INF 111111111
using namespace std;

int n,m,l,k,a,h;
struct edge{
	int t,cost;
	edge(){}
	edge(int it,int ic){
		t=it,cost=ic;
	}
};

struct data{
	int v,cost,f;
	data(){}
	data(int iv,int iif,int icost){
		v=iv;
		f=iif;
		cost=icost;
	}
	bool operator<(const data &d1)const{
		return d1.cost<cost;
	}
};

vector<edge> G[101];
int rec[101];
int dp[101][101];

int dijk(){
	priority_queue<data> que;
	que.push(data(a,m,0));
	for(int i=0;i<n;i++){
		for(int j=0;j<=m;j++){
			dp[i][j]=INF;
		}
	}
	dp[a][m]=0;
	while(que.size()){
		data q=que.top();
		que.pop();
		if(dp[q.v][q.f]<q.cost)continue;
		dp[q.v][q.f]=q.cost;
		if(q.v==h)return q.cost;
		if(rec[q.v]==1){
			for(int i=1;i<=m-q.f;i++){
				if(dp[q.v][q.f+i]>q.cost+i){
					dp[q.v][q.f+i]=q.cost+i;
					que.push(data(q.v,q.f+i,q.cost+i));
				}
			}
		}
		for(int i=0;i<G[q.v].size();i++){
			edge e=G[q.v][i];
			if(q.f<e.cost)continue;
			if(dp[e.t][q.f-e.cost]>q.cost+e.cost){
				dp[e.t][q.f-e.cost]=q.cost+e.cost;
				que.push(data(e.t,q.f-e.cost,q.cost+e.cost));
			}
		}
	}
	return INF;
}

int main(void){
	while(1){
		scanf("%d %d %d %d %d %d",&n,&m,&l,&k,&a,&h);
		if(n+m+l+k+a+h==0)break;
		for(int i=0;i<n;i++)G[i].clear();
		memset(rec,0,sizeof(rec));
		for(int i=0;i<l;i++){
			int r;
			scanf("%d",&r);
			rec[r]=1;
		}
		for(int i=0;i<k;i++){
			int x,y,t;
			scanf("%d %d %d",&x,&y,&t);
			G[x].push_back(edge(y,t));
			G[y].push_back(edge(x,t));
		}
		int res=dijk();
		if(res==INF)printf("Help!\n");
		else printf("%d\n",res);
	}
	return 0;
}