#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

typedef long long ll;
int n,k;

struct data{
	ll s;
	int id;
};

bool comp(const data &a,const data &b){
	return a.s<b.s;
}

data dat[1000001];
ll seq[1000001];
ll que[1000001];

ll labs(ll a){
	if(a<0)return -a;
	return a;
}

int main(void){
	while(1){
		scanf("%d%d",&n,&k);
		if(n+k==0)break;
		memset(seq,-1,sizeof(seq));
		dat[0].id=0,dat[0].s=0;
		for(int i=1;i<=n;i++){
			scanf("%lld",&seq[i]);
			dat[i].id=i;
		}
		for(int i=1;i<=n;i++){
			dat[i].s=seq[i]+dat[i-1].s;
		}
		sort(dat,dat+n+1,comp);
		for(int i=0;i<k;i++){
			scanf("%lld",&que[i]);
			int s=0,t=0,rs=0,rt=0;
			ll res=(ll)1145141919,res2=0;
			while(s<=n){
				while(dat[t].s-dat[s].s<que[i] && t<=n){
					t++;
					if(labs(dat[t].s-dat[s].s-que[i])<res  && t<=n){
						res2=dat[t].s-dat[s].s;
						res=labs(dat[t].s-dat[s].s-que[i]);
						rs=min(dat[s].id,dat[t].id)+1,rt=max(dat[s].id,dat[t].id);
					}
				}
				if(t==s){
					t++;
					if(labs(dat[t].s-dat[s].s-que[i])<res  && t<=n){
						res2=dat[t].s-dat[s].s;
						res=labs(dat[t].s-dat[s].s-que[i]);
						rs=min(dat[s].id,dat[t].id)+1,rt=max(dat[s].id,dat[t].id);
					}
				}
				s++;
				if(labs(dat[t].s-dat[s].s-que[i])<res && t<=n && s!=t){
					res2=dat[t].s-dat[s].s;
					res=labs(dat[t].s-dat[s].s-que[i]);
					rs=min(dat[s].id,dat[t].id)+1,rt=max(dat[s].id,dat[t].id);
				}
			}
			printf("%lld %d %d\n",res2,rs,rt);
		}
	}
	return 0;
}