#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
typedef long long ll;
ll n;
int cnt;

struct data{
	ll f,t;
};

data dat[10000001];

int main(void){
	scanf("%lld",&n);
	ll s=1,t=1,sum=0;
	while(s*s<=n){
		while(sum<n){
			sum+=t*t;
			t++;
		}
		if(sum==n){
			dat[cnt].f=s;
			dat[cnt].t=t-1;
			cnt++;
		}
		sum-=s*s;
		s++;
	}
	printf("%d\n",cnt);
	for(int i=0;i<cnt;i++){
		printf("%d ",dat[i].t-dat[i].f+1);
		for(int j=dat[i].f;j<=dat[i].t;j++)printf("%d%c",j,j==dat[i].t?'\n':' ');
	}
	return 0;
}