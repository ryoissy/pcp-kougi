#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

int n;
bool prime[20001];
int pn[15000];
int p=0;
void seive(int s){
	for(int i=2;i<=s;i++)prime[i]=true;
	prime[0]=prime[1]=false;
	for(int i=2;i<=s;i++){
		if(prime[i]){
			for(int j=i*2;j<=s;j+=i)prime[j]=false;
		}
	}
	for(int i=2;i<=s;i++){
		if(prime[i])pn[p++]=i;
	}
}

int main(void){
	seive(20000);
	while(1){
		scanf("%d",&n);
		if(n==0)break;
		int res=0;
		int f=0,t=0,sum=pn[t];
		while(1){
			if(n==sum)res++;
			t++;
			sum+=pn[t];
			while(sum>n){
				sum-=pn[f];
				f++;
			}
			if(pn[t]>n || p<t)break;
		}
		printf("%d\n",res);
	}
	return 0;
}