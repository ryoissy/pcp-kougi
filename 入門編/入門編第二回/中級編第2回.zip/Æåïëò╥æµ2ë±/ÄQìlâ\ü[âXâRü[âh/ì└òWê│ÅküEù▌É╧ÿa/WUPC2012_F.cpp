#include <iostream>
#include <iterator>
#include <fstream>
#include <sstream>
#include <iomanip> 
#include <complex> 
#include <string>
#include <vector> 
#include <list>
#include <deque> 
#include <stack> 
#include <queue> 
#include <set>
#include <map>
#include <bitset>
#include <functional>
#include <utility>
#include <algorithm> 
#include <numeric> 
#include <typeinfo> 
#include <cstdio>
#include <cstdlib> 
#include <cstring>
#include <cmath>
#include <climits> 
#include <ctime>

using namespace std;

int n;
int x[10001],y[10001];
int in[2000][2000];
int fie[2000][2000];

int main(void){
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d%d",&x[i],&y[i]);
		in[x[i]][y[i]]++;
		fie[x[i]][y[i]]++;
	}
	for(int i=0;i<1000;i++){
		for(int j=1;j<1000;j++)fie[j][i]+=fie[j-1][i];
	}
	for(int j=0;j<1000;j++){
		for(int i=1;i<1000;i++)fie[j][i]+=fie[j][i-1];
	}
	int res=0;
	for(int i=0;i<n-1;i++){
		for(int j=i+1;j<n;j++){
			if(x[i]==x[j] || y[i]==y[j])continue;
			if(in[x[i]][y[j]]==1 && in[x[j]][y[i]]){
				int nx=min(x[i],x[j]);
				int mx=max(x[i],x[j]);
				int ny=min(y[i],y[j]);
				int my=max(y[i],y[j]);
				if(fie[nx][ny]+fie[mx-1][my-1]-fie[mx-1][ny]-fie[nx][my-1]==0){
					res=max(res,(my-ny)*(mx-nx));
				}
			}
		}
	}
	printf("%d\n",res);
	return 0;
}