#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int n;
int p[501][501];
int sum[502][502];

int main(void){
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			scanf("%d",&p[j][i]);
		}
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			sum[j+1][i]=sum[j][i]+p[j][i];
		}
	}
	int res=-1001;
	for(int l=0;l<n;l++){
		for(int r=l+1;r<=n;r++){
			int now=sum[r][0]-sum[l][0];
			res=max(res,now);
			for(int i=1;i<n;i++){
				res=max(res,now+sum[r][i]-sum[l][i]);
				int next=sum[r][i]-sum[r-1][i]+sum[l+1][i]-sum[l][i];
				if(r==l+1)next=sum[r][i]-sum[r-1][i];
				now=max(now+next,sum[r][i]-sum[l][i]);
			}
		}
	}
	printf("%d\n",res);
	return 0;
}