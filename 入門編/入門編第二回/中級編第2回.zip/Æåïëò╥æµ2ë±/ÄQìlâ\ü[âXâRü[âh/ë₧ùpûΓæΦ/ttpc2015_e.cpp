#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
using namespace std;
 
int N,K;
int x[11],y[11];
vector<int> xindex,yindex;
int main(void){
	scanf("%d %d",&N,&K);
	for(int i=0;i<K;i++){
		scanf("%d %d",&y[i],&x[i]);
		for(int j=-2;j<=2;j++){
			if(y[i]+j>=1 && y[i]+j<=N)yindex.push_back(y[i]+j);
			if(x[i]+j>=1 && x[i]+j<=N)xindex.push_back(x[i]+j);
		}
	}
	sort(xindex.begin(),xindex.end());
	xindex.erase(unique(xindex.begin(),xindex.end()),xindex.end());
	sort(yindex.begin(),yindex.end());
	yindex.erase(unique(yindex.begin(),yindex.end()),yindex.end());
	int res=1;
	for(int i=0;i<xindex.size();i++){
		for(int j=i;j<xindex.size();j++){
			for(int k=0;k<yindex.size();k++){
				for(int l=k;l<yindex.size();l++){
					int wl=0;
					int lx=xindex[i];
					int rx=xindex[j];
					int ly=yindex[k];
					int ry=yindex[l];
					if((rx-lx)%2==0 && (ry-ly)%2==0){
						if((lx+ly)%2==0)wl=1;
						else wl=-1;
					}
					for(int n=0;n<K;n++){
						if(lx<=x[n] && x[n]<=rx && ly<=y[n] && y[n]<=ry){
							if((x[n]+y[n])%2==0)wl-=2;
							else wl+=2;
						}
					}
					res=max(res,abs(wl));
				}
			}
		}
	}
	printf("%d\n",res);
	return 0;
}