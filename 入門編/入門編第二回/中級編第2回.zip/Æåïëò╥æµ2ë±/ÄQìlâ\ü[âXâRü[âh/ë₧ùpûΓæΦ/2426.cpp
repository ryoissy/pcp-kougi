#include <cstdio>
#include <cstring>
#include <vector>
#include <cstring>
#include <algorithm>
using namespace std;
int n,m;
vector<int> xindex;
vector<int> yindex;
int fie[5001][5001];
int x[5001],y[5001];

int main(void){
	scanf("%d %d",&n,&m);
	xindex.push_back(-2e9);
	yindex.push_back(-2e9);
	for(int i=0;i<n;i++){
		scanf("%d %d",&x[i],&y[i]);
		xindex.push_back(x[i]);
		yindex.push_back(y[i]);
	}
	sort(xindex.begin(),xindex.end());
	xindex.erase(unique(xindex.begin(),xindex.end()),xindex.end());
	sort(yindex.begin(),yindex.end());
	yindex.erase(unique(yindex.begin(),yindex.end()),yindex.end());
	for(int i=0;i<n;i++){
		x[i]=lower_bound(xindex.begin(),xindex.end(),x[i])-xindex.begin();
		y[i]=lower_bound(yindex.begin(),yindex.end(),y[i])-yindex.begin();
		fie[x[i]][y[i]]++;
	}
	for(int i=0;i<yindex.size();i++){
		for(int j=1;j<xindex.size();j++){
			fie[j][i]+=fie[j-1][i];
		}
	}
	for(int i=0;i<xindex.size();i++){
		for(int j=1;j<yindex.size();j++){
			fie[i][j]+=fie[i][j-1];
		}
	}
	for(int i=0;i<m;i++){
		int lx,rx,ly,ry;
		scanf("%d %d %d %d",&lx,&ly,&rx,&ry);
		lx=upper_bound(xindex.begin(),xindex.end(),lx-1)-xindex.begin();
		rx=upper_bound(xindex.begin(),xindex.end(),rx)-xindex.begin();
		ly=upper_bound(yindex.begin(),yindex.end(),ly-1)-yindex.begin();
		ry=upper_bound(yindex.begin(),yindex.end(),ry)-yindex.begin();
		lx--;
		rx--;
		ly--;
		ry--;
		printf("%d\n",fie[rx][ry]-fie[lx][ry]-fie[rx][ly]+fie[lx][ly]);
	}
	return 0;
}