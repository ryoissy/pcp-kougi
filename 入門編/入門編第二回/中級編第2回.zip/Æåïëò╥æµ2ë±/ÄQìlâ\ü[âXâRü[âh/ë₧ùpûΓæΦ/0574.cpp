#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;

int n,m,ans=0;
int tri[5001][5001];


int main(void){
	scanf("%d%d",&n,&m);
	for(int i=0;i<m;i++){
		int x,y,size;
		scanf("%d%d%d",&y,&x,&size);
		tri[x][y]=size+1;
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=i;j++){
			tri[j][i]=max(tri[j][i],max(tri[j-1][i-1],tri[j][i-1])-1);
			if(tri[j][i]>0)ans++;
		}
	}
	printf("%d\n",ans);
    return 0;
}
