#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip> 
#include <complex> 
#include <string>
#include <vector> 
#include <list>
#include <deque> 
#include <stack> 
#include <queue> 
#include <set>
#include <map>
#include <bitset>
#include <functional>
#include <utility>
#include <algorithm> 
#include <numeric> 
#include <typeinfo> 
#include <cstdio>
#include <cstdlib> 
#include <cstring>
#include <cmath>
#include <climits> 
#include <ctime>
using namespace std;

int n;
int aa=1020;
int add1[2101][2101];
int add2[3][2101][2101];
int main(void){
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		int t,x,y,r;
		scanf("%d%d%d%d",&t,&x,&y,&r);
		y=-y;
		x+=aa;
		y+=aa;
		if(t==1){
			add1[x-r+1][y]++;
			add1[x+r][y]++;
			add1[x+1][y-r]++;
			add1[x+1][y+r-1]++;
			add1[x+r+1][y+r]++;
			add1[x-r+2][y-r+1]++;
			
			add1[x-r+2][y]--;
			add1[x+r+1][y]--;
			add1[x+1][y+r]--;
			add1[x+r][y+r-1]--;
			add1[x+1][y-r+1]--;
			add1[x-r+1][y-r]--;
		}
		if(t==2){
			add1[x-r+1][y]++;
			add1[x+1][y-r]++;
			add1[x+r+1][y+r]++;
			
			add1[x+r+1][y]--;
			add1[x+1][y+r]--;
			add1[x-r+1][y-r]--;
		}
		if(t==3){
			//��
			add2[0][x-r+2][y]++;
			add2[0][x-r+1][y]++;
			add2[0][x+1][y]-=2;
			add2[0][x+2][y]-=2;
			add2[0][x+r+1][y]++;
			add2[0][x+r+2][y]++;
			
			//�E��
			add2[1][x+1][y]+=2;
			add2[1][x+1][y-1]+=2;
			add2[1][x+1][y-r-1]--;
			add2[1][x+1][y-r]--;
			add2[1][x+1][y+r]--;
			add2[1][x+1][y+r-1]--;
			
			//�E��
			add2[2][x+1][y]+=2;
			add2[2][x+2][y+1]+=2;
			add2[2][x+r+1][y+r]--;
			add2[2][x+r+2][y+r+1]--;
			add2[2][x-r+1][y-r]--;
			add2[2][x-r+2][y-r+1]--;
		}
	}
	//type3�p�[�g1(�E��)
	for(int i=0;i<2050;i++){
		for(int j=2050;j>0;j--){
			add2[1][i][j-1]+=add2[1][i][j];
		}
	}
	
	//type3�p�[�g2(�E��)
	for(int i=0;i<2050;i++){
		for(int j=0;j<2050;j++){
			if(i+j+1<2050)add2[2][j+1][i+j+1]+=add2[2][j][i+j];
			else break;
		}
	}
	for(int i=1;i<2050;i++){
		for(int j=0;j<2050;j++){
			if(i+j+1<2050)add2[2][i+j+1][j+1]+=add2[2][i+j][j];
			else break;
		}
	}
	
	//type3�p�[�g3(��)
	for(int i=0;i<2050;i++){
		for(int j=0;j<2050;j++){
			add2[0][j+1][i]+=add2[0][j][i];
		}
	}
	
	//type3��type1,2�ɑ���
	for(int i=0;i<2050;i++){
		for(int j=0;j<2050;j++){
			add1[j][i]+=add2[0][j][i]+add2[1][j][i]+add2[2][j][i];
		}
	}
	
	//�p�[�g1(�E��)
	for(int i=0;i<2050;i++){
		for(int j=2050;j>0;j--){
			add1[i][j-1]+=add1[i][j];
		}
	}
	
	//�p�[�g2(�E��)
	for(int i=0;i<2050;i++){
		for(int j=0;j<2050;j++){
			if(i+j+1<2050)add1[j+1][i+j+1]+=add1[j][i+j];
			else break;
		}
	}
	for(int i=1;i<2050;i++){
		for(int j=0;j<2050;j++){
			if(i+j+1<2050)add1[i+j+1][j+1]+=add1[i+j][j];
			else break;
		}
	}
	
	//�p�[�g3(��)
	for(int i=0;i<2050;i++){
		for(int j=0;j<2050;j++){
			add1[j+1][i]+=add1[j][i];
		}
	}
	
	//�ő�l���߂�
	int res=0;
	for(int i=0;i<2050;i++){
		for(int j=0;j<2050;j++){
			res=max(res,add1[j][i]);
		}
	}
	
	printf("%d\n",res);
	return 0;
}