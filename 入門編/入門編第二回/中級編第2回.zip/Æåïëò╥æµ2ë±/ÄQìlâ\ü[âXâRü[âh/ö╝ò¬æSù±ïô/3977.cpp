#include <iostream>
#include <cstdio>
#include <cstring>
#include <map>
#include <algorithm>
using namespace std;

typedef long long ll;
typedef pair<ll,int> P;
int n;
ll a[40];
ll ans;
int acnt=0;

ll labs(ll num){
	if(num<0)return -num;
	return num;
}

int main(void){
	while(1){
		cin >> n;
		if(n==0)break;
		for(int i=0;i<n;i++)cin >> a[i];
		map<ll,int> app;
		ans=labs(a[0]);
		acnt=1;
		for(int i=0;i<(1<<n/2);i++){
			ll sum=0;
			int cnt=0;
			for(int j=0;j<n/2;j++){
				if((i >> j) & 1)sum+=a[j],cnt++;
			}
			if(cnt==0)continue;
			P ta=min(P(ans,acnt),P(labs(sum),cnt));
			ans=ta.first;
			acnt=ta.second;
			if(app.count(sum)){
				int t=app[sum];
				app[sum]=min(cnt,t);
			}else app[sum]=cnt;
			
		}
		for(int i=0;i<(1<<(n-n/2));i++){
			ll sum=0,cnt=0,res,fres;
			for(int j=n/2;j<n;j++){
				if((i >>(j-n/2)) & 1)sum+=a[j],cnt++;
			}
			if(!cnt)continue;
			P ta=min(P(ans,acnt),P(labs(sum),cnt));
			ans=ta.first;
			acnt=ta.second;
			
			map<ll,int>::iterator p=app.lower_bound(-sum);
			if(p!=app.end()){
				ta=min(P(ans,acnt),P(labs(sum+p->first),(cnt+p->second)));
				ans=ta.first;
				acnt=ta.second;
			}
			if(p!=app.begin()){
				p--;
				ta=min(P(ans,acnt),P(labs(sum+p->first),(cnt+p->second)));
				ans=ta.first;
				acnt=ta.second;
			}
			
		}
		cout << ans << " " << acnt << endl;
	}
	return 0;
}