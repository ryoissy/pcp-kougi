#include <cstdio>
#include <vector>
#include <cstring>
#include <algorithm>
#include <functional>
using namespace std;
typedef long long ll;

int n;
ll res;
ll num[1001];

struct data{
	ll val;
	int a,b;
	data(){}
	data(ll v,int aa,int bb){
		val=v;
		a=aa;
		b=bb;
	}
	bool operator<(const data& d1)const{
		return val<d1.val;
	}
};

vector<data> d;
vector<data> d2;

int main(void){
	while(1){
		scanf("%d",&n);
		if(n==0)break;
		res=-(1e12);
		for(int i=0;i<n;i++){
			scanf("%lld",&num[i]);
		}
		sort(num,num+n);
		d.clear();
		d2.clear();
		for(int i=0;i<n;i++){
			for(int j=i+1;j<n;j++){
				d.push_back(data(num[i]+num[j],i,j));
			}
		}
		sort(d.begin(),d.end());
		reverse(d.begin(),d.end());
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				if(i==j)continue;
				ll v=num[j]-num[i];
				d2.push_back(data(v,i,j));
			}
		}
		sort(d2.begin(),d2.end());
		for(int i=0;i<d.size();i++){
			int lb=lower_bound(d2.begin(),d2.end(),d[i])-d2.begin();
			int ub=upper_bound(d2.begin(),d2.end(),d[i])-d2.begin();
			for(int j=lb;j<ub;j++){
				if(d2[j].a!=d[i].a && d2[j].a!=d[i].b && d2[j].b!=d[i].a && d2[j].b!=d[i].b){
					res=max(res,num[d2[j].b]);
				}
			}
		}
		if(res!=-(1e12))printf("%lld\n",res);
		else printf("no solution\n");
	}
	return 0;
}