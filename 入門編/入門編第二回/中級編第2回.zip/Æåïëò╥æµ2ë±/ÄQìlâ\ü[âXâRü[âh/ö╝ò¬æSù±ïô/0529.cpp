#include <iostream>
#include <algorithm>
#include <cstring>
#include <queue>
#include <cstdio>
using namespace std;

vector<long long int> p;
vector<long long int> p2;

int main(void){
	int a,b,n,m;
	while(1){
		long long int ans=0;
		scanf("%d%d",&n,&m);
		if(n==0 && m==0)break;
		p.clear();
		p2.clear();
		for(a=0;a<n;a++){
			int num;
			scanf("%d",&num);
			p.push_back(num);
		}
		sort(p.begin(),p.end());
		p2.push_back(0);
		for(a=0;a<n;a++){
			p2.push_back(p[a]);
			for(b=0;b<n;b++){
				p2.push_back(p[a]+p[b]);
			}
		}
		p2.push_back(0);
		sort(p2.begin(),p2.end());
		for(a=0;a<p2.size();a++){
			long long int res=m-p2[a];
			if(m-p2[a]<0)continue;
			long long int pp=*(lower_bound(p2.begin(),p2.end(),res)-1);
			if(ans<pp+p2[a])ans=pp+p2[a];
			//cout << pp+p2[a] << endl;
		}
		printf("%d\n",ans);
	}
	return 0;
}